-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 28, 2020 lúc 08:43 AM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `hotel.com`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate`
--

DROP TABLE IF EXISTS `wp_adrotate`;
CREATE TABLE IF NOT EXISTS `wp_adrotate` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `bannercode` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `thetime` int(15) NOT NULL DEFAULT 0,
  `updated` int(15) NOT NULL,
  `author` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `imagetype` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tracker` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `show_everyone` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `desktop` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `mobile` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `tablet` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `os_ios` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `os_android` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `os_other` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `weight` int(3) NOT NULL DEFAULT 6,
  `autodelete` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `budget` double NOT NULL DEFAULT 0,
  `crate` double NOT NULL DEFAULT 0,
  `irate` double NOT NULL DEFAULT 0,
  `cities` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `countries` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_adrotate`
--

INSERT INTO `wp_adrotate` (`id`, `title`, `bannercode`, `thetime`, `updated`, `author`, `imagetype`, `image`, `tracker`, `show_everyone`, `desktop`, `mobile`, `tablet`, `os_ios`, `os_android`, `os_other`, `type`, `weight`, `autodelete`, `budget`, `crate`, `irate`, `cities`, `countries`) VALUES
(1, 'Demo banner 468x60', '&lt;a href=\\&quot;https:\\/\\/ajdg.solutions\\&quot;&gt;&lt;img src=\\&quot;http://ajdg.solutions/assets/banners/adrotate-468x60.jpg\\&quot; /&gt;&lt;/a&gt;', 1571761853, 1571761853, 'admin', '', '', 'N', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'expired', 6, 'N', 0, 0, 0, 'a:0:{}', 'a:0:{}'),
(2, 'Demo banner 728x90', '&lt;a href=\\&quot;https:\\/\\/ajdg.solutions\\&quot;&gt;&lt;img src=\\&quot;http://ajdg.solutions/assets/banners/adrotate-728x90.jpg\\&quot; /&gt;&lt;/a&gt;', 1571761853, 1571761853, 'admin', '', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'expired', 6, 'N', 0, 0, 0, 'a:0:{}', 'a:0:{}'),
(3, '', '', 1571762423, 1571762423, 'admin', 'dropdown', '', 'N', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'empty', 6, 'N', 0, 0, 0, 'a:0:{}', 'a:0:{}'),
(4, 'test', '&lt;a href=\\&quot;http://ailabviet.com\\&quot; target=\\&quot;_blank\\&quot;&gt;&lt;img src=\\&quot;%asset%\\&quot; /&gt;&lt;/a&gt;', 1571762563, 1571763529, 'admin', 'field', 'http://localhost/hotel01/wp-content/uploads/2019/09/massage.jpg', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'expired', 6, 'N', 0, 0, 0, 'a:0:{}', 'a:0:{}'),
(5, '', '', 1571763202, 1571763202, 'admin', 'dropdown', '', 'N', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'generator', 6, 'N', 0, 0, 0, 'a:0:{}', 'a:0:{}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_groups`
--

DROP TABLE IF EXISTS `wp_adrotate_groups`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_groups` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modus` tinyint(1) NOT NULL DEFAULT 0,
  `fallback` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cat` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_loc` tinyint(1) NOT NULL DEFAULT 0,
  `cat_par` tinyint(2) NOT NULL DEFAULT 0,
  `page` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_loc` tinyint(1) NOT NULL DEFAULT 0,
  `page_par` tinyint(2) NOT NULL DEFAULT 0,
  `mobile` tinyint(1) NOT NULL DEFAULT 0,
  `geo` tinyint(1) NOT NULL DEFAULT 0,
  `wrapper_before` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `wrapper_after` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `align` tinyint(1) NOT NULL DEFAULT 0,
  `gridrows` int(3) NOT NULL DEFAULT 2,
  `gridcolumns` int(3) NOT NULL DEFAULT 2,
  `admargin` int(2) NOT NULL DEFAULT 0,
  `admargin_bottom` int(2) NOT NULL DEFAULT 0,
  `admargin_left` int(2) NOT NULL DEFAULT 0,
  `admargin_right` int(2) NOT NULL DEFAULT 0,
  `adwidth` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '125',
  `adheight` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '125',
  `adspeed` int(5) NOT NULL DEFAULT 6000,
  `repeat_impressions` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_adrotate_groups`
--

INSERT INTO `wp_adrotate_groups` (`id`, `name`, `modus`, `fallback`, `cat`, `cat_loc`, `cat_par`, `page`, `page_loc`, `page_par`, `mobile`, `geo`, `wrapper_before`, `wrapper_after`, `align`, `gridrows`, `gridcolumns`, `admargin`, `admargin_bottom`, `admargin_left`, `admargin_right`, `adwidth`, `adheight`, `adspeed`, `repeat_impressions`) VALUES
(1, '', 0, '0', '', 0, 0, '', 0, 0, 0, 0, '', '', 0, 2, 2, 0, 0, 0, 0, '125', '125', 6000, 'Y');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_linkmeta`
--

DROP TABLE IF EXISTS `wp_adrotate_linkmeta`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_linkmeta` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `group` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `user` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `schedule` int(5) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_adrotate_linkmeta`
--

INSERT INTO `wp_adrotate_linkmeta` (`id`, `ad`, `group`, `user`, `schedule`) VALUES
(1, 1, 0, 0, 1),
(2, 2, 0, 0, 2),
(3, 3, 0, 0, 3),
(4, 4, 0, 0, 4),
(5, 5, 0, 0, 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_schedule`
--

DROP TABLE IF EXISTS `wp_adrotate_schedule`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_schedule` (
  `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `starttime` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `stoptime` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `maxclicks` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `maximpressions` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `spread` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `daystarttime` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000',
  `daystoptime` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000',
  `day_mon` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_tue` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_wed` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_thu` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_fri` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_sat` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `day_sun` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `autodelete` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `starttime` (`starttime`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_adrotate_schedule`
--

INSERT INTO `wp_adrotate_schedule` (`id`, `name`, `starttime`, `stoptime`, `maxclicks`, `maximpressions`, `spread`, `daystarttime`, `daystoptime`, `day_mon`, `day_tue`, `day_wed`, `day_thu`, `day_fri`, `day_sat`, `day_sun`, `autodelete`) VALUES
(1, 'Schedule for ad 1', 1571761853, 1579019453, 0, 0, 'N', '0000', '0000', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N'),
(2, 'Schedule for ad 2', 1571761853, 1579019453, 0, 0, 'N', '0000', '0000', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N'),
(3, 'Schedule for ad 3', 1571762423, 1579020023, 0, 0, 'N', '0000', '0000', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N'),
(4, 'Schedule for ad 4', 1571762520, 1579020120, 0, 0, 'N', '0000', '0000', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N'),
(5, 'Schedule for ad 5', 1571763202, 1579020802, 0, 0, 'N', '0000', '0000', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_stats`
--

DROP TABLE IF EXISTS `wp_adrotate_stats`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_stats` (
  `id` bigint(9) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `group` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `thetime` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `clicks` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `impressions` int(15) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ad` (`ad`),
  KEY `thetime` (`thetime`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_adrotate_stats`
--

INSERT INTO `wp_adrotate_stats` (`id`, `ad`, `group`, `thetime`, `clicks`, `impressions`) VALUES
(1, 1, 0, 1571702400, 0, 1),
(2, 2, 0, 1571702400, 1, 2),
(3, 4, 0, 1571702400, 1, 9),
(4, 4, 0, 1572393600, 1, 3),
(5, 1, 0, 1572393600, 0, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_stats_archive`
--

DROP TABLE IF EXISTS `wp_adrotate_stats_archive`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_stats_archive` (
  `id` bigint(9) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `group` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `thetime` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `clicks` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `impressions` int(15) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ad` (`ad`),
  KEY `thetime` (`thetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_adrotate_tracker`
--

DROP TABLE IF EXISTS `wp_adrotate_tracker`;
CREATE TABLE IF NOT EXISTS `wp_adrotate_tracker` (
  `id` bigint(9) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `timer` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `bannerid` int(15) UNSIGNED NOT NULL DEFAULT 0,
  `stat` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'c',
  PRIMARY KEY (`id`),
  KEY `ipaddress` (`ipaddress`),
  KEY `timer` (`timer`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_booking`
--

DROP TABLE IF EXISTS `wp_booking`;
CREATE TABLE IF NOT EXISTS `wp_booking` (
  `booking_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `trash` bigint(10) NOT NULL DEFAULT 0,
  `sync_gid` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_new` bigint(10) NOT NULL DEFAULT 1,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort_date` datetime DEFAULT NULL,
  `modification_date` datetime DEFAULT NULL,
  `form` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_type` bigint(10) NOT NULL DEFAULT 1,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_booking`
--

INSERT INTO `wp_booking` (`booking_id`, `trash`, `sync_gid`, `is_new`, `status`, `sort_date`, `modification_date`, `form`, `booking_type`) VALUES
(1, 0, '', 1, '', '2019-09-08 00:00:00', '2019-09-06 09:40:00', 'text^name1^Jony~text^secondname1^Smith~text^email1^example-free@wpbookingcalendar.com~text^phone1^458-77-77~textarea^details1^Reserve a room with sea view', 1),
(2, 0, '', 1, '', '2019-09-06 00:00:00', '2019-09-06 02:42:36', 'text^name1^hoai~text^secondname1^nguyen~email^email1^nguyenvanhoai1280@gmail.com~text^phone1^01238435~textarea^details1^', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_bookingdates`
--

DROP TABLE IF EXISTS `wp_bookingdates`;
CREATE TABLE IF NOT EXISTS `wp_bookingdates` (
  `booking_id` bigint(20) UNSIGNED NOT NULL,
  `booking_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approved` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  UNIQUE KEY `booking_id_dates` (`booking_id`,`booking_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_bookingdates`
--

INSERT INTO `wp_bookingdates` (`booking_id`, `booking_date`, `approved`) VALUES
(1, '2019-09-08 00:00:00', 0),
(1, '2019-09-09 00:00:00', 0),
(1, '2019-09-10 00:00:00', 0),
(2, '2019-09-06 00:00:00', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_commentmeta`
--

INSERT INTO `wp_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_wp_trash_meta_status', '1'),
(2, 1, '_wp_trash_meta_time', '1593309806');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-09-06 01:50:01', '2019-09-06 01:50:01', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'trash', '', '', 0, 0),
(33, 269, '', '', '', '', '2019-10-04 09:42:40', '2019-10-04 02:42:40', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 0),
(34, 269, '', '', '', '', '2019-10-04 09:42:43', '2019-10-04 02:42:43', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 0),
(35, 269, '', '', '', '', '2019-10-04 09:42:47', '2019-10-04 02:42:47', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 0),
(36, 269, '', '', '', '', '2019-10-04 09:42:50', '2019-10-04 02:42:50', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 0),
(37, 269, '', '', '', '', '2019-10-04 09:44:46', '2019-10-04 02:44:46', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(38, 269, '', '', '', '', '2019-10-04 09:44:50', '2019-10-04 02:44:50', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(39, 269, '', '', '', '', '2019-10-04 09:46:39', '2019-10-04 02:46:39', 'Trạng thái thay đổi từ Xác nhận thành Trong khi chờ thanh toán.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(40, 269, '', '', '', '', '2019-10-04 09:46:58', '2019-10-04 02:46:58', 'Trạng thái thay đổi từ Trong khi chờ thanh toán thành Xác nhận.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(41, 269, '', '', '', '', '2019-10-04 09:47:02', '2019-10-04 02:47:02', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(42, 420, '', '', '', '', '2020-06-16 14:46:18', '2020-06-16 07:46:18', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(43, 420, '', '', '', '', '2020-06-16 14:46:18', '2020-06-16 07:46:18', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(44, 420, '', '', '', '', '2020-06-16 14:46:21', '2020-06-16 07:46:21', 'Gửi thư \"Email đang chờ xử lý\" cho quản trị viên không thành công.', 0, '1', '', 'mphb_booking_log', 0, 0),
(45, 420, '', '', '', '', '2020-06-16 14:46:23', '2020-06-16 07:46:23', 'Gửi thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" không thành công.', 0, '1', '', 'mphb_booking_log', 0, 0),
(46, 269, '', '', '', '', '2020-06-16 14:47:00', '2020-06-16 07:47:00', 'Trạng thái thay đổi từ Xác nhận thành Thùng rác.', 0, 'post-trashed', '', 'mphb_booking_log', 0, 1),
(47, 420, '', '', '', '', '2020-06-16 14:48:20', '2020-06-16 07:48:20', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(48, 420, '', '', '', '', '2020-06-16 14:48:22', '2020-06-16 07:48:22', 'Gửi thư \"Email đặt phòng đã được phê duyệt\" không thành công.', 0, '1', '', 'mphb_booking_log', 0, 1),
(49, 443, '', '', '', '', '2020-06-16 16:49:28', '2020-06-16 09:49:28', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(50, 443, '', '', '', '', '2020-06-16 16:49:28', '2020-06-16 09:49:28', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(51, 443, '', '', '', '', '2020-06-16 16:49:32', '2020-06-16 09:49:32', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(52, 443, '', '', '', '', '2020-06-16 16:49:36', '2020-06-16 09:49:36', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(53, 443, '', '', '', '', '2020-06-16 16:51:38', '2020-06-16 09:51:38', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận người dùng đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 1),
(54, 443, '', '', '', '', '2020-06-16 16:52:07', '2020-06-16 09:52:07', 'Trạng thái thay đổi từ Xác nhận người dùng đang chờ xử lý thành Trong khi chờ thanh toán.', 0, '1', '', 'mphb_booking_log', 0, 1),
(55, 443, '', '', '', '', '2020-06-16 16:52:27', '2020-06-16 09:52:27', 'Trạng thái thay đổi từ Trong khi chờ thanh toán thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(56, 443, '', '', '', '', '2020-06-16 16:52:31', '2020-06-16 09:52:31', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(57, 447, '', '', '', '', '2020-06-16 17:04:18', '2020-06-16 10:04:18', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(58, 447, '', '', '', '', '2020-06-16 17:04:18', '2020-06-16 10:04:18', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(59, 447, '', '', '', '', '2020-06-16 17:04:23', '2020-06-16 10:04:23', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(60, 447, '', '', '', '', '2020-06-16 17:04:27', '2020-06-16 10:04:27', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(61, 447, '', '', '', '', '2020-06-16 17:05:29', '2020-06-16 10:05:29', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(62, 447, '', '', '', '', '2020-06-16 17:05:33', '2020-06-16 10:05:33', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(63, 449, '', '', '', '', '2020-06-16 17:12:52', '2020-06-16 10:12:52', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(64, 449, '', '', '', '', '2020-06-16 17:12:53', '2020-06-16 10:12:53', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(65, 449, '', '', '', '', '2020-06-16 17:12:57', '2020-06-16 10:12:57', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(66, 449, '', '', '', '', '2020-06-16 17:13:01', '2020-06-16 10:13:01', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(67, 449, '', '', '', '', '2020-06-16 17:13:45', '2020-06-16 10:13:45', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(68, 449, '', '', '', '', '2020-06-16 17:13:49', '2020-06-16 10:13:49', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(73, 455, '', '', '', '', '2020-06-17 19:13:43', '2020-06-17 12:13:43', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(74, 455, '', '', '', '', '2020-06-17 19:13:43', '2020-06-17 12:13:43', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(75, 455, '', '', '', '', '2020-06-17 19:13:50', '2020-06-17 12:13:50', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(76, 455, '', '', '', '', '2020-06-17 19:13:55', '2020-06-17 12:13:55', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(77, 455, '', '', '', '', '2020-06-17 19:15:02', '2020-06-17 12:15:02', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(78, 455, '', '', '', '', '2020-06-17 19:15:06', '2020-06-17 12:15:06', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(79, 459, '', '', '', '', '2020-06-18 14:35:35', '2020-06-18 07:35:35', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(80, 459, '', '', '', '', '2020-06-18 14:35:35', '2020-06-18 07:35:35', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(81, 459, '', '', '', '', '2020-06-18 14:35:40', '2020-06-18 07:35:40', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(82, 459, '', '', '', '', '2020-06-18 14:35:44', '2020-06-18 07:35:44', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(83, 462, '', '', '', '', '2020-06-18 15:11:03', '2020-06-18 08:11:03', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(84, 462, '', '', '', '', '2020-06-18 15:11:03', '2020-06-18 08:11:03', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(85, 462, '', '', '', '', '2020-06-18 15:11:07', '2020-06-18 08:11:07', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(86, 462, '', '', '', '', '2020-06-18 15:11:11', '2020-06-18 08:11:11', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(87, 462, '', '', '', '', '2020-06-18 15:19:41', '2020-06-18 08:19:41', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận người dùng đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 1),
(88, 462, '', '', '', '', '2020-06-18 15:20:12', '2020-06-18 08:20:12', 'Trạng thái thay đổi từ Xác nhận người dùng đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(89, 462, '', '', '', '', '2020-06-18 15:20:17', '2020-06-18 08:20:17', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(90, 469, '', '', '', '', '2020-06-18 15:56:26', '2020-06-18 08:56:26', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(91, 469, '', '', '', '', '2020-06-18 15:56:26', '2020-06-18 08:56:26', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(92, 469, '', '', '', '', '2020-06-18 15:56:31', '2020-06-18 08:56:31', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(93, 469, '', '', '', '', '2020-06-18 15:56:35', '2020-06-18 08:56:35', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(94, 469, '', '', '', '', '2020-06-18 15:57:15', '2020-06-18 08:57:15', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(95, 469, '', '', '', '', '2020-06-18 15:57:19', '2020-06-18 08:57:19', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1),
(96, 373, 'hoai', 'nguyenthimynga0505@gmail.com', '', '::1', '2020-06-26 17:19:25', '2020-06-26 10:19:25', 'phòng đẹp', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', '', 0, 0),
(97, 373, 'trung', 'nguyenthimynga0505@gmail.com', '', '::1', '2020-06-26 17:20:30', '2020-06-26 10:20:30', 'giá đắt quá', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', '', 0, 0),
(98, 373, 'admin', 'nguyenvanhoai1280@gmail.com', '', '::1', '2020-06-26 17:22:13', '2020-06-26 10:22:13', 'test', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', '', 0, 1),
(99, 373, 'admin', 'nguyenvanhoai1280@gmail.com', '', '::1', '2020-06-26 17:25:02', '2020-06-26 10:25:02', 'thank', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', '', 0, 1),
(100, 493, '', '', '', '', '2020-06-27 15:39:07', '2020-06-27 08:39:07', 'Trạng thái thay đổi từ Mới thành Dự thảo tự động.', 0, '1', '', 'mphb_booking_log', 0, 0),
(101, 493, '', '', '', '', '2020-06-27 15:39:07', '2020-06-27 08:39:07', 'Trạng thái thay đổi từ Dự thảo tự động thành Quản trị viên đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 0),
(102, 493, '', '', '', '', '2020-06-27 15:39:11', '2020-06-27 08:39:11', 'Thư \"Email đang chờ xử lý\" đã được gửi tới quản trị viên.', 0, '1', '', 'mphb_booking_log', 0, 0),
(103, 493, '', '', '', '', '2020-06-27 15:39:15', '2020-06-27 08:39:15', 'Thư \"Email đặt phòng mới (Xác nhận của quản trị viên)\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 0),
(104, 493, '', '', '', '', '2020-06-27 15:40:35', '2020-06-27 08:40:35', 'Trạng thái thay đổi từ Quản trị viên đang chờ xử lý thành Xác nhận người dùng đang chờ xử lý.', 0, '1', '', 'mphb_booking_log', 0, 1),
(105, 493, '', '', '', '', '2020-06-27 15:41:05', '2020-06-27 08:41:05', 'Trạng thái thay đổi từ Xác nhận người dùng đang chờ xử lý thành Xác nhận.', 0, '1', '', 'mphb_booking_log', 0, 1),
(106, 493, '', '', '', '', '2020-06-27 15:41:09', '2020-06-27 08:41:09', 'Thư \"Email đặt phòng đã được phê duyệt\" đã được gửi cho khách hàng.', 0, '1', '', 'mphb_booking_log', 0, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_bills`
--

DROP TABLE IF EXISTS `wp_erp_acct_bills`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_bill_account_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_bill_account_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_bill_account_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_bill_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_bill_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `ledger_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_cash_at_banks`
--

DROP TABLE IF EXISTS `wp_erp_acct_cash_at_banks`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_cash_at_banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ledger_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_chart_of_accounts`
--

DROP TABLE IF EXISTS `wp_erp_acct_chart_of_accounts`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_chart_of_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_chart_of_accounts`
--

INSERT INTO `wp_erp_acct_chart_of_accounts` (`id`, `name`, `slug`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Asset', 'asset', NULL, NULL, NULL, NULL),
(2, 'Liability', 'liability', NULL, NULL, NULL, NULL),
(3, 'Equity', 'equity', NULL, NULL, NULL, NULL),
(4, 'Income', 'income', NULL, NULL, NULL, NULL),
(5, 'Expense', 'expense', NULL, NULL, NULL, NULL),
(6, 'Asset & Liability', 'asset_liability', NULL, NULL, NULL, NULL),
(7, 'Bank', 'bank', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_currency_info`
--

DROP TABLE IF EXISTS `wp_erp_acct_currency_info`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_currency_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_currency_info`
--

INSERT INTO `wp_erp_acct_currency_info` (`id`, `name`, `sign`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'AED', 'د.إ', NULL, NULL, NULL, NULL),
(2, 'AFN', '؋', NULL, NULL, NULL, NULL),
(3, 'ALL', 'L', NULL, NULL, NULL, NULL),
(4, 'AMD', 'AMD', NULL, NULL, NULL, NULL),
(5, 'ANG', 'ƒ', NULL, NULL, NULL, NULL),
(6, 'AOA', 'Kz', NULL, NULL, NULL, NULL),
(7, 'ARS', '$', NULL, NULL, NULL, NULL),
(8, 'AUD', '$', NULL, NULL, NULL, NULL),
(9, 'AWG', 'ƒ', NULL, NULL, NULL, NULL),
(10, 'AZN', '₼', NULL, NULL, NULL, NULL),
(11, 'BAM', 'KM', NULL, NULL, NULL, NULL),
(12, 'BBD', '$', NULL, NULL, NULL, NULL),
(13, 'BDT', '৳', NULL, NULL, NULL, NULL),
(14, 'BGN', 'лв', NULL, NULL, NULL, NULL),
(15, 'BHD', '.د.ب', NULL, NULL, NULL, NULL),
(16, 'BIF', 'Fr', NULL, NULL, NULL, NULL),
(17, 'BMD', '$', NULL, NULL, NULL, NULL),
(18, 'BND', '$', NULL, NULL, NULL, NULL),
(19, 'BOB', 'Bs.', NULL, NULL, NULL, NULL),
(20, 'BRL', 'R$', NULL, NULL, NULL, NULL),
(21, 'BSD', '$', NULL, NULL, NULL, NULL),
(22, 'BTN', 'Nu.', NULL, NULL, NULL, NULL),
(23, 'BWP', 'P', NULL, NULL, NULL, NULL),
(24, 'BYN', 'Br', NULL, NULL, NULL, NULL),
(25, 'BYR', 'Br', NULL, NULL, NULL, NULL),
(26, 'BZD', '$', NULL, NULL, NULL, NULL),
(27, 'CAD', '$', NULL, NULL, NULL, NULL),
(28, 'CDF', 'Fr', NULL, NULL, NULL, NULL),
(29, 'CHF', 'Fr', NULL, NULL, NULL, NULL),
(30, 'CLP', '$', NULL, NULL, NULL, NULL),
(31, 'CNY', '¥', NULL, NULL, NULL, NULL),
(32, 'COP', '$', NULL, NULL, NULL, NULL),
(33, 'CRC', '₡', NULL, NULL, NULL, NULL),
(34, 'CUC', '$', NULL, NULL, NULL, NULL),
(35, 'CUP', '$', NULL, NULL, NULL, NULL),
(36, 'CVE', '$', NULL, NULL, NULL, NULL),
(37, 'CZK', 'Kč', NULL, NULL, NULL, NULL),
(38, 'DJF', 'Fr', NULL, NULL, NULL, NULL),
(39, 'DKK', 'kr', NULL, NULL, NULL, NULL),
(40, 'DOP', '$', NULL, NULL, NULL, NULL),
(41, 'DZD', 'د.ج', NULL, NULL, NULL, NULL),
(42, 'EGP', '£', NULL, NULL, NULL, NULL),
(43, 'ERN', 'Nfk', NULL, NULL, NULL, NULL),
(44, 'ETB', 'Br', NULL, NULL, NULL, NULL),
(45, 'EUR', '€', NULL, NULL, NULL, NULL),
(46, 'FJD', '$', NULL, NULL, NULL, NULL),
(47, 'FKP', '£', NULL, NULL, NULL, NULL),
(48, 'GBP', '£', NULL, NULL, NULL, NULL),
(49, 'GEL', 'GEL', NULL, NULL, NULL, NULL),
(50, 'GGP', '£', NULL, NULL, NULL, NULL),
(51, 'GHS', '₵', NULL, NULL, NULL, NULL),
(52, 'GIP', '£', NULL, NULL, NULL, NULL),
(53, 'GMD', 'D', NULL, NULL, NULL, NULL),
(54, 'GNF', 'Fr', NULL, NULL, NULL, NULL),
(55, 'GTQ', 'Q', NULL, NULL, NULL, NULL),
(56, 'GYD', '$', NULL, NULL, NULL, NULL),
(57, 'HKD', '$', NULL, NULL, NULL, NULL),
(58, 'HNL', 'L', NULL, NULL, NULL, NULL),
(59, 'HRK', 'kn', NULL, NULL, NULL, NULL),
(60, 'HTG', 'G', NULL, NULL, NULL, NULL),
(61, 'HUF', 'Ft', NULL, NULL, NULL, NULL),
(62, 'IDR', 'Rp', NULL, NULL, NULL, NULL),
(63, 'ILS', '₪', NULL, NULL, NULL, NULL),
(64, 'IMP', '£', NULL, NULL, NULL, NULL),
(65, 'INR', '₹', NULL, NULL, NULL, NULL),
(66, 'IQD', 'ع.د', NULL, NULL, NULL, NULL),
(67, 'IRR', '﷼', NULL, NULL, NULL, NULL),
(68, 'ISK', 'kr', NULL, NULL, NULL, NULL),
(69, 'JEP', '£', NULL, NULL, NULL, NULL),
(70, 'JMD', '$', NULL, NULL, NULL, NULL),
(71, 'JOD', 'د.ا', NULL, NULL, NULL, NULL),
(72, 'JPY', '¥', NULL, NULL, NULL, NULL),
(73, 'KES', 'Sh', NULL, NULL, NULL, NULL),
(74, 'KGS', 'с', NULL, NULL, NULL, NULL),
(75, 'KHR', '៛', NULL, NULL, NULL, NULL),
(76, 'KMF', 'Fr', NULL, NULL, NULL, NULL),
(77, 'KPW', '₩', NULL, NULL, NULL, NULL),
(78, 'KRW', '₩', NULL, NULL, NULL, NULL),
(79, 'KWD', 'د.ك', NULL, NULL, NULL, NULL),
(80, 'KYD', '$', NULL, NULL, NULL, NULL),
(81, 'KZT', 'KZT', NULL, NULL, NULL, NULL),
(82, 'LAK', '₭', NULL, NULL, NULL, NULL),
(83, 'LBP', 'ل.ل', NULL, NULL, NULL, NULL),
(84, 'LKR', 'Rs', NULL, NULL, NULL, NULL),
(85, 'LRD', '$', NULL, NULL, NULL, NULL),
(86, 'LSL', 'L', NULL, NULL, NULL, NULL),
(87, 'LYD', 'ل.د', NULL, NULL, NULL, NULL),
(88, 'MAD', 'د.م.', NULL, NULL, NULL, NULL),
(89, 'MDL', 'L', NULL, NULL, NULL, NULL),
(90, 'MGA', 'Ar', NULL, NULL, NULL, NULL),
(91, 'MKD', 'ден', NULL, NULL, NULL, NULL),
(92, 'MMK', 'Ks', NULL, NULL, NULL, NULL),
(93, 'MNT', '₮', NULL, NULL, NULL, NULL),
(94, 'MOP', 'P', NULL, NULL, NULL, NULL),
(95, 'MRO', 'UM', NULL, NULL, NULL, NULL),
(96, 'MUR', '₨', NULL, NULL, NULL, NULL),
(97, 'MVR', 'MVR', NULL, NULL, NULL, NULL),
(98, 'MWK', 'MK', NULL, NULL, NULL, NULL),
(99, 'MXN', '$', NULL, NULL, NULL, NULL),
(100, 'MYR', 'RM', NULL, NULL, NULL, NULL),
(101, 'MZN', 'MT', NULL, NULL, NULL, NULL),
(102, 'NAD', '$', NULL, NULL, NULL, NULL),
(103, 'NGN', '₦', NULL, NULL, NULL, NULL),
(104, 'NIO', 'C$', NULL, NULL, NULL, NULL),
(105, 'NOK', 'kr', NULL, NULL, NULL, NULL),
(106, 'NPR', '₨', NULL, NULL, NULL, NULL),
(107, 'NZD', '$', NULL, NULL, NULL, NULL),
(108, 'OMR', 'ر.ع.', NULL, NULL, NULL, NULL),
(109, 'PAB', 'B/.', NULL, NULL, NULL, NULL),
(110, 'PEN', 'S/.', NULL, NULL, NULL, NULL),
(111, 'PGK', 'K', NULL, NULL, NULL, NULL),
(112, 'PHP', '₱', NULL, NULL, NULL, NULL),
(113, 'PKR', '₨', NULL, NULL, NULL, NULL),
(114, 'PLN', 'zł', NULL, NULL, NULL, NULL),
(115, 'PRB', 'р.', NULL, NULL, NULL, NULL),
(116, 'PYG', '₲', NULL, NULL, NULL, NULL),
(117, 'QAR', 'ر.ق', NULL, NULL, NULL, NULL),
(118, 'RON', 'lei', NULL, NULL, NULL, NULL),
(119, 'RSD', 'дин', NULL, NULL, NULL, NULL),
(120, 'RUB', '₽', NULL, NULL, NULL, NULL),
(121, 'RWF', 'Fr', NULL, NULL, NULL, NULL),
(122, 'SAR', 'ر.س', NULL, NULL, NULL, NULL),
(123, 'SBD', '$', NULL, NULL, NULL, NULL),
(124, 'SCR', '₨', NULL, NULL, NULL, NULL),
(125, 'SDG', 'ج.س.', NULL, NULL, NULL, NULL),
(126, 'SEK', 'kr', NULL, NULL, NULL, NULL),
(127, 'SGD', '$', NULL, NULL, NULL, NULL),
(128, 'SHP', '£', NULL, NULL, NULL, NULL),
(129, 'SLL', 'Le', NULL, NULL, NULL, NULL),
(130, 'SOS', 'Sh', NULL, NULL, NULL, NULL),
(131, 'SRD', '$', NULL, NULL, NULL, NULL),
(132, 'SSP', '£', NULL, NULL, NULL, NULL),
(133, 'STD', 'Db', NULL, NULL, NULL, NULL),
(134, 'SYP', '£', NULL, NULL, NULL, NULL),
(135, 'SZL', 'L', NULL, NULL, NULL, NULL),
(136, 'THB', '฿', NULL, NULL, NULL, NULL),
(137, 'TJS', 'ЅМ', NULL, NULL, NULL, NULL),
(138, 'TMT', 'm', NULL, NULL, NULL, NULL),
(139, 'TND', 'د.ت', NULL, NULL, NULL, NULL),
(140, 'TOP', 'T$', NULL, NULL, NULL, NULL),
(141, 'TRY', 'TRY', NULL, NULL, NULL, NULL),
(142, 'TTD', '$', NULL, NULL, NULL, NULL),
(143, 'TVD', '$', NULL, NULL, NULL, NULL),
(144, 'TWD', '$', NULL, NULL, NULL, NULL),
(145, 'TZS', 'Sh', NULL, NULL, NULL, NULL),
(146, 'UAH', '₴', NULL, NULL, NULL, NULL),
(147, 'UGX', 'Sh', NULL, NULL, NULL, NULL),
(148, 'USD', '$', NULL, NULL, NULL, NULL),
(149, 'UYU', '$', NULL, NULL, NULL, NULL),
(150, 'UZS', 'UZS', NULL, NULL, NULL, NULL),
(151, 'VEF', 'Bs', NULL, NULL, NULL, NULL),
(152, 'VND', '₫', NULL, NULL, NULL, NULL),
(153, 'VUV', 'Vt', NULL, NULL, NULL, NULL),
(154, 'WST', 'T', NULL, NULL, NULL, NULL),
(155, 'XAF', 'Fr', NULL, NULL, NULL, NULL),
(156, 'XCD', '$', NULL, NULL, NULL, NULL),
(157, 'XOF', 'Fr', NULL, NULL, NULL, NULL),
(158, 'XPF', 'Fr', NULL, NULL, NULL, NULL),
(159, 'YER', '﷼', NULL, NULL, NULL, NULL),
(160, 'ZAR', 'R', NULL, NULL, NULL, NULL),
(161, 'ZMW', 'ZK', NULL, NULL, NULL, NULL),
(162, 'ZWL', '$', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_expenses`
--

DROP TABLE IF EXISTS `wp_erp_acct_expenses`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `people_id` int(11) DEFAULT NULL,
  `people_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `check_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `trn_by` int(11) DEFAULT NULL,
  `trn_by_ledger_id` int(11) DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_expense_checks`
--

DROP TABLE IF EXISTS `wp_erp_acct_expense_checks`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_expense_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `check_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `bank` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_expense_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_expense_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_expense_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `ledger_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_financial_years`
--

DROP TABLE IF EXISTS `wp_erp_acct_financial_years`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_financial_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_financial_years`
--

INSERT INTO `wp_erp_acct_financial_years` (`id`, `name`, `start_date`, `end_date`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, '2020', '2020-01-01', '2020-12-31', NULL, '2020-06-18', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoices`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoices`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `billing_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `discount` decimal(20,2) DEFAULT 0.00,
  `discount_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` decimal(20,2) DEFAULT 0.00,
  `estimate` tinyint(1) DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoice_account_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoice_account_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoice_account_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoice_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoice_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `unit_price` decimal(20,2) DEFAULT 0.00,
  `discount` decimal(20,2) DEFAULT 0.00,
  `tax` decimal(20,2) DEFAULT 0.00,
  `item_total` decimal(20,2) DEFAULT 0.00,
  `ecommerce_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoice_details_tax`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoice_details_tax`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoice_details_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_details_id` int(11) DEFAULT NULL,
  `agency_id` int(11) DEFAULT NULL,
  `tax_rate` decimal(20,2) DEFAULT 0.00,
  `tax_amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoice_receipts`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoice_receipts`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoice_receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `trn_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_by_ledger_id` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_invoice_receipts_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_invoice_receipts_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_invoice_receipts_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `invoice_no` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_journals`
--

DROP TABLE IF EXISTS `wp_erp_acct_journals`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_journals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_date` date DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_no` int(11) DEFAULT NULL,
  `voucher_amount` decimal(20,2) DEFAULT 0.00,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_journal_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_journal_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_journal_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `ledger_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_ledgers`
--

DROP TABLE IF EXISTS `wp_erp_acct_ledgers`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_ledgers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `unused` tinyint(1) DEFAULT NULL,
  `system` tinyint(1) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_ledgers`
--

INSERT INTO `wp_erp_acct_ledgers` (`id`, `chart_id`, `category_id`, `name`, `slug`, `code`, `unused`, `system`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, NULL, 'Accounts Receivable', 'accounts_receivable', 120, 1, 1, NULL, NULL, NULL, NULL),
(2, 1, NULL, 'Inventory', 'inventory', 140, NULL, 1, NULL, NULL, NULL, NULL),
(3, 1, NULL, 'Office Equipment', 'office_equipment', 150, NULL, 1, NULL, NULL, NULL, NULL),
(4, 1, NULL, 'Less Accumulated Depreciation on Office Equipment', 'less_accumulated_depreciation_on_office_equipment', 151, NULL, 1, NULL, NULL, NULL, NULL),
(5, 1, NULL, 'Computer Equipment', 'computer_equipment', 160, NULL, 1, NULL, NULL, NULL, NULL),
(6, 1, NULL, 'Less Accumulated Depreciation on Computer Equipment', 'less_accumulated_depreciation_on_computer_equipment', 161, NULL, 1, NULL, NULL, NULL, NULL),
(7, 1, NULL, 'Cash', 'cash', 90, NULL, 0, NULL, NULL, NULL, NULL),
(8, 2, NULL, 'Accounts Payable', 'accounts_payable', 200, 1, 1, NULL, NULL, NULL, NULL),
(9, 2, NULL, 'Accruals', 'accruals', 205, NULL, 0, NULL, NULL, NULL, NULL),
(10, 2, NULL, 'Unpaid Expense Claims', 'unpaid_expense_claims', 210, NULL, 1, NULL, NULL, NULL, NULL),
(11, 2, NULL, 'Wages Payable', 'wages_payable', 215, NULL, 1, NULL, NULL, NULL, NULL),
(12, 2, NULL, 'Wages Payable - Payroll', 'wages_payable_payroll', 216, NULL, 0, NULL, NULL, NULL, NULL),
(13, 2, NULL, 'Sales Tax', 'sales_tax', 220, NULL, 1, NULL, NULL, NULL, NULL),
(14, 2, NULL, 'Employee Tax Payable', 'employee_tax_payable', 230, NULL, 0, NULL, NULL, NULL, NULL),
(15, 2, NULL, 'Employee Benefits Payable', 'employee_benefits_payable', 235, NULL, 0, NULL, NULL, NULL, NULL),
(16, 2, NULL, 'Employee Deductions payable', 'employee_deductions_payable', 236, NULL, 0, NULL, NULL, NULL, NULL),
(17, 2, NULL, 'Income Tax Payable', 'income_tax_payable', 240, NULL, 0, NULL, NULL, NULL, NULL),
(18, 2, NULL, 'Suspense', 'suspense', 250, NULL, 0, NULL, NULL, NULL, NULL),
(19, 2, NULL, 'Historical Adjustments', 'historical_adjustments', 255, NULL, 1, NULL, NULL, NULL, NULL),
(20, 2, NULL, 'Rounding', 'rounding', 260, NULL, 1, NULL, NULL, NULL, NULL),
(21, 2, NULL, 'Revenue Received in Advance', 'revenue_received_in_advance', 835, NULL, 0, NULL, NULL, NULL, NULL),
(22, 2, NULL, 'Clearing Account', 'clearing_account', 855, NULL, 0, NULL, NULL, NULL, NULL),
(23, 2, NULL, 'Loan', 'loan', 290, NULL, 0, NULL, NULL, NULL, NULL),
(24, 5, NULL, 'Costs of Goods Sold', 'costs_of_goods_sold', 500, NULL, 1, NULL, NULL, NULL, NULL),
(25, 5, NULL, 'Advertising', 'advertising', 600, NULL, 0, NULL, NULL, NULL, NULL),
(26, 5, NULL, 'Bank Service Charges', 'bank_service_charges', 605, NULL, 0, NULL, NULL, NULL, NULL),
(27, 5, NULL, 'Janitorial Expenses', 'janitorial_expenses', 610, NULL, 0, NULL, NULL, NULL, NULL),
(28, 5, NULL, 'Consulting & Accounting', 'consulting_accounting', 615, NULL, 0, NULL, NULL, NULL, NULL),
(29, 5, NULL, 'Entertainment', 'entertainment', 620, NULL, 0, NULL, NULL, NULL, NULL),
(30, 5, NULL, 'Postage & Delivary', 'postage_delivary', 624, NULL, 0, NULL, NULL, NULL, NULL),
(31, 5, NULL, 'General Expenses', 'general_expenses', 628, NULL, 0, NULL, NULL, NULL, NULL),
(32, 5, NULL, 'Insurance', 'insurance', 632, NULL, 0, NULL, NULL, NULL, NULL),
(33, 5, NULL, 'Legal Expenses', 'legal_expenses', 636, NULL, 0, NULL, NULL, NULL, NULL),
(34, 5, NULL, 'Utilities', 'utilities', 640, NULL, 1, NULL, NULL, NULL, NULL),
(35, 5, NULL, 'Automobile Expenses', 'automobile_expenses', 644, NULL, 0, NULL, NULL, NULL, NULL),
(36, 5, NULL, 'Office Expenses', 'office_expenses', 648, NULL, 1, NULL, NULL, NULL, NULL),
(37, 5, NULL, 'Printing & Stationary', 'printing_stationary', 652, NULL, 0, NULL, NULL, NULL, NULL),
(38, 5, NULL, 'Rent', 'rent', 656, NULL, 1, NULL, NULL, NULL, NULL),
(39, 5, NULL, 'Repairs & Maintenance', 'repairs_maintenance', 660, NULL, 0, NULL, NULL, NULL, NULL),
(40, 5, NULL, 'Wages & Salaries', 'wages_salaries', 664, NULL, 0, NULL, NULL, NULL, NULL),
(41, 5, NULL, 'Payroll Tax Expense', 'payroll_tax_expense', 668, NULL, 0, NULL, NULL, NULL, NULL),
(42, 5, NULL, 'Dues & Subscriptions', 'dues_subscriptions', 672, NULL, 0, NULL, NULL, NULL, NULL),
(43, 5, NULL, 'Telephone & Internet', 'telephone_internet', 676, NULL, 0, NULL, NULL, NULL, NULL),
(44, 5, NULL, 'Travel', 'travel', 680, NULL, 0, NULL, NULL, NULL, NULL),
(45, 5, NULL, 'Bad Debts', 'bad_debts', 684, NULL, 0, NULL, NULL, NULL, NULL),
(46, 5, NULL, 'Depreciation', 'depreciation', 700, NULL, 1, NULL, NULL, NULL, NULL),
(47, 5, NULL, 'Income Tax Expense', 'income_tax_expense', 710, NULL, 0, NULL, NULL, NULL, NULL),
(48, 5, NULL, 'Employee Benefits Expense', 'employee_benefits_expense', 715, NULL, 0, NULL, NULL, NULL, NULL),
(49, 5, NULL, 'Interest Expense', 'interest_expense', 800, NULL, 0, NULL, NULL, NULL, NULL),
(50, 5, NULL, 'Bank Revaluations', 'bank_revaluations', 810, NULL, 1, NULL, NULL, NULL, NULL),
(51, 5, NULL, 'Unrealized Currency Gains', 'unrealized_currency_gains', 815, NULL, 1, NULL, NULL, NULL, NULL),
(52, 5, NULL, 'Realized Currency Gains', 'realized_currency_gains', 820, NULL, 1, NULL, NULL, NULL, NULL),
(53, 5, NULL, 'Sales Discount', 'sales_discount', 825, NULL, 1, NULL, NULL, NULL, NULL),
(54, 4, NULL, 'Sales', 'sales', 400, NULL, 0, NULL, NULL, NULL, NULL),
(55, 4, NULL, 'Interest Income', 'interest_income', 460, NULL, 0, NULL, NULL, NULL, NULL),
(56, 4, NULL, 'Other Revenue', 'other_revenue', 470, NULL, 0, NULL, NULL, NULL, NULL),
(57, 4, NULL, 'Purchase Discount', 'purchase_discount', 475, NULL, 1, NULL, NULL, NULL, NULL),
(58, 3, NULL, 'Owners Contribution', 'owners_contribution', 300, NULL, 0, NULL, NULL, NULL, NULL),
(59, 3, NULL, 'Owners Draw', 'owners_draw', 310, NULL, 0, NULL, NULL, NULL, NULL),
(60, 3, NULL, 'Retained Earnings', 'retained_earnings', 320, NULL, 1, NULL, NULL, NULL, NULL),
(61, 3, NULL, 'Common Stock', 'common_stock', 330, NULL, 0, NULL, NULL, NULL, NULL),
(62, 1, NULL, 'Savings Account', 'savings_account', 92, NULL, 0, NULL, NULL, NULL, NULL),
(63, 1, NULL, 'Allowance for Doubtful Accounts', 'allowance_for_doubtful_accounts', 1001, NULL, 1, NULL, NULL, NULL, NULL),
(64, 1, NULL, 'Interest Receivable', 'interest_receivable', 1002, NULL, 1, NULL, NULL, NULL, NULL),
(65, 1, NULL, 'Supplies', 'supplies', 1003, NULL, 1, NULL, NULL, NULL, NULL),
(66, 1, NULL, 'Prepaid Insurance', 'prepaid_insurance', 1004, NULL, 1, NULL, NULL, NULL, NULL),
(67, 1, NULL, 'Prepaid Rent', 'prepaid_rent', 1005, NULL, 1, NULL, NULL, NULL, NULL),
(68, 1, NULL, 'Prepaid Salary', 'prepaid_salary', 1006, NULL, 1, NULL, NULL, NULL, NULL),
(69, 1, NULL, 'Land', 'land', 1007, NULL, 1, NULL, NULL, NULL, NULL),
(70, 1, NULL, 'Furniture & Fixture', 'furniture_fixture', 1008, NULL, 1, NULL, NULL, NULL, NULL),
(71, 1, NULL, 'Buildings', 'buildings', 1009, NULL, 1, NULL, NULL, NULL, NULL),
(72, 1, NULL, 'Copyrights', 'copyrights', 1010, NULL, 1, NULL, NULL, NULL, NULL),
(73, 1, NULL, 'Goodwill', 'goodwill', 1011, NULL, 1, NULL, NULL, NULL, NULL),
(74, 1, NULL, 'Patents', 'patents', 1012, NULL, 1, NULL, NULL, NULL, NULL),
(75, 1, NULL, 'Accoumulated Depreciation- Buildings', 'accoumulated_depreciation_buildings', 1013, NULL, 1, NULL, NULL, NULL, NULL),
(76, 1, NULL, 'Accoumulated Depreciation- Furniture & Fixtures', 'accoumulated_depreciation_furniture_fixtures', 1014, NULL, 1, NULL, NULL, NULL, NULL),
(77, 2, NULL, 'Notes Payable', 'notes_payable', 1201, NULL, 1, NULL, NULL, NULL, NULL),
(78, 2, NULL, 'Salaries and Wages Payable', 'salaries_and_wages_payable', 1202, NULL, 1, NULL, NULL, NULL, NULL),
(79, 2, NULL, 'Unearned Rent Revenue', 'unearned_rent_revenue', 1203, NULL, 1, NULL, NULL, NULL, NULL),
(80, 2, NULL, 'Interest Payable', 'interest_payable', 1204, NULL, 1, NULL, NULL, NULL, NULL),
(81, 2, NULL, 'Dividends Payable', 'dividends_payable', 1205, NULL, 1, NULL, NULL, NULL, NULL),
(82, 2, NULL, 'Bonds Payable', 'bonds_payable', 1206, NULL, 1, NULL, NULL, NULL, NULL),
(83, 2, NULL, 'Discount on Bonds Payable', 'discount_on_bonds_payable', 1207, NULL, 1, NULL, NULL, NULL, NULL),
(84, 2, NULL, 'Premium on Bonds Payable', 'premium_on_bonds_payable', 1208, NULL, 1, NULL, NULL, NULL, NULL),
(85, 2, NULL, 'Mortgage Payable', 'mortgage_payable', 1209, NULL, 1, NULL, NULL, NULL, NULL),
(86, 3, NULL, 'Owner\'s Equity', 'owner_s_equity', 1301, NULL, 1, NULL, NULL, NULL, NULL),
(87, 3, NULL, 'Paid-in Capital in Excess of Par- Common Stock', 'paid_in_capital_in_excess_of_par_common_stock', 1302, NULL, 1, NULL, NULL, NULL, NULL),
(88, 3, NULL, 'Paid-in Capital in Excess of Par- Preferred Stock', 'paid_in_capital_in_excess_of_par_preferred_stock', 1303, NULL, 1, NULL, NULL, NULL, NULL),
(89, 3, NULL, 'Preferred Stock', 'preferred_stock', 1304, NULL, 1, NULL, NULL, NULL, NULL),
(90, 3, NULL, 'Treasury Stock', 'treasury_stock', 1305, NULL, 1, NULL, NULL, NULL, NULL),
(91, 3, NULL, 'Dividends', 'dividends', 1306, NULL, 1, NULL, NULL, NULL, NULL),
(92, 3, NULL, 'Income Summary', 'income_summary', 1307, NULL, 1, NULL, NULL, NULL, NULL),
(93, 4, NULL, 'Service Revenue', 'service_revenue', 1401, NULL, 1, NULL, NULL, NULL, NULL),
(94, 4, NULL, 'Sales Revenue', 'sales_revenue', 1402, NULL, 1, NULL, NULL, NULL, NULL),
(95, 4, NULL, 'Gain on Disposal of Plant Assets', 'gain_on_disposal_of_plant_assets', 1404, NULL, 1, NULL, NULL, NULL, NULL),
(96, 4, NULL, 'Asset Sales', 'asset_sales', 1405, NULL, 1, NULL, NULL, NULL, NULL),
(97, 5, NULL, 'Amortization Expense', 'amortization_expense', 1501, NULL, 1, NULL, NULL, NULL, NULL),
(98, 5, NULL, 'Freight-Out', 'freight_out', 1502, NULL, 1, NULL, NULL, NULL, NULL),
(99, 5, NULL, 'Insurance Expense', 'insurance_expense', 1503, NULL, 1, NULL, NULL, NULL, NULL),
(100, 5, NULL, 'Loss on Disposal of Plant Assets', 'loss_on_disposal_of_plant_assets', 1504, NULL, 1, NULL, NULL, NULL, NULL),
(101, 5, NULL, 'Maintenance and Repairs Expense', 'maintenance_and_repairs_expense', 1505, NULL, 1, NULL, NULL, NULL, NULL),
(102, 5, NULL, 'Purchase', 'purchase', 1506, NULL, 1, NULL, NULL, NULL, NULL),
(103, 5, NULL, 'Asset Purchase', 'asset_purchase', 1506, NULL, 1, NULL, NULL, NULL, NULL),
(104, 5, NULL, 'Sales Returns and Allowance', 'sales_returns_and_allowance', 1403, NULL, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_ledger_categories`
--

DROP TABLE IF EXISTS `wp_erp_acct_ledger_categories`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_ledger_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chart_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `system` tinyint(1) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_ledger_categories`
--

INSERT INTO `wp_erp_acct_ledger_categories` (`id`, `name`, `slug`, `chart_id`, `parent_id`, `system`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Current Asset', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Fixed Asset', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Inventory', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Non-current Asset', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Prepayment', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Bank & Cash', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Current Liability', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Liability', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Non-current Liability', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Depreciation', NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Direct Costs', NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Expense', NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Revenue', NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'Sales', NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Other Income', NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Equity', NULL, 5, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_ledger_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_ledger_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_ledger_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ledger_id` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `trn_date` date DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_ledger_settings`
--

DROP TABLE IF EXISTS `wp_erp_acct_ledger_settings`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_ledger_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ledger_id` int(11) DEFAULT NULL,
  `short_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_opening_balances`
--

DROP TABLE IF EXISTS `wp_erp_acct_opening_balances`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_opening_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `financial_year_id` int(11) DEFAULT NULL,
  `chart_id` int(11) DEFAULT NULL,
  `ledger_id` int(11) DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_payment_methods`
--

DROP TABLE IF EXISTS `wp_erp_acct_payment_methods`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_payment_methods`
--

INSERT INTO `wp_erp_acct_payment_methods` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Cash', NULL, NULL, NULL, NULL),
(2, 'Bank', NULL, NULL, NULL, NULL),
(3, 'Check', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_pay_bill`
--

DROP TABLE IF EXISTS `wp_erp_acct_pay_bill`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_pay_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `trn_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_by_ledger_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_pay_bill_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_pay_bill_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `bill_no` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_pay_purchase`
--

DROP TABLE IF EXISTS `wp_erp_acct_pay_purchase`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_pay_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `trn_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_by_ledger_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_pay_purchase_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_pay_purchase_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_pay_purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `purchase_no` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_people_account_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_people_account_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_people_account_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `trn_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_people_trn`
--

DROP TABLE IF EXISTS `wp_erp_acct_people_trn`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_people_trn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_no` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `trn_date` date DEFAULT NULL,
  `trn_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_people_trn_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_people_trn_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_people_trn_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_products`
--

DROP TABLE IF EXISTS `wp_erp_acct_products`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `tax_cat_id` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `cost_price` decimal(20,2) DEFAULT 0.00,
  `sale_price` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_product_categories`
--

DROP TABLE IF EXISTS `wp_erp_acct_product_categories`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_product_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_product_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_product_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `stock_in` int(11) DEFAULT NULL,
  `stock_out` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_product_types`
--

DROP TABLE IF EXISTS `wp_erp_acct_product_types`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_product_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_product_types`
--

INSERT INTO `wp_erp_acct_product_types` (`id`, `name`, `slug`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Inventory', 'inventory', NULL, NULL, NULL, NULL),
(2, 'Service', 'service', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_purchase`
--

DROP TABLE IF EXISTS `wp_erp_acct_purchase`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `purchase_order` tinyint(1) DEFAULT NULL,
  `attachments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_purchase_account_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_purchase_account_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_purchase_account_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_no` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT 0.00,
  `credit` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_purchase_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_purchase_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trn_no` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(20,2) DEFAULT 0.00,
  `amount` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_taxes`
--

DROP TABLE IF EXISTS `wp_erp_acct_taxes`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_taxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_rate_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default` tinyint(1) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_tax_agencies`
--

DROP TABLE IF EXISTS `wp_erp_acct_tax_agencies`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_tax_agencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ecommerce_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_tax_agency_details`
--

DROP TABLE IF EXISTS `wp_erp_acct_tax_agency_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_tax_agency_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) DEFAULT NULL,
  `trn_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` decimal(10,2) DEFAULT 0.00,
  `credit` decimal(10,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_tax_categories`
--

DROP TABLE IF EXISTS `wp_erp_acct_tax_categories`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_tax_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_tax_cat_agency`
--

DROP TABLE IF EXISTS `wp_erp_acct_tax_cat_agency`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_tax_cat_agency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) DEFAULT NULL,
  `component_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_cat_id` int(11) DEFAULT NULL,
  `agency_id` int(11) DEFAULT NULL,
  `tax_rate` decimal(20,2) DEFAULT 0.00,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_tax_pay`
--

DROP TABLE IF EXISTS `wp_erp_acct_tax_pay`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_tax_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT 0.00,
  `voucher_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_by` int(11) DEFAULT NULL,
  `agency_id` int(11) DEFAULT NULL,
  `ledger_id` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_transfer_voucher`
--

DROP TABLE IF EXISTS `wp_erp_acct_transfer_voucher`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_transfer_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` int(11) DEFAULT NULL,
  `trn_date` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `ac_from` int(11) DEFAULT NULL,
  `ac_to` int(11) DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_trn_status_types`
--

DROP TABLE IF EXISTS `wp_erp_acct_trn_status_types`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_trn_status_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_acct_trn_status_types`
--

INSERT INTO `wp_erp_acct_trn_status_types` (`id`, `type_name`, `slug`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Draft', 'draft', NULL, NULL, NULL, NULL),
(2, 'Awaiting Payment', 'awaiting_payment', NULL, NULL, NULL, NULL),
(3, 'Pending', 'pending', NULL, NULL, NULL, NULL),
(4, 'Paid', 'paid', NULL, NULL, NULL, NULL),
(5, 'Partially Paid', 'partially_paid', NULL, NULL, NULL, NULL),
(6, 'Approved', 'approved', NULL, NULL, NULL, NULL),
(7, 'Closed', 'closed', NULL, NULL, NULL, NULL),
(8, 'Void', 'void', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_acct_voucher_no`
--

DROP TABLE IF EXISTS `wp_erp_acct_voucher_no`;
CREATE TABLE IF NOT EXISTS `wp_erp_acct_voucher_no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editable` tinyint(4) DEFAULT 0,
  `created_at` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_audit_log`
--

DROP TABLE IF EXISTS `wp_erp_audit_log`;
CREATE TABLE IF NOT EXISTS `wp_erp_audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `component` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sub_component` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `data_id` bigint(20) DEFAULT NULL,
  `old_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changetype` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `component` (`component`),
  KEY `sub_component` (`sub_component`),
  KEY `changetype` (`changetype`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_company_locations`
--

DROP TABLE IF EXISTS `wp_erp_company_locations`;
CREATE TABLE IF NOT EXISTS `wp_erp_company_locations` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_id` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` int(6) DEFAULT NULL,
  `country` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_activities_task`
--

DROP TABLE IF EXISTS `wp_erp_crm_activities_task`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_activities_task` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_contact_group`
--

DROP TABLE IF EXISTS `wp_erp_crm_contact_group`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_contact_group` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `private` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_contact_subscriber`
--

DROP TABLE IF EXISTS `wp_erp_crm_contact_subscriber`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_contact_subscriber` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscribe_at` datetime DEFAULT NULL,
  `unsubscribe_at` datetime DEFAULT NULL,
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_group` (`user_id`,`group_id`),
  KEY `status` (`status`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_customer_activities`
--

DROP TABLE IF EXISTS `wp_erp_crm_customer_activities`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_customer_activities` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `extra` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_notification` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `log_type` (`log_type`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_customer_companies`
--

DROP TABLE IF EXISTS `wp_erp_crm_customer_companies`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_customer_companies` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `company_id` bigint(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_save_email_replies`
--

DROP TABLE IF EXISTS `wp_erp_crm_save_email_replies`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_save_email_replies` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_crm_save_search`
--

DROP TABLE IF EXISTS `wp_erp_crm_save_search`;
CREATE TABLE IF NOT EXISTS `wp_erp_crm_save_search` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `global` tinyint(4) DEFAULT 0,
  `search_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `search_val` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_holidays_indv`
--

DROP TABLE IF EXISTS `wp_erp_holidays_indv`;
CREATE TABLE IF NOT EXISTS `wp_erp_holidays_indv` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `holiday_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_announcement`
--

DROP TABLE IF EXISTS `wp_erp_hr_announcement`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_announcement` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(11) NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_dependents`
--

DROP TABLE IF EXISTS `wp_erp_hr_dependents`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_dependents` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_depts`
--

DROP TABLE IF EXISTS `wp_erp_hr_depts`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_depts` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead` int(11) UNSIGNED DEFAULT 0,
  `parent` int(11) UNSIGNED DEFAULT 0,
  `status` tinyint(1) UNSIGNED DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_designations`
--

DROP TABLE IF EXISTS `wp_erp_hr_designations`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_designations` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_education`
--

DROP TABLE IF EXISTS `wp_erp_hr_education`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_education` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) UNSIGNED DEFAULT NULL,
  `school` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finished` int(4) UNSIGNED DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interest` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_employees`
--

DROP TABLE IF EXISTS `wp_erp_hr_employees`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_employees` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `employee_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `department` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `location` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `hiring_source` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hiring_date` date NOT NULL,
  `termination_date` date NOT NULL,
  `date_of_birth` date NOT NULL,
  `reporting_to` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `pay_rate` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `pay_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `employee_id` (`employee_id`),
  KEY `designation` (`designation`),
  KEY `department` (`department`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_employee_history`
--

DROP TABLE IF EXISTS `wp_erp_hr_employee_history`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_employee_history` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `module` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_employee_notes`
--

DROP TABLE IF EXISTS `wp_erp_hr_employee_notes`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_employee_notes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_employee_performance`
--

DROP TABLE IF EXISTS `wp_erp_hr_employee_performance`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_employee_performance` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) UNSIGNED DEFAULT NULL,
  `reporting_to` int(11) UNSIGNED DEFAULT NULL,
  `job_knowledge` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_quality` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attendance` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `communication` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dependablity` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewer` int(11) UNSIGNED DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `goal_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_assessment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor` int(11) UNSIGNED DEFAULT NULL,
  `supervisor_assessment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performance_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_financial_years`
--

DROP TABLE IF EXISTS `wp_erp_hr_financial_years`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_financial_years` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `year_search` (`start_date`,`end_date`),
  KEY `start_date` (`start_date`),
  KEY `end_date` (`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_holiday`
--

DROP TABLE IF EXISTS `wp_erp_hr_holiday`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_holiday` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start` timestamp NOT NULL DEFAULT current_timestamp(),
  `end` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `range_status` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leaves`
--

DROP TABLE IF EXISTS `wp_erp_hr_leaves`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leaves` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leaves_unpaid`
--

DROP TABLE IF EXISTS `wp_erp_hr_leaves_unpaid`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leaves_unpaid` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `leave_id` smallint(6) UNSIGNED NOT NULL,
  `leave_request_id` bigint(20) UNSIGNED NOT NULL,
  `leave_approval_status_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `days` decimal(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `total` decimal(20,2) NOT NULL DEFAULT 0.00,
  `f_year` smallint(5) UNSIGNED NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `leave_id` (`leave_id`),
  KEY `f_year` (`f_year`),
  KEY `leave_request_id` (`leave_request_id`),
  KEY `leave_approval_status_id` (`leave_approval_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_approval_status`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_approval_status`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_approval_status` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `leave_request_id` bigint(20) UNSIGNED NOT NULL,
  `approval_status_id` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_request_id` (`leave_request_id`),
  KEY `approval_status_id` (`approval_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_encashment_requests`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_encashment_requests`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_encashment_requests` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `leave_id` smallint(6) UNSIGNED NOT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approval_status_id` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `encash_days` decimal(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `forward_days` decimal(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `total` decimal(20,2) NOT NULL DEFAULT 0.00,
  `f_year` smallint(5) UNSIGNED NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `leave_id` (`leave_id`),
  KEY `f_year` (`f_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_entitlements`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_entitlements`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_entitlements` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `leave_id` smallint(6) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `trn_id` bigint(20) UNSIGNED NOT NULL,
  `trn_type` enum('leave_policies','leave_approval_status','leave_encashment_requests','leave_entitlements','unpaid_leave','leave_encashment','leave_carryforward','manual_leave_policies','Accounts','others','leave_accrual','carry_forward_leave_expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'leave_policies',
  `day_in` decimal(5,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `day_out` decimal(5,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_year` smallint(6) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comp_key_1` (`user_id`,`leave_id`,`f_year`,`trn_type`),
  KEY `trn_id` (`trn_id`),
  KEY `leave_id` (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_policies`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_policies`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_policies` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `leave_id` smallint(5) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `days` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apply_limit` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `employee_type` enum('-1','permanent','parttime','contract','temporary','trainee') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'permanent',
  `department_id` int(11) NOT NULL DEFAULT -1,
  `location_id` int(11) NOT NULL DEFAULT -1,
  `designation_id` int(11) NOT NULL DEFAULT -1,
  `gender` enum('-1','male','female','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-1',
  `marital` enum('-1','single','married','widowed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-1',
  `f_year` smallint(5) UNSIGNED DEFAULT NULL,
  `apply_for_new_users` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `carryover_days` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `carryover_uses_limit` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `encashment_days` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `encashment_based_on` enum('pay_rate','basic','gross') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_default` enum('encashment','carryover') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'encashment',
  `applicable_from_days` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `accrued_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `accrued_max_days` smallint(4) UNSIGNED NOT NULL DEFAULT 0,
  `halfday_enable` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_id` (`leave_id`),
  KEY `f_year` (`f_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_policies_segregation`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_policies_segregation`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_policies_segregation` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `leave_policy_id` bigint(20) UNSIGNED NOT NULL,
  `jan` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `feb` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `mar` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `apr` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `may` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `jun` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `jul` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `aug` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `sep` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `oct` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `nov` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `decem` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_policy_id` (`leave_policy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_requests`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_requests`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_requests` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `leave_id` smallint(6) UNSIGNED NOT NULL,
  `leave_entitlement_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `day_status_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `days` decimal(5,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_status` smallint(6) UNSIGNED NOT NULL DEFAULT 2,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_leave` (`user_id`,`leave_id`),
  KEY `user_entitlement` (`user_id`,`leave_entitlement_id`),
  KEY `last_status` (`last_status`),
  KEY `leave_entitlement_id` (`leave_entitlement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_leave_request_details`
--

DROP TABLE IF EXISTS `wp_erp_hr_leave_request_details`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_leave_request_details` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `leave_request_id` bigint(20) UNSIGNED NOT NULL,
  `leave_approval_status_id` bigint(20) UNSIGNED NOT NULL,
  `workingday_status` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `f_year` smallint(6) NOT NULL,
  `leave_date` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_request_id` (`leave_request_id`),
  KEY `user_id` (`user_id`),
  KEY `user_fyear_leave` (`user_id`,`f_year`,`leave_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_hr_work_exp`
--

DROP TABLE IF EXISTS `wp_erp_hr_work_exp`;
CREATE TABLE IF NOT EXISTS `wp_erp_hr_work_exp` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `company_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_peoplemeta`
--

DROP TABLE IF EXISTS `wp_erp_peoplemeta`;
CREATE TABLE IF NOT EXISTS `wp_erp_peoplemeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `erp_people_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `erp_people_id` (`erp_people_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_peoples`
--

DROP TABLE IF EXISTS `wp_erp_peoples`;
CREATE TABLE IF NOT EXISTS `wp_erp_peoples` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT 0,
  `first_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `life_stage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_owner` bigint(20) DEFAULT NULL,
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `first_name` (`first_name`),
  KEY `last_name` (`last_name`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_people_types`
--

DROP TABLE IF EXISTS `wp_erp_people_types`;
CREATE TABLE IF NOT EXISTS `wp_erp_people_types` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_erp_people_types`
--

INSERT INTO `wp_erp_people_types` (`id`, `name`) VALUES
(2, 'company'),
(1, 'contact'),
(3, 'customer'),
(5, 'employee'),
(4, 'vendor');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_people_type_relations`
--

DROP TABLE IF EXISTS `wp_erp_people_type_relations`;
CREATE TABLE IF NOT EXISTS `wp_erp_people_type_relations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `people_id` bigint(20) UNSIGNED DEFAULT NULL,
  `people_types_id` int(11) UNSIGNED DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `people_id` (`people_id`),
  KEY `people_types_id` (`people_types_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_erp_user_leaves`
--

DROP TABLE IF EXISTS `wp_erp_user_leaves`;
CREATE TABLE IF NOT EXISTS `wp_erp_user_leaves` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `request_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_hotel_booking_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_hotel_booking_order_itemmeta`;
CREATE TABLE IF NOT EXISTS `wp_hotel_booking_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `hotel_booking_order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  UNIQUE KEY `meta_id` (`meta_id`),
  KEY `hotel_booking_order_item_id` (`hotel_booking_order_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_hotel_booking_order_items`
--

DROP TABLE IF EXISTS `wp_hotel_booking_order_items`;
CREATE TABLE IF NOT EXISTS `wp_hotel_booking_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_parent` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`order_item_id`),
  UNIQUE KEY `order_item_id` (`order_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_hotel_booking_plans`
--

DROP TABLE IF EXISTS `wp_hotel_booking_plans`;
CREATE TABLE IF NOT EXISTS `wp_hotel_booking_plans` (
  `plan_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `room_id` bigint(20) UNSIGNED NOT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `pricing` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`plan_id`),
  UNIQUE KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_hotel_booking_plans`
--

INSERT INTO `wp_hotel_booking_plans` (`plan_id`, `room_id`, `start_time`, `end_time`, `pricing`) VALUES
(1, 18, NULL, NULL, 'a:7:{i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";i:0;s:0:\"\";}'),
(2, 17, NULL, NULL, 'a:7:{i:1;s:3:\"100\";i:2;s:3:\"200\";i:3;s:3:\"300\";i:4;s:3:\"400\";i:5;s:3:\"500\";i:6;s:3:\"600\";i:0;s:3:\"700\";}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_mphb_sync_logs`
--

DROP TABLE IF EXISTS `wp_mphb_sync_logs`;
CREATE TABLE IF NOT EXISTS `wp_mphb_sync_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `queue_id` int(11) NOT NULL,
  `log_status` varchar(30) NOT NULL,
  `log_message` text NOT NULL,
  `log_context` text NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_mphb_sync_queue`
--

DROP TABLE IF EXISTS `wp_mphb_sync_queue`;
CREATE TABLE IF NOT EXISTS `wp_mphb_sync_queue` (
  `queue_id` int(11) NOT NULL AUTO_INCREMENT,
  `queue_name` tinytext NOT NULL,
  `queue_status` varchar(30) NOT NULL,
  PRIMARY KEY (`queue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_mphb_sync_stats`
--

DROP TABLE IF EXISTS `wp_mphb_sync_stats`;
CREATE TABLE IF NOT EXISTS `wp_mphb_sync_stats` (
  `stat_id` int(11) NOT NULL AUTO_INCREMENT,
  `queue_id` int(11) NOT NULL,
  `import_total` int(11) NOT NULL DEFAULT 0,
  `import_succeed` int(11) NOT NULL DEFAULT 0,
  `import_skipped` int(11) NOT NULL DEFAULT 0,
  `import_failed` int(11) NOT NULL DEFAULT 0,
  `clean_total` int(11) NOT NULL DEFAULT 0,
  `clean_done` int(11) NOT NULL DEFAULT 0,
  `clean_skipped` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`stat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_mphb_sync_urls`
--

DROP TABLE IF EXISTS `wp_mphb_sync_urls`;
CREATE TABLE IF NOT EXISTS `wp_mphb_sync_urls` (
  `url_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `sync_id` varchar(32) NOT NULL,
  `calendar_url` varchar(250) NOT NULL,
  PRIMARY KEY (`url_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2387 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8080/hotel01', 'yes'),
(2, 'home', 'http://localhost:8080/hotel01', 'yes'),
(3, 'blogname', 'Moonlight Hotel', 'yes'),
(4, 'blogdescription', 'Thiên đường nghĩ dưỡng', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'nguyenvanhoai1280@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd/m/Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:21:\"flamingo/flamingo.php\";i:3;s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";i:5;s:24:\"wordpress-seo/wp-seo.php\";i:6;s:19:\"wp-smtp/wp-smtp.php\";i:7;s:31:\"wp-statistics/wp-statistics.php\";i:8;s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'hotel-galaxy', 'yes'),
(41, 'stylesheet', 'hotel-galaxy', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:4:{i:1;a:0:{}i:2;a:4:{s:5:\"title\";s:11:\"Dịch vụ\";s:4:\"text\";s:15:\"[mphb_services]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:11:\"Dịch vụ\";s:4:\"text\";s:15:\"[mphb_services]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:21:\"adrotate/adrotate.php\";s:18:\"adrotate_uninstall\";}', 'no'),
(82, 'timezone_string', 'Asia/Bangkok', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '432', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'wp_user_roles', 'a:13:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:86:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:16:\"publish_hb_rooms\";b:1;s:15:\"delete_hb_rooms\";b:1;s:25:\"delete_published_hb_rooms\";b:1;s:23:\"delete_private_hb_rooms\";b:1;s:22:\"delete_others_hb_rooms\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:13:\"edit_hb_rooms\";b:1;s:23:\"edit_published_hb_rooms\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:19:\"publish_hb_bookings\";b:1;s:18:\"delete_hb_bookings\";b:1;s:28:\"delete_published_hb_bookings\";b:1;s:26:\"delete_private_hb_bookings\";b:1;s:25:\"delete_others_hb_bookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:16:\"edit_hb_bookings\";b:1;s:26:\"edit_published_hb_bookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:17:\"manage_hb_booking\";b:1;s:20:\"wpseo_manage_options\";b:1;s:10:\"loco_admin\";b:1;s:18:\"adrotate_ad_manage\";b:1;s:18:\"adrotate_ad_delete\";b:1;s:21:\"adrotate_group_manage\";b:1;s:21:\"adrotate_group_delete\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:18:\"wphb_hotel_manager\";a:2:{s:4:\"name\";s:13:\"Hotel Manager\";s:12:\"capabilities\";a:22:{s:4:\"read\";b:1;s:10:\"edit_posts\";b:1;s:15:\"delete_hb_rooms\";b:1;s:16:\"publish_hb_rooms\";b:1;s:25:\"delete_published_hb_rooms\";b:1;s:23:\"delete_private_hb_rooms\";b:1;s:22:\"delete_others_hb_rooms\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:13:\"edit_hb_rooms\";b:1;s:23:\"edit_published_hb_rooms\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:19:\"publish_hb_bookings\";b:1;s:18:\"delete_hb_bookings\";b:1;s:28:\"delete_published_hb_bookings\";b:1;s:26:\"delete_private_hb_bookings\";b:1;s:25:\"delete_others_hb_bookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:16:\"edit_hb_bookings\";b:1;s:26:\"edit_published_hb_bookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:12:\"upload_files\";b:1;s:17:\"manage_hb_booking\";b:1;}}s:19:\"wphb_booking_editor\";a:2:{s:4:\"name\";s:14:\"Booking Editor\";s:12:\"capabilities\";a:21:{s:4:\"read\";b:1;s:10:\"edit_posts\";b:1;s:16:\"publish_hb_rooms\";b:1;s:15:\"delete_hb_rooms\";b:1;s:25:\"delete_published_hb_rooms\";b:1;s:23:\"delete_private_hb_rooms\";b:1;s:22:\"delete_others_hb_rooms\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:13:\"edit_hb_rooms\";b:1;s:23:\"edit_published_hb_rooms\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:19:\"publish_hb_bookings\";b:1;s:18:\"delete_hb_bookings\";b:1;s:28:\"delete_published_hb_bookings\";b:1;s:26:\"delete_private_hb_bookings\";b:1;s:25:\"delete_others_hb_bookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:16:\"edit_hb_bookings\";b:1;s:26:\"edit_published_hb_bookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:12:\"upload_files\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}s:10:\"translator\";a:2:{s:4:\"name\";s:10:\"Translator\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:10:\"loco_admin\";b:1;}}s:14:\"erp_hr_manager\";a:2:{s:4:\"name\";s:10:\"HR Manager\";s:12:\"capabilities\";a:42:{s:4:\"read\";b:1;s:12:\"upload_files\";b:1;s:13:\"erp_view_list\";b:1;s:17:\"erp_list_employee\";b:1;s:19:\"erp_create_employee\";b:1;s:17:\"erp_view_employee\";b:1;s:17:\"erp_edit_employee\";b:1;s:19:\"erp_delete_employee\";b:1;s:17:\"erp_create_review\";b:1;s:17:\"erp_delete_review\";b:1;s:17:\"erp_manage_review\";b:1;s:22:\"erp_crate_announcement\";b:1;s:21:\"erp_view_announcement\";b:1;s:23:\"erp_manage_announcement\";b:1;s:18:\"erp_manage_jobinfo\";b:1;s:16:\"erp_view_jobinfo\";b:1;s:21:\"erp_manage_department\";b:1;s:22:\"erp_manage_designation\";b:1;s:24:\"erp_leave_create_request\";b:1;s:16:\"erp_leave_manage\";b:1;s:22:\"erp_manage_hr_settings\";b:1;s:21:\"erp_create_experience\";b:1;s:19:\"erp_edit_experience\";b:1;s:19:\"erp_view_experience\";b:1;s:21:\"erp_delete_experience\";b:1;s:20:\"erp_create_education\";b:1;s:18:\"erp_edit_education\";b:1;s:18:\"erp_view_education\";b:1;s:20:\"erp_delete_education\";b:1;s:17:\"erp_can_terminate\";b:1;s:20:\"erp_create_dependent\";b:1;s:18:\"erp_edit_dependent\";b:1;s:18:\"erp_view_dependent\";b:1;s:20:\"erp_delete_dependent\";b:1;s:19:\"erp_create_document\";b:1;s:17:\"erp_edit_document\";b:1;s:17:\"erp_view_document\";b:1;s:19:\"erp_delete_document\";b:1;s:21:\"erp_create_attendance\";b:1;s:19:\"erp_edit_attendance\";b:1;s:19:\"erp_view_attendance\";b:1;s:21:\"erp_delete_attendance\";b:1;}}s:8:\"employee\";a:2:{s:4:\"name\";s:8:\"Employee\";s:12:\"capabilities\";a:26:{s:4:\"read\";b:1;s:12:\"upload_files\";b:1;s:13:\"erp_view_list\";b:1;s:17:\"erp_list_employee\";b:1;s:17:\"erp_view_employee\";b:1;s:17:\"erp_edit_employee\";b:1;s:16:\"erp_view_jobinfo\";b:1;s:24:\"erp_leave_create_request\";b:1;s:21:\"erp_view_announcement\";b:1;s:21:\"erp_create_experience\";b:1;s:19:\"erp_edit_experience\";b:1;s:19:\"erp_view_experience\";b:1;s:21:\"erp_delete_experience\";b:1;s:20:\"erp_create_education\";b:1;s:18:\"erp_edit_education\";b:1;s:18:\"erp_view_education\";b:1;s:20:\"erp_delete_education\";b:1;s:20:\"erp_create_dependent\";b:1;s:18:\"erp_edit_dependent\";b:1;s:18:\"erp_view_dependent\";b:1;s:20:\"erp_delete_dependent\";b:1;s:19:\"erp_create_document\";b:1;s:17:\"erp_edit_document\";b:1;s:17:\"erp_view_document\";b:1;s:19:\"erp_delete_document\";b:1;s:19:\"erp_view_attendance\";b:1;}}s:14:\"erp_ac_manager\";a:2:{s:4:\"name\";s:18:\"Accounting Manager\";s:12:\"capabilities\";a:43:{s:4:\"read\";b:1;s:21:\"erp_ac_view_dashboard\";b:1;s:20:\"erp_ac_view_customer\";b:1;s:27:\"erp_ac_view_single_customer\";b:1;s:27:\"erp_ac_view_other_customers\";b:1;s:22:\"erp_ac_create_customer\";b:1;s:20:\"erp_ac_edit_customer\";b:1;s:27:\"erp_ac_edit_other_customers\";b:1;s:22:\"erp_ac_delete_customer\";b:1;s:29:\"erp_ac_delete_other_customers\";b:1;s:18:\"erp_ac_view_vendor\";b:1;s:25:\"erp_ac_view_other_vendors\";b:1;s:20:\"erp_ac_create_vendor\";b:1;s:18:\"erp_ac_edit_vendor\";b:1;s:25:\"erp_ac_edit_other_vendors\";b:1;s:20:\"erp_ac_delete_vendor\";b:1;s:27:\"erp_ac_delete_other_vendors\";b:1;s:16:\"erp_ac_view_sale\";b:1;s:25:\"erp_ac_view_single_vendor\";b:1;s:23:\"erp_ac_view_other_sales\";b:1;s:25:\"erp_ac_view_sales_summary\";b:1;s:27:\"erp_ac_create_sales_payment\";b:1;s:28:\"erp_ac_publish_sales_payment\";b:1;s:27:\"erp_ac_create_sales_invoice\";b:1;s:28:\"erp_ac_publish_sales_invoice\";b:1;s:19:\"erp_ac_view_expense\";b:1;s:26:\"erp_ac_view_other_expenses\";b:1;s:28:\"erp_ac_view_expenses_summary\";b:1;s:30:\"erp_ac_create_expenses_voucher\";b:1;s:31:\"erp_ac_publish_expenses_voucher\";b:1;s:29:\"erp_ac_create_expenses_credit\";b:1;s:30:\"erp_ac_publish_expenses_credit\";b:1;s:25:\"erp_ac_view_account_lists\";b:1;s:26:\"erp_ac_view_single_account\";b:1;s:21:\"erp_ac_create_account\";b:1;s:19:\"erp_ac_edit_account\";b:1;s:21:\"erp_ac_delete_account\";b:1;s:25:\"erp_ac_view_bank_accounts\";b:1;s:27:\"erp_ac_create_bank_transfer\";b:1;s:19:\"erp_ac_view_journal\";b:1;s:26:\"erp_ac_view_other_journals\";b:1;s:21:\"erp_ac_create_journal\";b:1;s:19:\"erp_ac_view_reports\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:3:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}i:3;a:3:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;s:9:\"show_date\";b:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"sidebar-primary\";a:3:{i:0;s:25:\"mphb_title_rooms_widget-3\";i:1;s:6:\"text-3\";i:2;s:14:\"recent-posts-2\";}s:13:\"home-services\";a:4:{i:0;s:29:\"hotel_galaxy_service_widget-3\";i:1;s:29:\"hotel_galaxy_service_widget-6\";i:2;s:29:\"hotel_galaxy_service_widget-5\";i:3;s:29:\"hotel_galaxy_service_widget-4\";}s:10:\"home-rooms\";a:1:{i:0;s:19:\"mphb_rooms_widget-2\";}s:18:\"footer-widget-area\";a:4:{i:0;s:25:\"mphb_title_rooms_widget-2\";i:1;s:6:\"text-2\";i:2;s:14:\"recent-posts-3\";i:3;s:33:\"mphb_search_availability_widget-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'cron', 'a:12:{i:1593327008;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1593329642;a:1:{s:34:\"mphb_wp_session_garbage_collection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1593330666;a:1:{s:28:\"wp_statistics_add_visit_hook\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1593352208;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1593352209;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1593352213;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1593395404;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1593395425;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1593395430;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1593396182;a:1:{s:23:\"flamingo_daily_cron_job\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1593402901;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'recovery_keys', 'a:0:{}', 'yes'),
(114, 'theme_mods_twentynineteen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567753747;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:3:{i:0;s:27:\"hb_widget_lastest_reviews-2\";i:1;s:18:\"hb_widget_search-2\";i:2;s:16:\"hb_widget_cart-2\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:0:{}}', 'yes'),
(128, 'can_compress_scripts', '1', 'no'),
(142, 'widget_di_business_social_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(145, 'widget_di-business-widget-recent-posts-thumb', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(148, 'theme_mods_hotel-dream', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567736000;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:12:\"sidebar_page\";a:0:{}s:14:\"sidebar_header\";a:0:{}s:19:\"sidebar_header_left\";a:0:{}}}s:18:\"nav_menu_locations\";a:0:{}}', 'yes'),
(161, 'current_theme', 'Hotel Galaxy', 'yes'),
(162, 'theme_switched', '', 'yes'),
(163, 'theme_switched_via_customizer', '', 'yes'),
(164, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(166, 'theme_mods_bistro-lite', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567753872;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:3:{i:0;s:27:\"hb_widget_lastest_reviews-2\";i:1;s:18:\"hb_widget_search-2\";i:2;s:16:\"hb_widget_cart-2\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:19:\"header-right-widget\";a:0:{}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(176, 'theme_mods_hotel-booking', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567736203;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"sidebar-primary\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"home-services\";a:0:{}s:18:\"footer-widget-area\";a:0:{}}}}', 'yes'),
(177, 'widget_hotel_galaxy_service_widget', 'a:5:{i:3;a:7:{s:4:\"icon\";s:10:\"fa fa-beer\";s:10:\"icon_color\";s:0:\"\";s:5:\"title\";s:3:\"Bar\";s:9:\"title_url\";s:42:\"http://localhost:8080/hotel01/service/bar/\";s:4:\"desc\";s:457:\"Không gian mở trên Sirius Bar là một địa điểm lý tưởng để vùa thưởng thức một ly Coctail vừa thư giãn và ngắm nhìn khung cảnh thành phố một cách êm đềm nhất. Tạm xa rời những khung cảnh nhộn nhịp, ồn ào của thành phố, Sirius Bar là nơi để bạn có thể thư giãn đầu ốc vài giây phút, lắng động lại và cảm nhận cuộc sống thật thú vị và thoải mái.\";s:9:\"charcount\";i:200;s:10:\"btn_target\";i:0;}i:4;a:7:{s:4:\"icon\";s:21:\"fab fa-cc-diners-club\";s:10:\"icon_color\";s:0:\"\";s:5:\"title\";s:15:\"Vip Dining Room\";s:9:\"title_url\";s:54:\"http://localhost:8080/hotel01/service/vip-dining-room/\";s:4:\"desc\";s:232:\"Các món ăn theo phong cách Âu và A sẽ luôn làm hài lòng tất cả các vị thực khách. Thật tuyệt với khi vừa thưởng thức các món ăn ngon và ngắm nhìn sông Hương một cách êm đềm nhất.\";s:9:\"charcount\";i:200;s:10:\"btn_target\";i:0;}i:5;a:7:{s:4:\"icon\";s:10:\"fas fa-spa\";s:10:\"icon_color\";s:0:\"\";s:5:\"title\";s:13:\"Spa Moonshine\";s:9:\"title_url\";s:52:\"http://localhost:8080/hotel01/service/spa-moonshine/\";s:4:\"desc\";s:331:\"Moonshine Spa với những phương pháp trị liệu phong phú, các liệu pháp chăm sóc toàn thân, chăm sóc sắc đẹp đảm bảo mang lại cho bạn cảm giác tuyệt vời nhất. Chúng tôi-với đội ngũ chuyên viên bài bản rất vui để đưa bạn đắm mình trong các cung bậc thư giãn.\";s:9:\"charcount\";i:200;s:10:\"btn_target\";i:0;}i:6;a:7:{s:4:\"icon\";s:14:\"fa fa-utensils\";s:10:\"icon_color\";s:0:\"\";s:5:\"title\";s:16:\"Nhà hàng Venus\";s:9:\"title_url\";s:53:\"http://localhost:8080/hotel01/service/nha-hang-venus/\";s:4:\"desc\";s:341:\"Nhà hàng Venus là một địa điểm lý tưởng để vừa thưởng thức các món ăn ngon và ngắm nhìn sông Hương một cách nhẹ nhàng nhưng đầy thú vị. Với một không gian đẹp, các món ẩm thực Âu & Á phong phú, sẽ làm hài long tất cả các vị khách khi đã đặt chân tới đây.\";s:9:\"charcount\";i:200;s:10:\"btn_target\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(178, 'hotel_galaxy_review_data', 'a:2:{s:4:\"time\";i:1568084655;s:9:\"dismissed\";b:1;}', 'yes'),
(180, 'theme_mods_hotel-galaxy', 'a:19:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:9;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567743527;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"sidebar-primary\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"home-services\";a:3:{i:0;s:27:\"hb_widget_lastest_reviews-2\";i:1;s:18:\"hb_widget_search-2\";i:2;s:16:\"hb_widget_cart-2\";}s:18:\"footer-widget-area\";a:0:{}}}s:13:\"Page_slider_1\";i:412;s:13:\"Page_slider_2\";i:410;s:13:\"Page_slider_3\";i:408;s:26:\"social_messenger_minimized\";s:6:\"enable\";s:23:\"social_messenger_phones\";s:6:\"enable\";s:25:\"social_messenger_language\";s:5:\"vi_VN\";s:31:\"social_messenger_hello_unlogged\";s:5:\"hello\";s:21:\"social_messenger_page\";s:15:\"100005752721546\";s:22:\"social_messenger_pages\";s:1:\"0\";s:23:\"social_messenger_enable\";s:6:\"enable\";s:13:\"Page_slider_4\";i:414;s:13:\"Page_slider_5\";i:401;s:11:\"custom_logo\";i:433;s:12:\"Page_about_1\";i:241;s:10:\"Page_about\";i:241;}', 'yes'),
(185, 'hotel_galaxy_option', 'a:33:{s:8:\"room_cat\";s:1:\"1\";s:7:\"address\";s:39:\"20 Phạm Ngũ Lão, thành phố Huế\";s:16:\"reservation_line\";s:18:\"+84 (0)234 3979797\";s:13:\"facebook_link\";s:8:\"http://c\";s:12:\"twitter_link\";s:8:\"http://c\";s:10:\"skyup_link\";s:8:\"http://c\";s:15:\"googleplus_link\";s:8:\"http://c\";s:13:\"room_sec_show\";s:0:\"\";s:12:\"service_show\";s:1:\"1\";s:17:\"room_sec_position\";s:5:\"R_top\";s:13:\"service_title\";s:11:\"Dịch vụ\";s:11:\"blog_latest\";s:1:\"5\";s:21:\"slider_smartphone_res\";s:0:\"\";s:11:\"google_font\";s:4:\"Jura\";s:11:\"font_family\";s:16:\"Jura, sans-serif\";s:14:\"shortcode_echo\";s:46:\"[contact-form-7 id=\"143\" title=\"Form contact\"]\";s:22:\"footer_collout_title_1\";s:10:\"Phòng Gym\";s:21:\"footer_collout_icon_1\";s:15:\"fas fa-dumbbell\";s:22:\"footer_collout_title_2\";s:12:\"Điều hòa\";s:21:\"footer_collout_icon_2\";s:25:\"fa fa-thermometer-quarter\";s:22:\"footer_collout_title_3\";s:4:\"Tivi\";s:21:\"footer_collout_icon_3\";s:8:\"fa fa-tv\";s:22:\"footer_collout_title_4\";s:14:\"Bãi đổ oto\";s:21:\"footer_collout_icon_4\";s:9:\"fa fa-car\";s:22:\"hotel_galaxy_copyright\";s:14:\"Copyright 2020\";s:12:\"developed_by\";s:0:\"\";s:30:\"hotel_galaxy_developed_by_text\";s:11:\"- Moonlight\";s:14:\"slider_sec_btn\";s:0:\"\";s:19:\"service_rooms_title\";s:6:\"Phòng\";s:10:\"blog_title\";s:9:\"Tin tức\";s:15:\"shortcode_title\";s:10:\"Liên hệ\";s:10:\"about_show\";s:1:\"1\";s:11:\"about_title\";s:12:\"khách sạn\";}', 'yes'),
(190, 'recently_activated', 'a:0:{}', 'yes'),
(191, 'booking_activation_process', 'Off', 'yes'),
(192, 'booking_admin_cal_count', '2', 'yes'),
(193, 'booking_skin', '/css/skins/traditional.css', 'yes'),
(194, 'booking_num_per_page', '10', 'yes'),
(195, 'booking_sort_order', '', 'yes'),
(196, 'booking_default_toolbar_tab', 'filter', 'yes'),
(197, 'booking_listing_default_view_mode', 'vm_calendar', 'yes'),
(198, 'booking_view_days_num', '90', 'yes'),
(199, 'booking_timeline_load', 'timeline_v2_flex', 'yes'),
(200, 'booking_max_monthes_in_calendar', '1y', 'yes'),
(201, 'booking_client_cal_count', '1', 'yes'),
(202, 'booking_start_day_weeek', '0', 'yes'),
(203, 'booking_title_after_reservation', 'Thank you for your online booking.  We will send confirmation of your booking as soon as possible.', 'yes'),
(204, 'booking_title_after_reservation_time', '7000', 'yes'),
(205, 'booking_type_of_thank_you_message', 'message', 'yes'),
(206, 'booking_thank_you_page_URL', '/thank-you', 'yes'),
(207, 'booking_is_use_autofill_4_logged_user', 'Off', 'yes'),
(208, 'booking_date_format', 'F j, Y', 'yes'),
(209, 'booking_date_view_type', 'short', 'yes'),
(210, 'booking_is_delete_if_deactive', 'Off', 'yes'),
(211, 'booking_dif_colors_approval_pending', 'On', 'yes'),
(212, 'booking_is_use_hints_at_admin_panel', 'On', 'yes'),
(213, 'booking_is_not_load_bs_script_in_client', 'Off', 'yes'),
(214, 'booking_is_not_load_bs_script_in_admin', 'Off', 'yes'),
(215, 'booking_is_load_js_css_on_specific_pages', 'Off', 'yes'),
(216, 'booking_is_show_system_debug_log', 'Off', 'yes'),
(217, 'booking_pages_for_load_js_css', '', 'yes'),
(218, 'booking_type_of_day_selections', 'multiple', 'yes'),
(219, 'booking_timeslot_day_bg_as_available', 'On', 'yes'),
(220, 'booking_form_is_using_bs_css', 'On', 'yes'),
(221, 'booking_form_format_type', 'vertical', 'yes'),
(222, 'booking_form_field_active1', 'On', 'yes'),
(223, 'booking_form_field_required1', 'On', 'yes'),
(224, 'booking_form_field_label1', 'First Name', 'yes'),
(225, 'booking_form_field_active2', 'On', 'yes'),
(226, 'booking_form_field_required2', 'On', 'yes'),
(227, 'booking_form_field_label2', 'Last Name', 'yes'),
(228, 'booking_form_field_active3', 'On', 'yes'),
(229, 'booking_form_field_required3', 'On', 'yes'),
(230, 'booking_form_field_label3', 'Email', 'yes'),
(231, 'booking_form_field_active4', 'On', 'yes'),
(232, 'booking_form_field_required4', 'Off', 'yes'),
(233, 'booking_form_field_label4', 'Phone', 'yes'),
(234, 'booking_form_field_active5', 'On', 'yes'),
(235, 'booking_form_field_required5', 'Off', 'yes'),
(236, 'booking_form_field_label5', 'Details', 'yes'),
(237, 'booking_form_field_active6', 'Off', 'yes'),
(238, 'booking_form_field_required6', 'Off', 'yes'),
(239, 'booking_form_field_label6', 'Visitors', 'yes'),
(240, 'booking_form_field_values6', '1\n2\n3\n4', 'yes'),
(241, 'booking_is_days_always_available', 'Off', 'yes'),
(242, 'booking_is_show_pending_days_as_available', 'Off', 'yes'),
(243, 'booking_check_on_server_if_dates_free', 'Off', 'yes'),
(244, 'booking_unavailable_days_num_from_today', '0', 'yes'),
(245, 'booking_unavailable_day0', 'Off', 'yes'),
(246, 'booking_unavailable_day1', 'Off', 'yes'),
(247, 'booking_unavailable_day2', 'Off', 'yes'),
(248, 'booking_unavailable_day3', 'Off', 'yes'),
(249, 'booking_unavailable_day4', 'Off', 'yes'),
(250, 'booking_unavailable_day5', 'Off', 'yes'),
(251, 'booking_unavailable_day6', 'Off', 'yes'),
(252, 'booking_menu_position', 'top', 'yes'),
(253, 'booking_user_role_booking', 'editor', 'yes'),
(254, 'booking_user_role_addbooking', 'editor', 'yes'),
(255, 'booking_user_role_resources', 'editor', 'yes'),
(256, 'booking_user_role_settings', 'administrator', 'yes'),
(257, 'booking_is_email_reservation_adress', 'On', 'yes'),
(258, 'booking_email_reservation_adress', '&quot;Booking system&quot; &lt;nguyenvanhoai1280@gmail.com&gt;', 'yes'),
(259, 'booking_email_reservation_from_adress', '[visitoremail]', 'yes'),
(260, 'booking_email_reservation_subject', 'New booking', 'yes'),
(261, 'booking_email_reservation_content', 'You need to approve a new booking [bookingtype] for: [dates]&lt;br/&gt;&lt;br/&gt; Person detail information:&lt;br/&gt; [content]&lt;br/&gt;&lt;br/&gt; Currently a new booking is waiting for approval. Please visit the moderation panel [moderatelink]&lt;br/&gt;&lt;br/&gt;Thank you, Hotel.com&lt;br/&gt;[siteurl]', 'yes'),
(262, 'booking_is_email_newbookingbyperson_adress', 'Off', 'yes'),
(263, 'booking_email_newbookingbyperson_adress', '&quot;Booking system&quot; &lt;nguyenvanhoai1280@gmail.com&gt;', 'yes'),
(264, 'booking_email_newbookingbyperson_subject', 'New booking', 'yes'),
(265, 'booking_email_newbookingbyperson_content', 'Your reservation [bookingtype] for: [dates] is processing now! We will send confirmation by email. &lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt; Thank you, Hotel.com&lt;br/&gt;[siteurl]', 'yes'),
(266, 'booking_is_email_approval_adress', 'On', 'yes'),
(267, 'booking_is_email_approval_send_copy_to_admin', 'Off', 'yes'),
(268, 'booking_email_approval_adress', '&quot;Booking system&quot; &lt;nguyenvanhoai1280@gmail.com&gt;', 'yes'),
(269, 'booking_email_approval_subject', 'Your booking has been approved', 'yes'),
(270, 'booking_email_approval_content', 'Your booking [bookingtype] for: [dates] has been approved.&lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt;Thank you, Hotel.com&lt;br/&gt;[siteurl]', 'yes'),
(271, 'booking_is_email_deny_adress', 'On', 'yes'),
(272, 'booking_is_email_deny_send_copy_to_admin', 'Off', 'yes'),
(273, 'booking_email_deny_adress', '&quot;Booking system&quot; &lt;nguyenvanhoai1280@gmail.com&gt;', 'yes'),
(274, 'booking_email_deny_subject', 'Your booking has been declined', 'yes'),
(275, 'booking_email_deny_content', 'Your booking [bookingtype] for: [dates] has been  canceled. &lt;br/&gt;[denyreason]&lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt;Thank you, Hotel.com&lt;br/&gt;[siteurl]', 'yes'),
(276, 'booking_widget_title', 'Booking form', 'yes'),
(277, 'booking_widget_show', 'booking_form', 'yes'),
(278, 'booking_widget_type', '1', 'yes'),
(279, 'booking_widget_calendar_count', '1', 'yes'),
(280, 'booking_widget_last_field', '', 'yes'),
(281, 'booking_wpdev_copyright_adminpanel', 'On', 'yes'),
(282, 'booking_is_show_powered_by_notice', 'On', 'yes'),
(283, 'booking_is_use_captcha', 'Off', 'yes'),
(284, 'booking_is_show_legend', 'Off', 'yes'),
(285, 'booking_legend_is_show_item_available', 'On', 'yes'),
(286, 'booking_legend_text_for_item_available', 'Available', 'yes'),
(287, 'booking_legend_is_show_item_pending', 'On', 'yes'),
(288, 'booking_legend_text_for_item_pending', 'Pending', 'yes'),
(289, 'booking_legend_is_show_item_approved', 'On', 'yes'),
(290, 'booking_legend_text_for_item_approved', 'Booked', 'yes'),
(291, 'booking_legend_is_show_numbers', 'Off', 'yes'),
(292, 'booking_email_new_admin', 'a:15:{s:7:\"enabled\";s:2:\"On\";s:2:\"to\";s:27:\"nguyenvanhoai1280@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:11:\"New booking\";s:7:\"content\";s:264:\"You need to approve a new booking [bookingtype] for: [dates]<br/><br/> Person detail information:<br/> [content]<br/><br/> Currently a new booking is waiting for approval. Please visit the moderation panel [moderatelink]<br/><br/>Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(293, 'booking_email_new_visitor', 'a:13:{s:7:\"enabled\";s:2:\"On\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:11:\"New booking\";s:7:\"content\";s:163:\"Your reservation [bookingtype] for: [dates] is processing now! We will send confirmation by email. <br/><br/>[content]<br/><br/> Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(294, 'booking_email_approved', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:27:\"nguyenvanhoai1280@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been approved\";s:7:\"content\";s:121:\"Your booking [bookingtype] for: [dates] has been approved.<br/><br/>[content]<br/><br/>Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(295, 'booking_email_deleted', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:27:\"nguyenvanhoai1280@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:140:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(296, 'booking_email_deny', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:27:\"nguyenvanhoai1280@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:140:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(297, 'booking_email_trash', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:27:\"nguyenvanhoai1280@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:140:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, Hotel.com<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(298, 'booking_form_structure_type', 'vertical', 'yes'),
(299, 'booking_menu_go_pro', 'show', 'yes'),
(300, 'booking_ics_force_import', 'Off', 'yes'),
(301, 'booking_ics_force_trash_before_import', 'Off', 'yes'),
(302, 'booking_form', '<div class=\"wpbc_booking_form_structure wpbc_vertical\">\n  <div class=\"wpbc_structure_calendar\">\n    [calendar]\n  </div>\n  <div class=\"wpbc_structure_form\">\n     <p>First Name*:<br />[text* name]</p>\n     <p>Last Name*:<br />[text* secondname]</p>\n     <p>Email*:<br />[email* email]</p>\n     <p>Phone:<br />[text phone]</p>\n     <p>Details:<br />[textarea details]</p>\n     <p>[captcha]</p>\n     <p>[submit class:btn \"Send\"]</p>\n  </div>\n</div>\n<div class=\"wpbc_booking_form_footer\"></div>', 'yes'),
(303, 'booking_form_show', '<div style=\"text-align:left;word-wrap: break-word;\">\n  <strong>First Name</strong>: <span class=\"fieldvalue\">[name]</span><br/>\n  <strong>Last Name</strong>: <span class=\"fieldvalue\">[secondname]</span><br/>\n  <strong>Email</strong>: <span class=\"fieldvalue\">[email]</span><br/>\n  <strong>Phone</strong>: <span class=\"fieldvalue\">[phone]</span><br/>\n  <strong>Details</strong>: <span class=\"fieldvalue\">[details]</span><br/>\n</div>', 'yes'),
(304, 'booking_form_visual', 'a:9:{i:0;a:2:{s:4:\"type\";s:8:\"calendar\";s:10:\"obligatory\";s:2:\"On\";}i:1;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:4:\"name\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:10:\"First Name\";}i:2;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:10:\"secondname\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:9:\"Last Name\";}i:3;a:6:{s:4:\"type\";s:5:\"email\";s:4:\"name\";s:5:\"email\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:5:\"Email\";}i:4;a:7:{s:4:\"type\";s:6:\"select\";s:4:\"name\";s:8:\"visitors\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:3:\"Off\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:8:\"Visitors\";s:5:\"value\";s:7:\"1\n2\n3\n4\";}i:5;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:5:\"phone\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:5:\"Phone\";}i:6;a:6:{s:4:\"type\";s:8:\"textarea\";s:4:\"name\";s:7:\"details\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:7:\"Details\";}i:7;a:6:{s:4:\"type\";s:7:\"captcha\";s:4:\"name\";s:7:\"captcha\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:3:\"Off\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:0:\"\";}i:8;a:6:{s:4:\"type\";s:6:\"submit\";s:4:\"name\";s:6:\"submit\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:4:\"Send\";}}', 'yes'),
(305, 'booking_gcal_feed', '', 'yes'),
(306, 'booking_gcal_events_from', 'month-start', 'yes'),
(307, 'booking_gcal_events_from_offset', '', 'yes'),
(308, 'booking_gcal_events_from_offset_type', '', 'yes'),
(309, 'booking_gcal_events_until', 'any', 'yes'),
(310, 'booking_gcal_events_until_offset', '', 'yes'),
(311, 'booking_gcal_events_until_offset_type', '', 'yes'),
(312, 'booking_gcal_events_max', '25', 'yes'),
(313, 'booking_gcal_api_key', '', 'yes'),
(314, 'booking_gcal_timezone', '', 'yes'),
(315, 'booking_gcal_is_send_email', 'Off', 'yes'),
(316, 'booking_gcal_auto_import_is_active', 'Off', 'yes'),
(317, 'booking_gcal_auto_import_time', '24', 'yes'),
(318, 'booking_gcal_events_form_fields', 's:101:\"a:3:{s:5:\"title\";s:9:\"text^name\";s:11:\"description\";s:16:\"textarea^details\";s:5:\"where\";s:5:\"text^\";}\";', 'yes'),
(319, 'booking_version_num', '8.6', 'yes'),
(322, 'widget_bookingwidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(323, 'booking_activation_redirect_for_version', '8.6', 'yes'),
(325, 'tp_hotel_booking_single_purchase', '1', 'yes'),
(326, 'tp_hotel_booking_custom_process', '1', 'yes'),
(327, 'tp_hotel_booking_currency', 'USD', 'yes'),
(328, 'tp_hotel_booking_price_currency_position', 'left', 'yes'),
(329, 'tp_hotel_booking_price_thousands_separator', ',', 'yes'),
(330, 'tp_hotel_booking_price_decimals_separator', '.', 'yes'),
(331, 'tp_hotel_booking_price_number_of_decimal', '1', 'yes'),
(332, 'tp_hotel_booking_minimum_booking_day', '1', 'yes'),
(333, 'tp_hotel_booking_tax', '10', 'yes'),
(334, 'tp_hotel_booking_price_including_tax', '1', 'yes'),
(335, 'tp_hotel_booking_price_display', 'min', 'yes'),
(336, 'tp_hotel_booking_advance_payment', '50', 'yes'),
(337, 'tp_hotel_booking_hotel_name', 'Hanoi Daewoo Hotel', 'yes'),
(338, 'tp_hotel_booking_hotel_address', 'Ha Noi', 'yes'),
(339, 'tp_hotel_booking_hotel_city', 'Ha Noi', 'yes'),
(340, 'tp_hotel_booking_hotel_state', 'Hanoi Daewoo Hotel', 'yes'),
(341, 'tp_hotel_booking_hotel_country', 'Vietnam', 'yes'),
(342, 'tp_hotel_booking_hotel_zip_code', '10000', 'yes'),
(343, 'tp_hotel_booking_hotel_phone_number', '', 'yes'),
(344, 'tp_hotel_booking_hotel_fax_number', '', 'yes'),
(345, 'tp_hotel_booking_hotel_email_address', '', 'yes'),
(346, 'tp_hotel_booking_email_general_from_name', 'Hotel.com', 'yes'),
(347, 'tp_hotel_booking_email_general_from_email', 'nguyenvanhoai1280@gmail.com', 'yes'),
(348, 'tp_hotel_booking_email_general_subject', 'Reservation', 'yes'),
(349, 'tp_hotel_booking_cancel_payment', '12', 'yes'),
(350, 'tp_hotel_booking_guest_checkout', '1', 'yes'),
(351, 'tp_hotel_booking_catalog_number_column', '4', 'yes'),
(352, 'tp_hotel_booking_posts_per_page', '8', 'yes'),
(353, 'tp_hotel_booking_catalog_image', 'a:2:{s:5:\"width\";i:270;s:6:\"height\";i:270;}', 'yes'),
(354, 'tp_hotel_booking_catalog_display_rating', '1', 'yes'),
(355, 'tp_hotel_booking_room_image_gallery', 'a:2:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;}', 'yes'),
(356, 'tp_hotel_booking_room_thumbnail', 'a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}', 'yes'),
(357, 'tp_hotel_booking_display_pricing_plans', '1', 'yes'),
(358, 'tp_hotel_booking_enable_review_rating', '1', 'yes'),
(359, 'tp_hotel_booking_review_rating_required', '1', 'yes'),
(360, 'tp_hotel_booking_enable_gallery_lightbox', '1', 'yes'),
(361, 'hotel_booking_version', '1.9.8.7', 'yes'),
(364, 'widget_hb_widget_search', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:10:\"show_title\";s:4:\"true\";s:10:\"show_label\";s:4:\"true\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(365, 'widget_hb_widget_carousel', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(366, 'widget_hb_widget_best_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(367, 'widget_hb_widget_lastest_reviews', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";s:1:\"5\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(368, 'widget_hb_widget_cart', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(369, 'hotel_booking_rooms_page_id', '10', 'yes'),
(370, 'tp_hotel_booking_rooms_page_id', '10', 'yes'),
(371, 'hotel_booking_cart_page_id', '11', 'yes'),
(372, 'tp_hotel_booking_cart_page_id', '11', 'yes'),
(373, 'hotel_booking_checkout_page_id', '12', 'yes'),
(374, 'tp_hotel_booking_checkout_page_id', '12', 'yes'),
(375, 'hotel_booking_search_page_id', '13', 'yes'),
(376, 'tp_hotel_booking_search_page_id', '13', 'yes'),
(377, 'hotel_booking_account_page_id', '14', 'yes'),
(378, 'tp_hotel_booking_account_page_id', '14', 'yes'),
(379, 'hotel_booking_terms_page_id', '15', 'yes'),
(380, 'tp_hotel_booking_terms_page_id', '15', 'yes'),
(381, 'hotel_booking_thankyou_page_id', '16', 'yes'),
(382, 'tp_hotel_booking_thankyou_page_id', '16', 'yes'),
(390, 'theme_mods_di-business', 'a:4:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1567754740;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:3:{i:0;s:27:\"hb_widget_lastest_reviews-2\";i:1;s:18:\"hb_widget_search-2\";i:2;s:16:\"hb_widget_cart-2\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:12:\"sidebar_page\";a:0:{}s:14:\"sidebar_header\";a:0:{}s:19:\"sidebar_header_left\";a:0:{}}}s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(405, 'mphb_db_version', '3.8.2', 'yes'),
(406, 'mphb_registered_attributes', 'a:0:{}', 'yes'),
(407, 'widget_mphb_rooms_widget', 'a:2:{i:2;a:8:{s:5:\"title\";s:0:\"\";s:13:\"room_type_ids\";a:6:{i:0;s:3:\"304\";i:1;s:3:\"317\";i:2;s:3:\"333\";i:3;s:3:\"348\";i:4;s:3:\"364\";i:5;s:3:\"373\";}s:10:\"show_title\";b:1;s:19:\"show_featured_image\";b:1;s:12:\"show_excerpt\";s:0:\"\";s:12:\"show_details\";s:0:\"\";s:10:\"show_price\";s:0:\"\";s:16:\"show_book_button\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(408, 'widget_mphb_search_availability_widget', 'a:2:{i:2;a:6:{s:5:\"title\";s:11:\"Tìm phòng\";s:6:\"adults\";s:1:\"1\";s:8:\"children\";s:1:\"0\";s:13:\"check_in_date\";s:0:\"\";s:14:\"check_out_date\";s:0:\"\";s:10:\"attributes\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(409, 'mphb_search_results_page', '23', 'yes'),
(410, 'mphb_checkout_page', '24', 'yes'),
(411, 'mphb_booking_confirmation_page', '25', 'yes'),
(412, 'mphb_user_cancel_redirect_page', '26', 'yes'),
(413, 'mphb_payment_success_page', '27', 'yes'),
(414, 'mphb_payment_failed_page', '28', 'yes'),
(415, 'mphb_wizard_passed', '1', 'yes'),
(419, 'WPLANG', 'vi', 'yes'),
(420, 'new_admin_email', 'nguyenvanhoai1280@gmail.com', 'yes'),
(423, 'mphb_terms_and_conditions_page', '', 'yes'),
(424, 'mphb_confirmation_mode', 'manual', 'yes'),
(425, 'mphb_user_approval_time', '20', 'yes'),
(426, 'mphb_require_country', '1', 'yes'),
(427, 'mphb_require_full_address', '0', 'yes'),
(428, 'mphb_default_country', 'VN', 'yes'),
(429, 'mphb_unfold_price_breakdown', '0', 'yes'),
(430, 'mphb_user_can_cancel_booking', '1', 'yes'),
(431, 'mphb_search_max_adults', '30', 'yes'),
(432, 'mphb_search_max_children', '10', 'yes'),
(433, 'mphb_children_age', '', 'yes'),
(434, 'mphb_direct_booking', '0', 'yes'),
(435, 'mphb_guest_management', 'allow-all', 'yes'),
(436, 'mphb_hide_guests_on_search', '0', 'yes'),
(437, 'mphb_square_unit', 'm2', 'yes'),
(438, 'mphb_currency_symbol', 'VND', 'yes'),
(439, 'mphb_currency_position', 'after_space', 'yes'),
(440, 'mphb_datepicker_date_format', 'd/m/Y', 'yes'),
(441, 'mphb_check_out_time', '12:00', 'yes'),
(442, 'mphb_check_in_time', '12:00', 'yes'),
(443, 'mphb_bed_types', 'a:3:{i:0;a:1:{s:4:\"type\";s:26:\"Giường đôi Queen-size\";}i:1;a:1:{s:4:\"type\";s:25:\"Giường đôi King-size\";}i:2;a:1:{s:4:\"type\";s:25:\"Giường đơn Twin-size\";}}', 'yes'),
(444, 'mphb_average_price_period', '7', 'yes'),
(445, 'mphb_enable_recommendation', '1', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(446, 'mphb_enable_coupons', '0', 'yes'),
(447, 'mphb_template_mode', 'theme', 'yes'),
(448, 'mphb_checkout_text', '', 'yes'),
(449, 'mphb_booking_disabled', '0', 'yes'),
(450, 'mphb_disabled_booking_text', '', 'yes'),
(451, 'mphb_single_room_type_gallery_use_magnific', '1', 'yes'),
(452, 'mphb_datepicker_theme', '', 'yes'),
(453, 'mphb_ical_export_blocks', '0', 'yes'),
(454, 'mphb_ical_dont_export_imports', '1', 'yes'),
(455, 'mphb_use_block_editor_for_room_types', '0', 'yes'),
(456, 'mphb_use_block_editor_for_services', '0', 'yes'),
(459, 'mphb_room_type_category_children', 'a:0:{}', 'yes'),
(489, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(533, 'wpcf7', 'a:6:{s:7:\"version\";s:5:\"5.1.4\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1567828000;s:7:\"version\";s:5:\"5.1.4\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}s:23:\"recaptcha_v2_v3_warning\";b:0;s:9:\"recaptcha\";a:1:{s:40:\"6LeG9LUUAAAAAE41PXYbMpC5QYrh-VNVHISwvSeR\";s:40:\"6LeG9LUUAAAAALOTQ0qgUwEwi74_WMpxOyegz4al\";}s:15:\"iqfix_recaptcha\";i:2;s:22:\"iqfix_recaptcha_source\";s:10:\"google.com\";}', 'yes'),
(536, 'recovery_mode_email_last_sent', '1572418608', 'yes'),
(543, 'core_updater.lock', '1568077252', 'no'),
(580, 'wpseo', 'a:20:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:4:\"12.0\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1568087695;s:13:\"myyoast-oauth\";b:0;}', 'yes'),
(581, 'wpseo_titles', 'a:109:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:2:\"»\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:1;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";s:1:\"0\";s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";s:1:\"0\";s:18:\"title-tax-category\";s:44:\"%%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:20:\"title-mphb_room_type\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:23:\"metadesc-mphb_room_type\";s:0:\"\";s:22:\"noindex-mphb_room_type\";b:0;s:23:\"showdate-mphb_room_type\";b:0;s:33:\"display-metabox-pt-mphb_room_type\";b:1;s:33:\"post_types-mphb_room_type-maintax\";i:0;s:30:\"title-ptarchive-mphb_room_type\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:33:\"metadesc-ptarchive-mphb_room_type\";s:0:\"\";s:32:\"bctitle-ptarchive-mphb_room_type\";s:0:\"\";s:32:\"noindex-ptarchive-mphb_room_type\";b:0;s:33:\"title-tax-mphb_room_type_category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:36:\"metadesc-tax-mphb_room_type_category\";s:0:\"\";s:43:\"display-metabox-tax-mphb_room_type_category\";b:1;s:35:\"noindex-tax-mphb_room_type_category\";b:0;s:41:\"taxonomy-mphb_room_type_category-ptparent\";i:0;s:28:\"title-tax-mphb_room_type_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:31:\"metadesc-tax-mphb_room_type_tag\";s:0:\"\";s:38:\"display-metabox-tax-mphb_room_type_tag\";b:1;s:30:\"noindex-tax-mphb_room_type_tag\";b:0;s:36:\"taxonomy-mphb_room_type_tag-ptparent\";i:0;s:33:\"title-tax-mphb_room_type_facility\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:36:\"metadesc-tax-mphb_room_type_facility\";s:0:\"\";s:43:\"display-metabox-tax-mphb_room_type_facility\";b:1;s:35:\"noindex-tax-mphb_room_type_facility\";b:0;s:41:\"taxonomy-mphb_room_type_facility-ptparent\";i:0;s:23:\"title-mphb_room_service\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-mphb_room_service\";s:0:\"\";s:25:\"noindex-mphb_room_service\";b:0;s:26:\"showdate-mphb_room_service\";b:0;s:36:\"display-metabox-pt-mphb_room_service\";b:1;s:36:\"post_types-mphb_room_service-maintax\";s:1:\"0\";s:33:\"title-ptarchive-mphb_room_service\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:36:\"metadesc-ptarchive-mphb_room_service\";s:0:\"\";s:35:\"bctitle-ptarchive-mphb_room_service\";s:0:\"\";s:35:\"noindex-ptarchive-mphb_room_service\";b:0;s:26:\"taxonomy-category-ptparent\";s:1:\"0\";s:26:\"taxonomy-post_tag-ptparent\";s:1:\"0\";s:29:\"taxonomy-post_format-ptparent\";s:1:\"0\";}', 'yes'),
(582, 'wpseo_social', 'a:19:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}', 'yes'),
(584, '_transient_timeout_wpseo_link_table_inaccessible', '1599623701', 'no'),
(585, '_transient_wpseo_link_table_inaccessible', '0', 'no'),
(586, '_transient_timeout_wpseo_meta_table_inaccessible', '1599623701', 'no'),
(587, '_transient_wpseo_meta_table_inaccessible', '0', 'no'),
(760, 'loco_settings', 'a:4:{s:1:\"c\";s:18:\"Loco_data_Settings\";s:1:\"v\";i:0;s:1:\"d\";a:14:{s:7:\"version\";s:5:\"2.3.0\";s:8:\"gen_hash\";b:0;s:9:\"use_fuzzy\";b:1;s:11:\"num_backups\";i:1;s:9:\"pot_alias\";a:3:{i:0;s:10:\"default.po\";i:1;s:8:\"en_US.po\";i:2;s:5:\"en.po\";}s:9:\"php_alias\";a:2:{i:0;s:3:\"php\";i:1;s:4:\"twig\";}s:9:\"jsx_alias\";a:0:{}s:10:\"fs_persist\";b:0;s:10:\"fs_protect\";i:1;s:12:\"max_php_size\";s:4:\"100K\";s:11:\"po_utf8_bom\";b:0;s:8:\"po_width\";s:2:\"79\";s:10:\"jed_pretty\";b:0;s:10:\"ajax_files\";b:0;}s:1:\"t\";i:1568365371;}', 'yes'),
(819, 'loco_recent', 'a:4:{s:1:\"c\";s:21:\"Loco_data_RecentItems\";s:1:\"v\";i:0;s:1:\"d\";a:1:{s:6:\"bundle\";a:1:{s:63:\"plugin.motopress-hotel-booking-lite/motopress-hotel-booking.php\";i:1568365486;}}s:1:\"t\";i:1568365486;}', 'no'),
(924, 'htcc_plugin_details', 'a:1:{s:7:\"version\";s:3:\"4.2\";}', 'yes'),
(925, 'htcc_options', 'a:13:{s:10:\"fb_page_id\";s:0:\"\";s:9:\"fb_app_id\";s:16:\"2015199145383303\";s:10:\"log_events\";s:2:\"no\";s:11:\"fb_sdk_lang\";s:7:\"English\";s:8:\"fb_color\";s:0:\"\";s:17:\"fb_greeting_login\";s:0:\"\";s:18:\"fb_greeting_logout\";s:0:\"\";s:17:\"list_hideon_pages\";s:0:\"\";s:15:\"list_hideon_cat\";s:0:\"\";s:9:\"shortcode\";s:7:\"chatbot\";s:23:\"greeting_dialog_display\";s:0:\"\";s:21:\"greeting_dialog_delay\";s:0:\"\";s:3:\"ref\";s:0:\"\";}', 'yes'),
(932, 'mobilemonkey_environment', 'O:8:\"stdClass\":6:{s:9:\"fb_app_id\";s:16:\"2015199145383303\";s:12:\"callback_url\";s:55:\"https://api.mobilemonkey.com/incoming_facebook_messages\";s:14:\"ga_tracking_id\";s:14:\"UA-110510132-2\";s:26:\"global_javascript_base_url\";s:23:\"static.mobilemonkey.com\";s:20:\"notification_banners\";a:0:{}s:10:\"bot_widget\";O:8:\"stdClass\":3:{s:3:\"ref\";s:50:\"aae14f21cf3da893f26091100b459242418e61de2c4ea32378\";s:6:\"app_id\";s:16:\"2015199145383303\";s:7:\"page_id\";s:15:\"704303946360030\";}}', 'yes'),
(940, 'ztb_status_message', '2', 'yes'),
(941, 'ztb_source', '', 'yes'),
(942, 'ztb_id', '563458', 'yes'),
(943, 'ztb_domainid', '00ef9c0efcaa3bd65b6b818172876cc1', 'yes'),
(944, 'ztb_email', '', 'yes'),
(945, 'access_key', '', 'yes'),
(946, 'ztb_access_key', '225bd23bf705525a8d7852a2a9140371dd84e77803c4ad18625b7fa823078361fb4346e952f36d9e4ae49a7a55acce5c044a1e55dbc81249123cc7e77476376ab1d9812864ec22a08b6eb4ea1f8f940a13e7af01231ab014166ebe2d2f6f2b275e5408c49127bd996e736303a6086b6465ac829b43251c38da31346d9a28ec95', 'yes'),
(947, 'ztb_status_disconnect', '1', 'yes'),
(950, 'social_messenger_versions', '1', 'yes'),
(1091, 'category_children', 'a:0:{}', 'yes'),
(1220, 'widget_mphb_title_rooms_widget', 'a:3:{i:2;a:3:{s:5:\"title\";s:13:\"Loại phòng\";s:13:\"room_type_ids\";a:6:{i:0;s:3:\"304\";i:1;s:3:\"317\";i:2;s:3:\"333\";i:3;s:3:\"348\";i:4;s:3:\"364\";i:5;s:3:\"373\";}s:10:\"show_title\";b:1;}i:3;a:3:{s:5:\"title\";s:13:\"Loại phòng\";s:13:\"room_type_ids\";a:6:{i:0;s:3:\"304\";i:1;s:3:\"317\";i:2;s:3:\"333\";i:3;s:3:\"348\";i:4;s:3:\"364\";i:5;s:3:\"373\";}s:10:\"show_title\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(1233, 'widget_mphb_services_widget', 'a:3:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:12:\"services_ids\";s:0:\"\";s:10:\"show_title\";b:1;}i:3;a:3:{s:5:\"title\";s:0:\"\";s:12:\"services_ids\";s:0:\"\";s:10:\"show_title\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(1531, '_transient_random_seed', 'd4b65d464d41f88564432adc1638e284', 'yes'),
(1532, 'adminhash', 'a:2:{s:4:\"hash\";s:32:\"824868ce36d425d2e2ab62e7209d33aa\";s:8:\"newemail\";s:19:\"ailabviet@gmail.com\";}', 'yes'),
(1554, 'wp_smtp_options', 'a:9:{s:4:\"from\";s:27:\"nguyenvanhoai1280@gmail.com\";s:8:\"fromname\";s:5:\"Hotel\";s:4:\"host\";s:14:\"smtp.gmail.com\";s:10:\"smtpsecure\";s:3:\"tls\";s:4:\"port\";s:3:\"587\";s:8:\"smtpauth\";s:3:\"yes\";s:8:\"username\";s:27:\"nguyenvanhoai1280@gmail.com\";s:8:\"password\";s:31:\"q s f v g j h m o x q p e y d u\";s:10:\"deactivate\";s:0:\"\";}', 'yes'),
(1671, 'rewrite_rules', 'a:291:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:39:\"index.php?yoast-sitemap-xsl=$matches[1]\";s:16:\"accommodation/?$\";s:34:\"index.php?post_type=mphb_room_type\";s:46:\"accommodation/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?post_type=mphb_room_type&feed=$matches[1]\";s:41:\"accommodation/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?post_type=mphb_room_type&feed=$matches[1]\";s:33:\"accommodation/page/([0-9]{1,})/?$\";s:52:\"index.php?post_type=mphb_room_type&paged=$matches[1]\";s:10:\"service/?$\";s:37:\"index.php?post_type=mphb_room_service\";s:40:\"service/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?post_type=mphb_room_service&feed=$matches[1]\";s:35:\"service/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?post_type=mphb_room_service&feed=$matches[1]\";s:27:\"service/page/([0-9]{1,})/?$\";s:55:\"index.php?post_type=mphb_room_service&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:44:\"(room)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:27:\"(room)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:9:\"(room)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:47:\"(tin-tuc)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:30:\"(tin-tuc)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:12:\"(tin-tuc)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:53:\"(uncategorized)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:36:\"(uncategorized)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:18:\"(uncategorized)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:14:\"category/(.+)$\";s:45:\"index.php?wpseo_category_redirect=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:40:\"mphb_booking/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"mphb_booking/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"mphb_booking/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"mphb_booking/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"mphb_booking/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"mphb_booking/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"mphb_booking/([^/]+)/embed/?$\";s:60:\"index.php?post_type=mphb_booking&name=$matches[1]&embed=true\";s:33:\"mphb_booking/([^/]+)/trackback/?$\";s:54:\"index.php?post_type=mphb_booking&name=$matches[1]&tb=1\";s:41:\"mphb_booking/([^/]+)/page/?([0-9]{1,})/?$\";s:67:\"index.php?post_type=mphb_booking&name=$matches[1]&paged=$matches[2]\";s:48:\"mphb_booking/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?post_type=mphb_booking&name=$matches[1]&cpage=$matches[2]\";s:37:\"mphb_booking/([^/]+)(?:/([0-9]+))?/?$\";s:66:\"index.php?post_type=mphb_booking&name=$matches[1]&page=$matches[2]\";s:29:\"mphb_booking/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"mphb_booking/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"mphb_booking/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"mphb_booking/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"mphb_booking/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"mphb_booking/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:41:\"accommodation/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:51:\"accommodation/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:71:\"accommodation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"accommodation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"accommodation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:47:\"accommodation/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:30:\"accommodation/([^/]+)/embed/?$\";s:47:\"index.php?mphb_room_type=$matches[1]&embed=true\";s:34:\"accommodation/([^/]+)/trackback/?$\";s:41:\"index.php?mphb_room_type=$matches[1]&tb=1\";s:54:\"accommodation/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?mphb_room_type=$matches[1]&feed=$matches[2]\";s:49:\"accommodation/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?mphb_room_type=$matches[1]&feed=$matches[2]\";s:42:\"accommodation/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?mphb_room_type=$matches[1]&paged=$matches[2]\";s:49:\"accommodation/([^/]+)/comment-page-([0-9]{1,})/?$\";s:54:\"index.php?mphb_room_type=$matches[1]&cpage=$matches[2]\";s:38:\"accommodation/([^/]+)(?:/([0-9]+))?/?$\";s:53:\"index.php?mphb_room_type=$matches[1]&page=$matches[2]\";s:30:\"accommodation/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"accommodation/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"accommodation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"accommodation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"accommodation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"accommodation/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:61:\"accommodation-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?mphb_room_type_category=$matches[1]&feed=$matches[2]\";s:56:\"accommodation-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?mphb_room_type_category=$matches[1]&feed=$matches[2]\";s:37:\"accommodation-category/(.+?)/embed/?$\";s:56:\"index.php?mphb_room_type_category=$matches[1]&embed=true\";s:49:\"accommodation-category/(.+?)/page/?([0-9]{1,})/?$\";s:63:\"index.php?mphb_room_type_category=$matches[1]&paged=$matches[2]\";s:31:\"accommodation-category/(.+?)/?$\";s:45:\"index.php?mphb_room_type_category=$matches[1]\";s:58:\"accommodation-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?mphb_room_type_tag=$matches[1]&feed=$matches[2]\";s:53:\"accommodation-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?mphb_room_type_tag=$matches[1]&feed=$matches[2]\";s:34:\"accommodation-tag/([^/]+)/embed/?$\";s:51:\"index.php?mphb_room_type_tag=$matches[1]&embed=true\";s:46:\"accommodation-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?mphb_room_type_tag=$matches[1]&paged=$matches[2]\";s:28:\"accommodation-tag/([^/]+)/?$\";s:40:\"index.php?mphb_room_type_tag=$matches[1]\";s:61:\"accommodation-facility/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?mphb_room_type_facility=$matches[1]&feed=$matches[2]\";s:56:\"accommodation-facility/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?mphb_room_type_facility=$matches[1]&feed=$matches[2]\";s:37:\"accommodation-facility/(.+?)/embed/?$\";s:56:\"index.php?mphb_room_type_facility=$matches[1]&embed=true\";s:49:\"accommodation-facility/(.+?)/page/?([0-9]{1,})/?$\";s:63:\"index.php?mphb_room_type_facility=$matches[1]&paged=$matches[2]\";s:31:\"accommodation-facility/(.+?)/?$\";s:45:\"index.php?mphb_room_type_facility=$matches[1]\";s:47:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"mphb_room_attribute/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"mphb_room_attribute/([^/]+)/embed/?$\";s:52:\"index.php?mphb_room_attribute=$matches[1]&embed=true\";s:40:\"mphb_room_attribute/([^/]+)/trackback/?$\";s:46:\"index.php?mphb_room_attribute=$matches[1]&tb=1\";s:48:\"mphb_room_attribute/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?mphb_room_attribute=$matches[1]&paged=$matches[2]\";s:55:\"mphb_room_attribute/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?mphb_room_attribute=$matches[1]&cpage=$matches[2]\";s:44:\"mphb_room_attribute/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?mphb_room_attribute=$matches[1]&page=$matches[2]\";s:36:\"mphb_room_attribute/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"mphb_room_attribute/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"mphb_room_attribute/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"mphb_room_attribute/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"mphb_room_attribute/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"mphb_room_attribute/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"mphb_season/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"mphb_season/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"mphb_season/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"mphb_season/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"mphb_season/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"mphb_season/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"mphb_season/([^/]+)/embed/?$\";s:59:\"index.php?post_type=mphb_season&name=$matches[1]&embed=true\";s:32:\"mphb_season/([^/]+)/trackback/?$\";s:53:\"index.php?post_type=mphb_season&name=$matches[1]&tb=1\";s:40:\"mphb_season/([^/]+)/page/?([0-9]{1,})/?$\";s:66:\"index.php?post_type=mphb_season&name=$matches[1]&paged=$matches[2]\";s:47:\"mphb_season/([^/]+)/comment-page-([0-9]{1,})/?$\";s:66:\"index.php?post_type=mphb_season&name=$matches[1]&cpage=$matches[2]\";s:36:\"mphb_season/([^/]+)(?:/([0-9]+))?/?$\";s:65:\"index.php?post_type=mphb_season&name=$matches[1]&page=$matches[2]\";s:28:\"mphb_season/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"mphb_season/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"mphb_season/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"mphb_season/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"mphb_season/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"mphb_season/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:37:\"mphb_rate/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"mphb_rate/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"mphb_rate/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"mphb_rate/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"mphb_rate/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"mphb_rate/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"mphb_rate/([^/]+)/embed/?$\";s:57:\"index.php?post_type=mphb_rate&name=$matches[1]&embed=true\";s:30:\"mphb_rate/([^/]+)/trackback/?$\";s:51:\"index.php?post_type=mphb_rate&name=$matches[1]&tb=1\";s:38:\"mphb_rate/([^/]+)/page/?([0-9]{1,})/?$\";s:64:\"index.php?post_type=mphb_rate&name=$matches[1]&paged=$matches[2]\";s:45:\"mphb_rate/([^/]+)/comment-page-([0-9]{1,})/?$\";s:64:\"index.php?post_type=mphb_rate&name=$matches[1]&cpage=$matches[2]\";s:34:\"mphb_rate/([^/]+)(?:/([0-9]+))?/?$\";s:63:\"index.php?post_type=mphb_rate&name=$matches[1]&page=$matches[2]\";s:26:\"mphb_rate/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"mphb_rate/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"mphb_rate/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"mphb_rate/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"mphb_rate/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"mphb_rate/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"service/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"service/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"service/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"service/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"service/([^/]+)/embed/?$\";s:50:\"index.php?mphb_room_service=$matches[1]&embed=true\";s:28:\"service/([^/]+)/trackback/?$\";s:44:\"index.php?mphb_room_service=$matches[1]&tb=1\";s:48:\"service/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?mphb_room_service=$matches[1]&feed=$matches[2]\";s:43:\"service/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?mphb_room_service=$matches[1]&feed=$matches[2]\";s:36:\"service/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?mphb_room_service=$matches[1]&paged=$matches[2]\";s:43:\"service/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?mphb_room_service=$matches[1]&cpage=$matches[2]\";s:32:\"service/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?mphb_room_service=$matches[1]&page=$matches[2]\";s:24:\"service/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"service/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"service/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"service/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:37:\"mphb_room/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"mphb_room/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"mphb_room/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"mphb_room/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"mphb_room/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"mphb_room/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"mphb_room/([^/]+)/embed/?$\";s:57:\"index.php?post_type=mphb_room&name=$matches[1]&embed=true\";s:30:\"mphb_room/([^/]+)/trackback/?$\";s:51:\"index.php?post_type=mphb_room&name=$matches[1]&tb=1\";s:38:\"mphb_room/([^/]+)/page/?([0-9]{1,})/?$\";s:64:\"index.php?post_type=mphb_room&name=$matches[1]&paged=$matches[2]\";s:45:\"mphb_room/([^/]+)/comment-page-([0-9]{1,})/?$\";s:64:\"index.php?post_type=mphb_room&name=$matches[1]&cpage=$matches[2]\";s:34:\"mphb_room/([^/]+)(?:/([0-9]+))?/?$\";s:63:\"index.php?post_type=mphb_room&name=$matches[1]&page=$matches[2]\";s:26:\"mphb_room/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"mphb_room/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"mphb_room/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"mphb_room/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"mphb_room/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"mphb_room/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"mphb_payment/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"mphb_payment/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"mphb_payment/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"mphb_payment/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"mphb_payment/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"mphb_payment/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"mphb_payment/([^/]+)/embed/?$\";s:60:\"index.php?post_type=mphb_payment&name=$matches[1]&embed=true\";s:33:\"mphb_payment/([^/]+)/trackback/?$\";s:54:\"index.php?post_type=mphb_payment&name=$matches[1]&tb=1\";s:41:\"mphb_payment/([^/]+)/page/?([0-9]{1,})/?$\";s:67:\"index.php?post_type=mphb_payment&name=$matches[1]&paged=$matches[2]\";s:48:\"mphb_payment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?post_type=mphb_payment&name=$matches[1]&cpage=$matches[2]\";s:37:\"mphb_payment/([^/]+)(?:/([0-9]+))?/?$\";s:66:\"index.php?post_type=mphb_payment&name=$matches[1]&page=$matches[2]\";s:29:\"mphb_payment/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"mphb_payment/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"mphb_payment/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"mphb_payment/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"mphb_payment/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"mphb_payment/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:46:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:56:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:76:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:52:\"mphb_reserved_room/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"mphb_reserved_room/([^/]+)/embed/?$\";s:66:\"index.php?post_type=mphb_reserved_room&name=$matches[1]&embed=true\";s:39:\"mphb_reserved_room/([^/]+)/trackback/?$\";s:60:\"index.php?post_type=mphb_reserved_room&name=$matches[1]&tb=1\";s:47:\"mphb_reserved_room/([^/]+)/page/?([0-9]{1,})/?$\";s:73:\"index.php?post_type=mphb_reserved_room&name=$matches[1]&paged=$matches[2]\";s:54:\"mphb_reserved_room/([^/]+)/comment-page-([0-9]{1,})/?$\";s:73:\"index.php?post_type=mphb_reserved_room&name=$matches[1]&cpage=$matches[2]\";s:43:\"mphb_reserved_room/([^/]+)(?:/([0-9]+))?/?$\";s:72:\"index.php?post_type=mphb_reserved_room&name=$matches[1]&page=$matches[2]\";s:35:\"mphb_reserved_room/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"mphb_reserved_room/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"mphb_reserved_room/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"mphb_reserved_room/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"mphb_reserved_room/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"mphb_reserved_room/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"mphb_coupon/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"mphb_coupon/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"mphb_coupon/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"mphb_coupon/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"mphb_coupon/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"mphb_coupon/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"mphb_coupon/([^/]+)/embed/?$\";s:59:\"index.php?post_type=mphb_coupon&name=$matches[1]&embed=true\";s:32:\"mphb_coupon/([^/]+)/trackback/?$\";s:53:\"index.php?post_type=mphb_coupon&name=$matches[1]&tb=1\";s:40:\"mphb_coupon/([^/]+)/page/?([0-9]{1,})/?$\";s:66:\"index.php?post_type=mphb_coupon&name=$matches[1]&paged=$matches[2]\";s:47:\"mphb_coupon/([^/]+)/comment-page-([0-9]{1,})/?$\";s:66:\"index.php?post_type=mphb_coupon&name=$matches[1]&cpage=$matches[2]\";s:36:\"mphb_coupon/([^/]+)(?:/([0-9]+))?/?$\";s:65:\"index.php?post_type=mphb_coupon&name=$matches[1]&page=$matches[2]\";s:28:\"mphb_coupon/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"mphb_coupon/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"mphb_coupon/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"mphb_coupon/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"mphb_coupon/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"mphb_coupon/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(1704, 'wp_statistics_plugin_version', '12.6.10', 'yes'),
(1705, 'wp_statistics_db_version', '12.6.10', 'yes'),
(1706, 'wp_statistics', 'a:28:{s:18:\"pending_db_updates\";a:2:{s:13:\"date_ip_agent\";b:0;s:11:\"unique_date\";b:0;}s:16:\"search_converted\";i:1;s:9:\"robotlist\";s:1715:\"007ac9\n5bot\nA6-Indexer\nAbachoBOT\naccoona\nAcoiRobot\nAddThis.com\nADmantX\nAdsBot-Google\nadvbot\nAhrefsBot\naiHitBot\nalexa\nalphabot\nAltaVista\nAntivirusPro\nanyevent\nappie\nApplebot\narchive.org_bot\nAsk Jeeves\nASPSeek\nBaiduspider\nBenjojo\nBeetleBot\nbingbot\nBlekkobot\nblexbot\nBOT for JCE\nbubing\nButterfly\ncbot\nclamantivirus\ncliqzbot\nclumboot\ncoccoc\ncrawler\nCrocCrawler\ncrowsnest.tv\ndbot\ndl2bot\ndotbot\ndownloadbot\nduckduckgo\nDumbot\nEasouSpider\neStyle\nEveryoneSocialBot\nExabot\nezooms\nfacebook.com\nfacebookexternalhit\nFAST\nFeedfetcher-Google\nfeedzirra\nfindxbot\nFirfly\nFriendFeedBot\nfroogle\nGeonaBot\nGigabot\ngirafabot\ngimme60bot\nglbot\nGooglebot\nGroupHigh\nia_archiver\nIDBot\nInfoSeek\ninktomi\nIstellaBot\njetmon\nKraken\nLeikibot\nlinkapediabot\nlinkdexbot\nLinkpadBot\nLoadTimeBot\nlooksmart\nltx71\nLycos\nMail.RU_Bot\nMe.dium\nmeanpathbot\nmediabot\nmedialbot\nMediapartners-Google\nMJ12bot\nmsnbot\nMojeekBot\nmonobot\nmoreover\nMRBOT\nNationalDirectory\nNerdyBot\nNetcraftSurveyAgent\nniki-bot\nnutch\nOpenbot\nOrangeBot\nowler\np4Bot\nPaperLiBot\npageanalyzer\nPagesInventory\nPimonster\nporkbun\npr-cy\nproximic\npwbot\nr4bot\nrabaz\nRambler\nRankivabot\nrevip\nriddler\nrogerbot\nScooter\nScrubby\nscrapy.org\nSearchmetricsBot\nsees.co\nSemanticBot\nSemrushBot\nSeznamBot\nsfFeedReader\nshareaholic-bot\nsistrix\nSiteExplorer\nSlurp\nSocialradarbot\nSocialSearch\nSogou web spider\nSpade\nspbot\nSpiderLing\nSputnikBot\nSuperfeedr\nSurveyBot\nTechnoratiSnoop\nTECNOSEEK\nTeoma\ntrendictionbot\nTweetmemeBot\nTwiceler\nTwitterbot\nTwitturls\nu2bot\nuMBot-LN\nuni5download\nunrulymedia\nUptimeRobot\nURL_Spider_SQL\nVagabondo\nvBSEO\nWASALive-Bot\nWebAlta Crawler\nWebBug\nWebFindBot\nWebMasterAid\nWeSEE\nWotbox\nwsowner\nwsr-agent\nwww.galaxy.com\nx100bot\nXoviBot\nxzybot\nyandex\nYahoo\nYammybot\nYoudaoBot\nZyBorg\nZemlyaCrawl\";s:13:\"anonymize_ips\";b:0;s:5:\"geoip\";b:0;s:10:\"useronline\";b:1;s:6:\"visits\";b:1;s:8:\"visitors\";b:1;s:5:\"pages\";b:1;s:12:\"check_online\";s:3:\"120\";s:8:\"menu_bar\";b:0;s:11:\"coefficient\";s:1:\"1\";s:12:\"stats_report\";b:0;s:11:\"time_report\";s:5:\"daily\";s:11:\"send_report\";s:4:\"mail\";s:14:\"content_report\";s:0:\"\";s:12:\"update_geoip\";b:1;s:8:\"store_ua\";b:0;s:21:\"exclude_administrator\";s:1:\"1\";s:18:\"disable_se_clearch\";b:1;s:16:\"disable_se_qwant\";b:1;s:16:\"disable_se_baidu\";b:1;s:14:\"disable_se_ask\";b:1;s:8:\"map_type\";s:6:\"jqvmap\";s:9:\"ip_method\";s:11:\"REMOTE_ADDR\";s:18:\"force_robot_update\";b:1;s:17:\"show_welcome_page\";b:0;s:23:\"first_show_welcome_page\";b:1;}', 'yes'),
(1707, 'widget_wp_statistics_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1708, 'wp_statistics_check_useronline', '1593351658', 'yes'),
(1710, 'wp_statistics_overview_page_ads', 'a:3:{s:9:\"timestamp\";d:1592422217;s:3:\"ads\";a:6:{s:2:\"ID\";s:6:\"wp-sms\";s:5:\"title\";s:6:\"WP-SMS\";s:4:\"link\";s:22:\"https://bit.ly/30yWb8H\";s:5:\"image\";s:22:\"https://bit.ly/2LLePqv\";s:7:\"_target\";s:3:\"yes\";s:6:\"status\";s:3:\"yes\";}s:4:\"view\";s:0:\"\";}', 'no'),
(1750, 'rdev_social_messenger_verify', '1', 'yes'),
(1854, 'adrotate_config', 'a:33:{s:10:\"advertiser\";s:10:\"subscriber\";s:13:\"global_report\";s:13:\"administrator\";s:9:\"ad_manage\";s:13:\"administrator\";s:9:\"ad_delete\";s:13:\"administrator\";s:12:\"group_manage\";s:13:\"administrator\";s:12:\"group_delete\";s:13:\"administrator\";s:15:\"schedule_manage\";s:13:\"administrator\";s:15:\"schedule_delete\";s:13:\"administrator\";s:8:\"moderate\";s:13:\"administrator\";s:16:\"moderate_approve\";s:13:\"administrator\";s:18:\"enable_advertisers\";s:1:\"N\";s:14:\"enable_editing\";s:1:\"N\";s:5:\"stats\";i:1;s:27:\"enable_loggedin_impressions\";s:1:\"Y\";s:22:\"enable_loggedin_clicks\";s:1:\"Y\";s:10:\"enable_geo\";i:0;s:9:\"geo_email\";s:0:\"\";s:8:\"geo_pass\";s:0:\"\";s:15:\"geo_cookie_life\";i:86400;s:22:\"enable_geo_advertisers\";i:0;s:16:\"adblock_disguise\";s:0:\"\";s:13:\"banner_folder\";s:7:\"banners\";s:16:\"impression_timer\";i:60;s:11:\"click_timer\";i:86400;s:14:\"hide_schedules\";s:1:\"N\";s:11:\"widgetalign\";s:1:\"N\";s:13:\"widgetpadding\";s:1:\"N\";s:9:\"w3caching\";s:1:\"N\";s:12:\"borlabscache\";s:1:\"N\";s:21:\"textwidget_shortcodes\";s:1:\"N\";s:19:\"mobile_dynamic_mode\";s:1:\"Y\";s:6:\"jquery\";s:1:\"N\";s:8:\"jsfooter\";s:1:\"Y\";}', 'yes'),
(1855, 'adrotate_notifications', 'a:3:{s:17:\"notification_dash\";s:1:\"Y\";s:25:\"notification_dash_expired\";s:1:\"Y\";s:22:\"notification_dash_soon\";s:1:\"Y\";}', 'yes'),
(1856, 'adrotate_debug', 'a:3:{s:7:\"general\";b:0;s:6:\"timers\";b:0;s:5:\"track\";b:0;}', 'yes'),
(1857, 'adrotate_db_version', 'a:2:{s:7:\"current\";i:65;s:8:\"previous\";s:0:\"\";}', 'yes'),
(1858, 'adrotate_version', 'a:2:{s:7:\"current\";i:394;s:8:\"previous\";s:0:\"\";}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1859, 'adrotate_crawlers', 'a:88:{i:0;s:3:\"008\";i:1;s:3:\"bot\";i:2;s:7:\"crawler\";i:3;s:6:\"spider\";i:4;s:16:\"Accoona-AI-Agent\";i:5;s:5:\"alexa\";i:6;s:7:\"Arachmo\";i:7;s:15:\"B-l-i-t-z-B-O-T\";i:8;s:13:\"boitho.com-dc\";i:9;s:15:\"Cerberian Drtrs\";i:10;s:9:\"Charlotte\";i:11;s:6:\"cosmos\";i:12;s:11:\"Covario IDS\";i:13;s:14:\"DataparkSearch\";i:14;s:9:\"FindLinks\";i:15;s:6:\"Holmes\";i:16;s:5:\"htdig\";i:17;s:11:\"ia_archiver\";i:18;s:6:\"ichiro\";i:19;s:7:\"inktomi\";i:20;s:10:\"igdeSpyder\";i:21;s:7:\"L.webis\";i:22;s:6:\"Larbin\";i:23;s:10:\"LinkWalker\";i:24;s:11:\"lwp-trivial\";i:25;s:10:\"mabontland\";i:26;s:11:\"Mnogosearch\";i:27;s:8:\"mogimogi\";i:28;s:13:\"Morning Paper\";i:29;s:9:\"MVAClient\";i:30;s:17:\"NetResearchServer\";i:31;s:9:\"NewsGator\";i:32;s:9:\"NG-Search\";i:33;s:8:\"NutchCVS\";i:34;s:7:\"Nymesis\";i:35;s:4:\"oegp\";i:36;s:7:\"Orbiter\";i:37;s:4:\"Peew\";i:38;s:6:\"Pompos\";i:39;s:8:\"PostPost\";i:40;s:6:\"PycURL\";i:41;s:6:\"Qseero\";i:42;s:7:\"Radian6\";i:43;s:6:\"SBIder\";i:44;s:8:\"ScoutJet\";i:45;s:7:\"Scrubby\";i:46;s:11:\"SearchSight\";i:47;s:17:\"semanticdiscovery\";i:48;s:8:\"ShopWiki\";i:49;s:4:\"silk\";i:50;s:6:\"Snappy\";i:51;s:6:\"Sqworm\";i:52;s:12:\"StackRambler\";i:53;s:5:\"Teoma\";i:54;s:6:\"TinEye\";i:55;s:8:\"truwoGPS\";i:56;s:7:\"updated\";i:57;s:9:\"Vagabondo\";i:58;s:6:\"Vortex\";i:59;s:7:\"voyager\";i:60;s:4:\"VYU2\";i:61;s:10:\"webcollage\";i:62;s:13:\"Websquash.com\";i:63;s:4:\"wf84\";i:64;s:13:\"WomlpeFactory\";i:65;s:4:\"yacy\";i:66;s:12:\"Yahoo! Slurp\";i:67;s:18:\"Yahoo! Slurp China\";i:68;s:11:\"YahooSeeker\";i:69;s:19:\"YahooSeeker-Testing\";i:70;s:12:\"YandexImages\";i:71;s:4:\"Yeti\";i:72;s:16:\"yoogliFetchAgent\";i:73;s:3:\"Zao\";i:74;s:6:\"ZyBorg\";i:75;s:7:\"froogle\";i:76;s:9:\"looksmart\";i:77;s:7:\"Firefly\";i:78;s:17:\"NationalDirectory\";i:79;s:10:\"Ask Jeeves\";i:80;s:9:\"TECNOSEEK\";i:81;s:8:\"InfoSeek\";i:82;s:7:\"Scooter\";i:83;s:5:\"appie\";i:84;s:6:\"WebBug\";i:85;s:5:\"Spade\";i:86;s:5:\"rabaz\";i:87;s:15:\"TechnoratiSnoop\";}', 'yes'),
(1860, 'adrotate_db_timer', '1571736650', 'yes'),
(1861, 'adrotate_advert_status', 'a:5:{s:5:\"error\";i:0;s:7:\"expired\";i:3;s:11:\"expiressoon\";i:0;s:6:\"normal\";i:0;s:7:\"unknown\";i:0;}', 'yes'),
(1862, 'adrotate_geo_required', '0', 'yes'),
(1863, 'adrotate_geo_requests', '0', 'yes'),
(1864, 'adrotate_dynamic_required', '0', 'yes'),
(1865, 'adrotate_hide_getpro', '1593425424', 'yes'),
(1866, 'adrotate_hide_review', '1592215824', 'yes'),
(1867, 'adrotate_hide_competition', '1571761850', 'yes'),
(1868, 'widget_adrotate_widgets', 'a:2:{i:2;a:5:{s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:4:\"type\";s:6:\"single\";s:4:\"adid\";s:1:\"1\";s:6:\"siteid\";s:1:\"1\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(1962, 'mphb_passed_notices', 'a:2:{i:0;s:13:\"force_upgrade\";i:1;s:29:\"update_confirmation_endpoints\";}', 'yes'),
(2012, 'mphb_room_type_facility_children', 'a:0:{}', 'yes'),
(2068, 'flamingo_inbound_channel_children', 'a:1:{i:12;a:1:{i:0;i:13;}}', 'yes'),
(2131, 'wp_statistics_referrals_detail', 'a:2:{s:9:\"localhost\";a:3:{s:2:\"ip\";s:9:\"127.0.0.1\";s:7:\"country\";s:0:\"\";s:5:\"title\";s:0:\"\";}s:14:\"localhost:8080\";a:3:{s:2:\"ip\";s:0:\"\";s:7:\"country\";s:0:\"\";s:5:\"title\";s:0:\"\";}}', 'no'),
(2172, 'mphb_last_known_extensions', 'a:9:{i:0;a:5:{s:4:\"slug\";s:29:\"hotel-booking-checkout-fields\";s:5:\"title\";s:29:\"Hotel Booking Checkout Fields\";s:7:\"excerpt\";s:547:\"This Hotel Booking extension allows you to edit the form that appears at the checkout by customizing current Hotel Booking Checkout Fields or adding new custom ones. The add-on adds more field types you can use to tailor the checkout experience to your business needs: collect more basic information from guests, require extra legal data/agreements to comply with the policies of your country or property, enable guests to leave comments, etc. You can also add extra text fields with instructions or a referral survey to learn how guests find you.\";s:9:\"thumbnail\";s:82:\"https://motopress.com/wp-content/uploads/2020/01/hotel-booking-checkout-fields.jpg\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=905135\";}i:1;a:5:{s:4:\"slug\";s:22:\"hotel-booking-notifier\";s:5:\"title\";s:44:\"Hotel Booking Notifier - Event-Driven Emails\";s:7:\"excerpt\";s:477:\"This extension allows you to create common event-driven emails/notifications, such as key pick-up instructions or house rules, before and after arrival/departure. Upsell services or offer property upgrade options by sending relevant pre-arrival emails. Ask for property reviews to get social proof in a certain number of days after check-out. Send any other type of automated relevant emails to drive ancillary revenue. Less work for a manager, a receptionist or a housekeeper.\";s:9:\"thumbnail\";s:75:\"https://motopress.com/wp-content/uploads/2019/12/hotel-booking-notifier.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=890485\";}i:2;a:5:{s:4:\"slug\";s:23:\"hotel-booking-mailchimp\";s:5:\"title\";s:37:\"Hotel Booking & Mailchimp Integration\";s:7:\"excerpt\";s:372:\"Integrate powerful email marketing automation and e-commerce tools by Mailchimp into the Hotel Booking plugin. Automatically subscribe users who book accommodations through your website to your Mailchimp audiences/lists or output checkboxes for opt-in consent at checkout. Send any volume of automated targeted emails to promote your property and increase direct bookings.\";s:9:\"thumbnail\";s:77:\"https://motopress.com/wp-content/uploads/2019/10/mail-chimp-hotel-booking.jpg\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=869188\";}i:3;a:5:{s:4:\"slug\";s:35:\"hotel-booking-elementor-integration\";s:5:\"title\";s:37:\"Hotel Booking & Elementor Integration\";s:7:\"excerpt\";s:105:\"Build your property rental website visually with MotoPress Hotel Booking plugin shortcodes and Elementor.\";s:9:\"thumbnail\";s:88:\"https://motopress.com/wp-content/uploads/2019/04/hotel-booking-elementor-integration.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=790102\";}i:4;a:5:{s:4:\"slug\";s:36:\"hotel-booking-divi-theme-integration\";s:5:\"title\";s:32:\"Hotel Booking & Divi Integration\";s:7:\"excerpt\";s:117:\"Integrates Divi theme with the MotoPress Hotel Booking plugin to modify content and styles visually via Divi builder.\";s:9:\"thumbnail\";s:83:\"https://motopress.com/wp-content/uploads/2019/04/hotel-booking-divi-integration.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=790089\";}i:5;a:5:{s:4:\"slug\";s:21:\"hotel-booking-reviews\";s:5:\"title\";s:21:\"Hotel Booking Reviews\";s:7:\"excerpt\";s:380:\"Build trust with travelers by featuring real user-generated reviews. This easy-to-implement WordPress property rating system allows guests to submit written reviews and star ratings evaluating your accommodation by different criteria. Manage reviews with a power and flexibility of the native WordPress comment system, customize reviews layout, display them on any page or widget.\";s:9:\"thumbnail\";s:74:\"https://motopress.com/wp-content/uploads/2018/12/hotel-booking-reviews.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=755481\";}i:6;a:5:{s:4:\"slug\";s:29:\"hotel-booking-payment-request\";s:5:\"title\";s:29:\"Hotel Booking Payment Request\";s:7:\"excerpt\";s:371:\"This add-on will automate your workflow of requesting and collecting rental payments from your clients. Allow your guests to secure their bookings by paying the full or remaining balance in a certain number of days before arrival. Email the balance payment request link automatically or manually. Always receive on-time payments without a need to handle repetitive tasks.\";s:9:\"thumbnail\";s:83:\"https://motopress.com/wp-content/uploads/2018/12/booking_payment_request_plugin.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=751734\";}i:7;a:5:{s:4:\"slug\";s:34:\"hotel-booking-woocommerce-payments\";s:5:\"title\";s:34:\"Hotel Booking WooCommerce Payments\";s:7:\"excerpt\";s:203:\"This plugin integrates WooCommerce payment gateways with MotoPress Hotel Booking plugin for WordPress. Use it to extend a number of payment gateways needed to handle online reservation of accommodations.\";s:9:\"thumbnail\";s:75:\"https://motopress.com/wp-content/uploads/edd/2018/01/woocommerce_plugin.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=631792\";}i:8;a:5:{s:4:\"slug\";s:13:\"hotel-booking\";s:5:\"title\";s:13:\"Hotel Booking\";s:7:\"excerpt\";s:489:\"The MotoPress WordPress Hotel Booking plugin is an all-in-one property management suite for rental property websites. List unlimited accommodations and services, accept direct online reservations, synchronize all bookings across OTAs and more (no per-booking or per-property commission). This WordPress hotel booking plugin is perfect for running any hospitality business establishment regardless of the size, function or cost: a hotel, vacation rental, apartments agency, hostel and more.\";s:9:\"thumbnail\";s:75:\"https://motopress.com/wp-content/uploads/2018/02/hotel_booking_plugin_1.png\";s:4:\"link\";s:50:\"https://motopress.com/?post_type=download&p=439190\";}}', 'no'),
(2192, 'erp_modules', 'a:3:{s:3:\"hrm\";a:5:{s:5:\"title\";s:13:\"HR Management\";s:4:\"slug\";s:7:\"erp-hrm\";s:11:\"description\";s:25:\"Human Resource Management\";s:8:\"callback\";s:30:\"\\WeDevs\\ERP\\HRM\\Human_Resource\";s:7:\"modules\";a:0:{}}s:3:\"crm\";a:5:{s:5:\"title\";s:13:\"CR Management\";s:4:\"slug\";s:7:\"erp-crm\";s:11:\"description\";s:32:\"Customer Relationship Management\";s:8:\"callback\";s:37:\"\\WeDevs\\ERP\\CRM\\Customer_Relationship\";s:7:\"modules\";a:0:{}}s:10:\"accounting\";a:5:{s:5:\"title\";s:10:\"Accounting\";s:4:\"slug\";s:14:\"erp-accounting\";s:11:\"description\";s:21:\"Accounting Management\";s:8:\"callback\";s:33:\"\\WeDevs\\ERP\\Accounting\\Accounting\";s:7:\"modules\";a:0:{}}}', 'yes'),
(2193, 'erp_settings_erp-crm_subscription', 'a:8:{s:10:\"is_enabled\";s:3:\"yes\";s:13:\"email_subject\";s:44:\"Confirm your subscription to Moonlight Hotel\";s:13:\"email_content\";s:278:\"Hello!\n\nThanks so much for signing up for our newsletter.\nWe need you to activate your subscription to the list(s): [contact_groups_to_confirm] by clicking the link below: \n\n[activation_link]Click here to confirm your subscription.[/activation_link]\n\nThank you,\n\nMoonlight Hotel\";s:7:\"page_id\";i:468;s:18:\"confirm_page_title\";s:23:\"You are now subscribed!\";s:20:\"confirm_page_content\";s:63:\"We\'ve added you to our email list. You\'ll hear from us shortly.\";s:17:\"unsubs_page_title\";s:24:\"You are now unsubscribed\";s:19:\"unsubs_page_content\";s:47:\"You are successfully unsubscribed from list(s):\";}', 'yes'),
(2194, 'erp_acct_new_ledgers', '1', 'yes'),
(2195, 'erp_email_settings_employee-welcome', 'a:3:{s:7:\"subject\";s:37:\"Welcome {full_name} to {company_name}\";s:7:\"heading\";s:29:\"Welcome Onboard {first_name}!\";s:4:\"body\";s:1015:\"Dear {full_name},\n\nWelcome aboard as a <strong>{job_title}</strong> in our <strong>{dept_title}</strong> team at <strong>{company_name}</strong>! I am pleased to have you working with us. You were selected for employment due to the attributes that you displayed that appear to match the qualities I look for in an employee.\n\nI’m looking forward to seeing you grow and develop into an outstanding employee that exhibits a high level of care, concern, and compassion for others. I hope that you will find your work to be rewarding, challenging, and meaningful.\n\nYour <strong>{type}</strong> employment will start from <strong>{joined_date}</strong> and you will be reporting to <strong>{reporting_to}</strong>.\n\nPlease take your time and review our yearly goals so that you can know what is expected and make a positive contribution. Again, I look forward to seeing you grow as a professional while enhancing the lives of the clients entrusted in your care.\n\nSincerely,\nManager Name\nCEO, Company Name\n\n{login_info}\";}', 'yes'),
(2196, 'erp_email_settings_new-leave-request', 'a:3:{s:7:\"subject\";s:47:\"New leave request received from {employee_name}\";s:7:\"heading\";s:17:\"New Leave Request\";s:4:\"body\";s:316:\"Hello,\n\nA new leave request has been received from {employee_url}.\n\n<strong>Leave type:</strong> {leave_type}\n<strong>Date:</strong> {date_from} to {date_to}\n<strong>Days:</strong> {no_days}\n<strong>Reason:</strong> {reason}\n\nPlease approve/reject this leave application by going following:\n\n{requests_url}\n\nThanks.\";}', 'yes'),
(2197, 'erp_email_settings_approved-leave-request', 'a:3:{s:7:\"subject\";s:36:\"Your leave request has been approved\";s:7:\"heading\";s:22:\"Leave Request Approved\";s:4:\"body\";s:192:\"Hello {employee_name},\n\nYour <strong>{leave_type}</strong> type leave request for <strong>{no_days} days</strong> from {date_from} to {date_to} has been approved.\n\nRegards\nManager Name\nCompany\";}', 'yes'),
(2198, 'erp_email_settings_rejected-leave-request', 'a:3:{s:7:\"subject\";s:36:\"Your leave request has been rejected\";s:7:\"heading\";s:22:\"Leave Request Rejected\";s:4:\"body\";s:237:\"Hello {employee_name},\n\nYour <strong>{leave_type}</strong> type leave request for <strong>{no_days} days</strong> from {date_from} to {date_to} has been rejected.\n\nThe reason of rejection is: {reject_reason}\n\nRegards\nManager Name\nCompany\";}', 'yes'),
(2199, 'erp_email_settings_new-task-assigned', 'a:3:{s:7:\"subject\";s:33:\"New task has been assigned to you\";s:7:\"heading\";s:17:\"New Task Assigned\";s:4:\"body\";s:157:\"Hello {employee_name},\n\nA new task <strong>{task_title}</strong> has been assigned to you by {created_by}.\nDue Date: {due_date}\n\nRegards\nManager Name\nCompany\";}', 'yes'),
(2200, 'erp_email_settings_new-contact-assigned', 'a:3:{s:7:\"subject\";s:36:\"New contact has been assigned to you\";s:7:\"heading\";s:20:\"New Contact Assigned\";s:4:\"body\";s:141:\"Hello {employee_name},\n\nA new contact <strong>{contact_name}</strong> has been assigned to you by {created_by}.\n\nRegards\nManager Name\nCompany\";}', 'yes'),
(2201, 'erp_email_settings_hiring-anniversary-wish', 'a:3:{s:7:\"subject\";s:40:\"Congratulation for Your Work Anniversary\";s:7:\"heading\";s:51:\"Congratulation for Passing One More Year With Us :)\";s:4:\"body\";s:512:\"Congratulations {full_name}!\n\nYou have been a model employee for {total_year} years now. You are one of my few original employees and have certainly become an asset to this company. I appreciate the selfless service you\'ve given for so many years. Without the loyalty and hard work of experts like you who helped us get things started, we could never have achieved our present stature. I hope the gift I sent will reflect the high esteem I have for you.\n\nMay you enjoy the fruits of your labors for years to come\";}', 'yes'),
(2204, 'wp_erp_version', '1.6.0', 'yes'),
(2205, 'wp_erp_db_version', '1.6.0', 'yes'),
(2206, 'wp_erp_install_date', '1592495334', 'yes'),
(2207, 'widget_erp-subscription-from-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2209, 'erp_setup_wizard_ran', '1', 'yes'),
(2212, 'erp_allow_tracking', 'no', 'yes'),
(2214, '_erp_company', 'a:9:{s:4:\"logo\";i:0;s:4:\"name\";s:15:\"Moonlight Hotel\";s:7:\"address\";a:6:{s:9:\"address_1\";s:16:\"Street Address 1\";s:9:\"address_2\";s:14:\"Address Line 2\";s:4:\"city\";s:4:\"City\";s:5:\"state\";s:5:\"State\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"US\";}s:5:\"phone\";s:0:\"\";s:3:\"fax\";s:0:\"\";s:6:\"mobile\";s:0:\"\";s:7:\"website\";s:0:\"\";s:8:\"currency\";s:3:\"USD\";s:13:\"business_type\";s:14:\"ecommerceOther\";}', 'yes'),
(2215, 'erp_settings_general', 'a:5:{s:19:\"gen_financial_month\";s:1:\"1\";s:13:\"gen_com_start\";s:10:\"2020-06-10\";s:11:\"date_format\";s:5:\"d/m/Y\";s:12:\"erp_currency\";s:3:\"152\";s:14:\"erp_debug_mode\";i:0;}', 'yes'),
(2217, 'pm_version', '2.3.11', 'yes'),
(2218, 'pm_installed', '1592470342', 'yes'),
(2221, 'include_project_manager', 'yes', 'yes'),
(2222, 'pm_db_version', '2.3', 'yes'),
(2225, 'mon', '8', 'yes'),
(2226, 'tue', '8', 'yes'),
(2227, 'wed', '8', 'yes'),
(2228, 'thu', '8', 'yes'),
(2229, 'fri', '8', 'yes'),
(2230, 'sat', '4', 'yes'),
(2231, 'sun', '4', 'yes'),
(2233, 'wedevs-project-manager_allow_tracking', 'yes', 'yes'),
(2235, 'wedevs-project-manager_tracking_last_send', '1592470458', 'yes'),
(2346, '_transient_timeout_plugin_slugs', '1593335184', 'no'),
(2347, '_transient_plugin_slugs', 'a:10:{i:0;s:21:\"adrotate/adrotate.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:21:\"flamingo/flamingo.php\";i:4;s:9:\"hello.php\";i:5;s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";i:6;s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";i:7;s:19:\"wp-smtp/wp-smtp.php\";i:8;s:31:\"wp-statistics/wp-statistics.php\";i:9;s:24:\"wordpress-seo/wp-seo.php\";}', 'no'),
(2350, '_site_transient_timeout_theme_roots', '1593310707', 'no'),
(2351, '_site_transient_theme_roots', 'a:5:{s:13:\"hotel-booking\";s:7:\"/themes\";s:12:\"hotel-galaxy\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(2361, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:4:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.4.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.2\";s:7:\"version\";s:5:\"5.4.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.4.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.2\";s:7:\"version\";s:5:\"5.4.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.4\";s:7:\"version\";s:5:\"5.3.4\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.7.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.7.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.7-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.7-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.2.7-partial-1.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.7-rollback-1.zip\";}s:7:\"current\";s:5:\"5.2.7\";s:7:\"version\";s:5:\"5.2.7\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:5:\"5.2.1\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1593309023;s:15:\"version_checked\";s:5:\"5.2.1\";s:12:\"translations\";a:0:{}}', 'no'),
(2362, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1593309025;s:7:\"checked\";a:5:{s:13:\"hotel-booking\";s:3:\"0.3\";s:12:\"hotel-galaxy\";s:5:\"4.1.8\";s:14:\"twentynineteen\";s:3:\"1.4\";s:15:\"twentyseventeen\";s:3:\"2.2\";s:13:\"twentysixteen\";s:3:\"2.0\";}s:8:\"response\";a:4:{s:12:\"hotel-galaxy\";a:6:{s:5:\"theme\";s:12:\"hotel-galaxy\";s:11:\"new_version\";s:5:\"4.2.1\";s:3:\"url\";s:42:\"https://wordpress.org/themes/hotel-galaxy/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/hotel-galaxy.4.2.1.zip\";s:8:\"requires\";s:3:\"5.0\";s:12:\"requires_php\";s:3:\"7.0\";}s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.6.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.3.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:13:\"twentysixteen\";a:6:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.2.1.zip\";s:8:\"requires\";s:3:\"4.4\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}', 'no'),
(2363, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1593309028;s:7:\"checked\";a:10:{s:21:\"adrotate/adrotate.php\";s:3:\"5.6\";s:19:\"akismet/akismet.php\";s:5:\"4.1.2\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.4\";s:21:\"flamingo/flamingo.php\";s:3:\"2.1\";s:9:\"hello.php\";s:5:\"1.7.2\";s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";s:5:\"3.5.2\";s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";s:5:\"1.2.2\";s:19:\"wp-smtp/wp-smtp.php\";s:6:\"1.1.10\";s:31:\"wp-statistics/wp-statistics.php\";s:7:\"12.6.10\";s:24:\"wordpress-seo/wp-seo.php\";s:4:\"12.0\";}s:8:\"response\";a:8:{s:21:\"adrotate/adrotate.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:22:\"w.org/plugins/adrotate\";s:4:\"slug\";s:8:\"adrotate\";s:6:\"plugin\";s:21:\"adrotate/adrotate.php\";s:11:\"new_version\";s:5:\"5.8.4\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/adrotate/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/adrotate.5.8.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/adrotate/assets/icon-256x256.jpg?rev=2308166\";s:2:\"1x\";s:61:\"https://ps.w.org/adrotate/assets/icon-128x128.jpg?rev=2308166\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/adrotate/assets/banner-1544x500.jpg?rev=2308166\";s:2:\"1x\";s:63:\"https://ps.w.org/adrotate/assets/banner-772x250.jpg?rev=2308166\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.6\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.9\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=2279696\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:21:\"flamingo/flamingo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:22:\"w.org/plugins/flamingo\";s:4:\"slug\";s:8:\"flamingo\";s:6:\"plugin\";s:21:\"flamingo/flamingo.php\";s:11:\"new_version\";s:5:\"2.1.1\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/flamingo/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/flamingo.2.1.1.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/flamingo/assets/icon-128x128.png?rev=1540977\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/flamingo/assets/banner-772x250.png?rev=544829\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.3.4\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:42:\"w.org/plugins/motopress-hotel-booking-lite\";s:4:\"slug\";s:28:\"motopress-hotel-booking-lite\";s:6:\"plugin\";s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";s:11:\"new_version\";s:5:\"3.8.2\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/motopress-hotel-booking-lite/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/motopress-hotel-booking-lite.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:81:\"https://ps.w.org/motopress-hotel-booking-lite/assets/icon-128x128.png?rev=1852316\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:83:\"https://ps.w.org/motopress-hotel-booking-lite/assets/banner-772x250.jpg?rev=1852316\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:29:\"w.org/plugins/wpcf7-recaptcha\";s:4:\"slug\";s:15:\"wpcf7-recaptcha\";s:6:\"plugin\";s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";s:11:\"new_version\";s:5:\"1.2.7\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/wpcf7-recaptcha/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/wpcf7-recaptcha.1.2.7.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:68:\"https://ps.w.org/wpcf7-recaptcha/assets/icon-256x256.png?rev=2003053\";s:2:\"1x\";s:60:\"https://ps.w.org/wpcf7-recaptcha/assets/icon.svg?rev=2003053\";s:3:\"svg\";s:60:\"https://ps.w.org/wpcf7-recaptcha/assets/icon.svg?rev=2003053\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/wpcf7-recaptcha/assets/banner-1544x500.png?rev=2003053\";s:2:\"1x\";s:70:\"https://ps.w.org/wpcf7-recaptcha/assets/banner-772x250.png?rev=2003053\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/wpcf7-recaptcha/assets/banner-1544x500-rtl.png?rev=2003053\";s:2:\"1x\";s:74:\"https://ps.w.org/wpcf7-recaptcha/assets/banner-772x250-rtl.png?rev=2003053\";}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:19:\"wp-smtp/wp-smtp.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/wp-smtp\";s:4:\"slug\";s:7:\"wp-smtp\";s:6:\"plugin\";s:19:\"wp-smtp/wp-smtp.php\";s:11:\"new_version\";s:6:\"1.1.11\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/wp-smtp/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/wp-smtp.1.1.11.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/wp-smtp.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:31:\"wp-statistics/wp-statistics.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wp-statistics\";s:4:\"slug\";s:13:\"wp-statistics\";s:6:\"plugin\";s:31:\"wp-statistics/wp-statistics.php\";s:11:\"new_version\";s:7:\"12.6.13\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-statistics/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/wp-statistics.12.6.13.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-statistics/assets/icon-256x256.png?rev=1673578\";s:2:\"1x\";s:58:\"https://ps.w.org/wp-statistics/assets/icon.svg?rev=2041108\";s:3:\"svg\";s:58:\"https://ps.w.org/wp-statistics/assets/icon.svg?rev=2041108\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:68:\"https://ps.w.org/wp-statistics/assets/banner-772x250.png?rev=2041108\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:3:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.1.4\";s:7:\"updated\";s:19:\"2019-09-08 10:17:58\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/5.1.4/vi.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"hello-dolly\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"1.7.2\";s:7:\"updated\";s:19:\"2019-11-12 11:26:07\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/translation/plugin/hello-dolly/1.7.2/vi.zip\";s:10:\"autoupdate\";b:1;}i:2;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:4:\"12.0\";s:7:\"updated\";s:19:\"2019-08-01 05:00:43\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/12.0/vi.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:2:{s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"14.4.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.14.4.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"5.4.2\";s:12:\"requires_php\";s:6:\"5.6.20\";s:13:\"compatibility\";a:0:{}}}}', 'no'),
(2366, '_site_transient_timeout_available_translations', '1593320626', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2367, '_site_transient_available_translations', 'a:118:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-10-31 16:35:52\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.6/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-15 14:27:16\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.15/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-10 20:13:25\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:6:\"4.8.14\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.8.14/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-16 03:25:39\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:33:\"མུ་མཐུད་དུ།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-14 07:58:27\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-14 11:54:05\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-14 05:36:50\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-11 08:51:16\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-09-19 12:19:29\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-10 16:03:04\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.2.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:3:\"5.2\";s:7:\"updated\";s:19:\"2019-05-07 21:15:55\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-10 16:02:58\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:30:49\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.2.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:30:07\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-06 05:44:03\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-18 10:42:19\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:25:10\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:33:22\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-18 10:42:08\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2020-04-23 13:56:35\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-05-19 17:09:08\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-06 15:53:48\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:3:\"5.2\";s:7:\"updated\";s:19:\"2019-05-11 15:51:57\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2020-06-04 23:40:23\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"5.0\";s:7:\"updated\";s:19:\"2018-12-06 21:26:01\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.0/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2019-05-23 02:23:28\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.15/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-18 12:06:18\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 03:26:22\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:9:\"5.0-beta3\";s:7:\"updated\";s:19:\"2018-11-28 16:04:33\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0-beta3/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-05-29 05:00:30\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-12 08:08:56\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 01:38:53\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:32:08\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-15 09:41:31\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-05-28 10:07:08\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-11 14:05:23\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-19 14:36:40\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:6:\"5.0.10\";s:7:\"updated\";s:19:\"2019-09-24 03:05:30\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0.10/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-14 07:31:31\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-18 06:50:11\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"次へ\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-11-04 08:57:25\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-09 07:34:10\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.3/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2019-12-04 12:22:34\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.15/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-11-05 01:55:15\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-10-19 19:22:55\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:6:\"4.7.15\";s:7:\"updated\";s:19:\"2019-05-10 10:24:08\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.15/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.8.14\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.14/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.15/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-10 17:45:28\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 06:02:07\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:34:52\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2020-05-21 08:20:43\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.1.6/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-10-24 08:39:08\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:8:\"5.2-beta\";s:7:\"updated\";s:19:\"2019-04-09 16:46:27\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.2-beta/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 08:23:12\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 09:24:27\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.2.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:3:\"5.2\";s:7:\"updated\";s:19:\"2019-05-08 11:59:02\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-11 13:56:15\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-18 13:30:06\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-15 12:19:22\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 15:22:52\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-14 13:39:13\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.1/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-10-20 12:34:47\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.6/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-05-21 18:58:08\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-13 17:16:16\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-10-29 03:20:38\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.6/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-16 03:13:05\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-12 23:35:59\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 19:34:53\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2020-04-09 10:48:08\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:6:\"5.0.10\";s:7:\"updated\";s:19:\"2019-01-23 12:32:40\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0.10/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-05-24 10:49:36\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.2.1\";s:7:\"updated\";s:19:\"2019-06-17 05:35:37\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:3:\"5.2\";s:7:\"updated\";s:19:\"2019-05-09 17:07:08\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-11-14 00:32:42\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.6/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}', 'no');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_activities`
--

DROP TABLE IF EXISTS `wp_pm_activities`;
CREATE TABLE IF NOT EXISTS `wp_pm_activities` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_id` int(11) UNSIGNED NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_id` int(11) UNSIGNED DEFAULT NULL,
  `resource_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `actor_id` (`actor_id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_assignees`
--

DROP TABLE IF EXISTS `wp_pm_assignees`;
CREATE TABLE IF NOT EXISTS `wp_pm_assignees` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `task_id` int(11) UNSIGNED NOT NULL,
  `assigned_to` int(11) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `project_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_boardables`
--

DROP TABLE IF EXISTS `wp_pm_boardables`;
CREATE TABLE IF NOT EXISTS `wp_pm_boardables` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `board_id` int(11) UNSIGNED NOT NULL,
  `board_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boardable_id` int(11) UNSIGNED NOT NULL,
  `boardable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `board_id` (`board_id`),
  KEY `boardable_id` (`boardable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_boards`
--

DROP TABLE IF EXISTS `wp_pm_boards`;
CREATE TABLE IF NOT EXISTS `wp_pm_boards` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT 1,
  `is_private` tinyint(2) UNSIGNED DEFAULT 0,
  `project_id` int(11) UNSIGNED NOT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_capabilities`
--

DROP TABLE IF EXISTS `wp_pm_capabilities`;
CREATE TABLE IF NOT EXISTS `wp_pm_capabilities` (
  `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_categories`
--

DROP TABLE IF EXISTS `wp_pm_categories`;
CREATE TABLE IF NOT EXISTS `wp_pm_categories` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categorible_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_category_project`
--

DROP TABLE IF EXISTS `wp_pm_category_project`;
CREATE TABLE IF NOT EXISTS `wp_pm_category_project` (
  `project_id` int(11) UNSIGNED NOT NULL,
  `category_id` int(11) UNSIGNED NOT NULL,
  KEY `project_id` (`project_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_comments`
--

DROP TABLE IF EXISTS `wp_pm_comments`;
CREATE TABLE IF NOT EXISTS `wp_pm_comments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mentioned_users` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentable_id` int(11) UNSIGNED NOT NULL,
  `commentable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` int(11) UNSIGNED NOT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `commentable_id` (`commentable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_files`
--

DROP TABLE IF EXISTS `wp_pm_files`;
CREATE TABLE IF NOT EXISTS `wp_pm_files` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fileable_id` int(11) DEFAULT NULL,
  `fileable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'file',
  `attachment_id` bigint(20) DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `fileable_id` (`fileable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_imports`
--

DROP TABLE IF EXISTS `wp_pm_imports`;
CREATE TABLE IF NOT EXISTS `wp_pm_imports` (
  `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remote_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creator_id` int(15) UNSIGNED DEFAULT NULL,
  `source` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_meta`
--

DROP TABLE IF EXISTS `wp_pm_meta`;
CREATE TABLE IF NOT EXISTS `wp_pm_meta` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `entity_id` int(11) UNSIGNED NOT NULL,
  `entity_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entity_id` (`entity_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_projects`
--

DROP TABLE IF EXISTS `wp_pm_projects`;
CREATE TABLE IF NOT EXISTS `wp_pm_projects` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `budget` double(8,2) DEFAULT NULL,
  `pay_rate` double(8,2) DEFAULT NULL,
  `est_completion_date` timestamp NULL DEFAULT NULL,
  `color_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` tinyint(4) DEFAULT NULL,
  `projectable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_roles`
--

DROP TABLE IF EXISTS `wp_pm_roles`;
CREATE TABLE IF NOT EXISTS `wp_pm_roles` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT 1,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_pm_roles`
--

INSERT INTO `wp_pm_roles` (`id`, `title`, `slug`, `description`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Manager', 'manager', 'Manager is a person who manages the project.', 1, 1, 1, '2020-06-18 01:52:22', '2020-06-18 01:52:22'),
(2, 'Co-Worker', 'co_worker', 'Co-worker is person who works under a project.', 1, 1, 1, '2020-06-18 01:52:22', '2020-06-18 01:52:22');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_role_project`
--

DROP TABLE IF EXISTS `wp_pm_role_project`;
CREATE TABLE IF NOT EXISTS `wp_pm_role_project` (
  `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` int(20) UNSIGNED NOT NULL,
  `role_id` int(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_role_project_capabilities`
--

DROP TABLE IF EXISTS `wp_pm_role_project_capabilities`;
CREATE TABLE IF NOT EXISTS `wp_pm_role_project_capabilities` (
  `role_project_id` int(20) UNSIGNED NOT NULL,
  `capability_id` int(20) UNSIGNED NOT NULL,
  KEY `role_project_id` (`role_project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_role_project_users`
--

DROP TABLE IF EXISTS `wp_pm_role_project_users`;
CREATE TABLE IF NOT EXISTS `wp_pm_role_project_users` (
  `role_project_id` int(20) UNSIGNED NOT NULL,
  `user_id` int(20) UNSIGNED NOT NULL,
  KEY `role_project_id` (`role_project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_role_user`
--

DROP TABLE IF EXISTS `wp_pm_role_user`;
CREATE TABLE IF NOT EXISTS `wp_pm_role_user` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `role_id` int(11) UNSIGNED NOT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `assigned_by` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `role_id` (`role_id`),
  KEY `user_id` (`user_id`),
  KEY `assigned_by` (`assigned_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_settings`
--

DROP TABLE IF EXISTS `wp_pm_settings`;
CREATE TABLE IF NOT EXISTS `wp_pm_settings` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_pm_settings`
--

INSERT INTO `wp_pm_settings` (`id`, `key`, `value`, `project_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'managing_capability', 'a:3:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";i:2;s:6:\"author\";}', NULL, 1, 1, '2020-06-18 08:52:22', '2020-06-18 08:52:22'),
(2, 'project_create_capability', 'a:3:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";i:2;s:6:\"author\";}', NULL, 1, 1, '2020-06-18 08:52:22', '2020-06-18 08:52:22');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_pm_tasks`
--

DROP TABLE IF EXISTS `wp_pm_tasks`;
CREATE TABLE IF NOT EXISTS `wp_pm_tasks` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimation` int(11) DEFAULT 0,
  `start_at` timestamp NULL DEFAULT NULL,
  `due_date` timestamp NULL DEFAULT NULL,
  `complexity` tinyint(4) DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 1,
  `payable` tinyint(1) NOT NULL DEFAULT 0,
  `recurrent` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `is_private` tinyint(2) UNSIGNED DEFAULT 0,
  `project_id` int(11) UNSIGNED NOT NULL,
  `parent_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `completed_by` int(11) UNSIGNED DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2634 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(5, 6, '_edit_lock', '1569228215:1'),
(6, 7, '_wp_attached_file', '2019/09/download.jpg'),
(7, 7, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:168;s:4:\"file\";s:20:\"2019/09/download.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"download-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"download-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(10, 6, '_thumbnail_id', '214'),
(11, 6, '_edit_last', '1'),
(16, 17, '_edit_last', '1'),
(17, 17, '_edit_lock', '1567741322:1'),
(18, 17, '_thumbnail_id', '7'),
(19, 17, '_hb_num_of_rooms', '10'),
(20, 17, '_hb_room_extra', ''),
(21, 17, '_hb_max_child_per_room', '0'),
(22, 17, '_hb_room_addition_information', ''),
(23, 17, '_hb_gallery', 'a:0:{}'),
(488, 109, '_menu_item_type', 'custom'),
(489, 109, '_menu_item_menu_item_parent', '0'),
(490, 109, '_menu_item_object_id', '109'),
(491, 109, '_menu_item_object', 'custom'),
(492, 109, '_menu_item_target', ''),
(493, 109, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(494, 109, '_menu_item_xfn', ''),
(495, 109, '_menu_item_url', 'http://localhost:8080/hotel01/'),
(612, 128, '_wp_attached_file', '2019/09/page-title.jpg'),
(613, 128, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1349;s:6:\"height\";i:500;s:4:\"file\";s:22:\"2019/09/page-title.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"page-title-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"page-title-300x111.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:111;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"page-title-768x285.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:285;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"page-title-1024x380.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:22:\"page-title-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(617, 132, '_wp_attached_file', '2019/09/normal_11-571252810.jpg'),
(618, 132, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1366;s:6:\"height\";i:749;s:4:\"file\";s:31:\"2019/09/normal_11-571252810.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"normal_11-571252810-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"normal_11-571252810-300x164.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:164;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"normal_11-571252810-768x421.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:421;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"normal_11-571252810-1024x561.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:561;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"normal_11-571252810-1366x650.jpg\";s:5:\"width\";i:1366;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"normal_11-571252810-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(665, 143, '_form', '<label> Tên của bạn (bắt buộc)\n    [text* your-name] </label>\n\n<label> Địa chỉ Email (bắt buộc)\n    [email* your-email] </label>\n\n<label> Tiêu đề:\n    [text your-subject] </label>\n\n<label> Thông điệp\n    [textarea your-message] </label>\n\n\n\n[submit \"Gửi đi\"]'),
(666, 143, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:26:\"Hotel.com \"[your-subject]\"\";s:6:\"sender\";s:41:\"Moonlight Hotel <wordpress@moonlight.com>\";s:9:\"recipient\";s:27:\"nguyenvanhoai1280@gmail.com\";s:4:\"body\";s:231:\"Gửi đến từ: [your-name] <[your-email]>\nTiêu đề: [your-subject]\n\nNội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website Hotel.com (http://localhost:8080/hotel01)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(667, 143, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:26:\"Hotel.com \"[your-subject]\"\";s:6:\"sender\";s:39:\"Hotel.com <nguyenvanhoai1280@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:153:\"Nội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website Hotel.com (http://localhost/wordpress)\";s:18:\"additional_headers\";s:37:\"Reply-To: nguyenvanhoai1280@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(668, 143, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:53:\"Xin cảm ơn, form đã được gửi thành công.\";s:12:\"mail_sent_ng\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:16:\"validation_error\";s:86:\"Có một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\";s:4:\"spam\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:12:\"accept_terms\";s:67:\"Bạn phải chấp nhận điều khoản trước khi gửi form.\";s:16:\"invalid_required\";s:28:\"Mục này là bắt buộc.\";s:16:\"invalid_too_long\";s:36:\"Nhập quá số kí tự cho phép.\";s:17:\"invalid_too_short\";s:44:\"Nhập ít hơn số kí tự tối thiểu.\";s:12:\"invalid_date\";s:46:\"Định dạng ngày tháng không hợp lệ.\";s:14:\"date_too_early\";s:58:\"Ngày này trước ngày sớm nhất được cho phép.\";s:13:\"date_too_late\";s:54:\"Ngày này quá ngày gần nhất được cho phép.\";s:13:\"upload_failed\";s:36:\"Tải file lên không thành công.\";s:24:\"upload_file_type_invalid\";s:69:\"Bạn không được phép tải lên file theo định dạng này.\";s:21:\"upload_file_too_large\";s:31:\"File kích thước quá lớn.\";s:23:\"upload_failed_php_error\";s:36:\"Tải file lên không thành công.\";s:14:\"invalid_number\";s:38:\"Định dạng số không hợp lệ.\";s:16:\"number_too_small\";s:48:\"Con số nhỏ hơn số nhỏ nhất cho phép.\";s:16:\"number_too_large\";s:48:\"Con số lớn hơn số lớn nhất cho phép.\";s:23:\"quiz_answer_not_correct\";s:30:\"Câu trả lời chưa đúng.\";s:17:\"captcha_not_match\";s:34:\"Bạn đã nhập sai mã CAPTCHA.\";s:13:\"invalid_email\";s:38:\"Địa chỉ e-mail không hợp lệ.\";s:11:\"invalid_url\";s:22:\"URL không hợp lệ.\";s:11:\"invalid_tel\";s:39:\"Số điện thoại không hợp lệ.\";}'),
(669, 143, '_additional_settings', ''),
(670, 143, '_locale', 'vi'),
(691, 154, '_edit_lock', '1569227707:1'),
(694, 154, '_thumbnail_id', '211'),
(712, 160, '_menu_item_type', 'custom'),
(713, 160, '_menu_item_menu_item_parent', '0'),
(714, 160, '_menu_item_object_id', '160'),
(715, 160, '_menu_item_object', 'custom'),
(716, 160, '_menu_item_target', ''),
(717, 160, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(718, 160, '_menu_item_xfn', ''),
(719, 160, '_menu_item_url', 'http://localhost:8080/hotel01/service/'),
(723, 21, '_edit_lock', '1569310343:1'),
(779, 154, '_edit_last', '1'),
(782, 154, '_yoast_wpseo_primary_category', '2'),
(783, 154, '_yoast_wpseo_content_score', '30'),
(794, 173, '_wp_attached_file', '2019/09/89787233.jpg'),
(795, 173, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:20:\"2019/09/89787233.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"89787233-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"89787233-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"89787233-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"89787233-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:21:\"89787233-1024x650.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:20:\"89787233-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(896, 211, '_wp_attached_file', '2019/09/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495.jpg'),
(897, 211, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:660;s:6:\"height\";i:495;s:4:\"file\";s:127:\"2019/09/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:127:\"1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:127:\"1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:127:\"1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(900, 154, '_wp_old_slug', '100-day'),
(909, 214, '_wp_attached_file', '2019/09/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427.jpg'),
(910, 214, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:640;s:6:\"height\";i:427;s:4:\"file\";s:99:\"2019/09/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:99:\"Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:99:\"Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:99:\"Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"5.6\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 700D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1485595261\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"18\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:6:\"0.0005\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(913, 6, '_wp_old_slug', '120-day'),
(916, 6, '_yoast_wpseo_primary_category', '10'),
(917, 6, '_yoast_wpseo_content_score', '30'),
(918, 1, '_edit_last', '1'),
(921, 1, '_edit_lock', '1572421944:1'),
(922, 218, '_wp_attached_file', '2019/09/1499934736-1-1499820344338.jpg'),
(923, 218, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:540;s:6:\"height\";i:405;s:4:\"file\";s:38:\"2019/09/1499934736-1-1499820344338.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"1499934736-1-1499820344338-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"1499934736-1-1499820344338-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:38:\"1499934736-1-1499820344338-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(926, 1, '_thumbnail_id', '218'),
(929, 1, '_yoast_wpseo_primary_category', '10'),
(930, 1, '_yoast_wpseo_content_score', '30'),
(934, 220, '_edit_last', '1'),
(935, 220, '_edit_lock', '1569232520:1'),
(936, 220, 'mphb_start_date', '2019-09-01'),
(937, 220, 'mphb_end_date', '2020-09-01'),
(938, 220, 'mphb_days', 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"2\";i:3;s:1:\"3\";i:4;s:1:\"4\";i:5;s:1:\"5\";i:6;s:1:\"6\";}'),
(948, 24, '_edit_last', '1'),
(949, 24, '_wp_page_template', 'default'),
(950, 24, '_edit_lock', '1569310181:1'),
(951, 21, '_edit_last', '1'),
(952, 21, '_wp_page_template', 'default'),
(953, 23, '_edit_last', '1'),
(954, 23, '_wp_page_template', 'default'),
(955, 23, '_edit_lock', '1569310408:1'),
(956, 22, '_edit_last', '1'),
(957, 22, '_wp_page_template', 'default'),
(958, 22, '_edit_lock', '1569310435:1'),
(959, 27, '_edit_last', '1'),
(960, 27, '_wp_page_template', 'default'),
(961, 27, '_edit_lock', '1569310474:1'),
(962, 25, '_edit_last', '1'),
(963, 25, '_wp_page_template', 'default'),
(964, 25, '_edit_lock', '1569310499:1'),
(965, 28, '_edit_last', '1'),
(966, 28, '_wp_page_template', 'default'),
(967, 28, '_edit_lock', '1569310524:1'),
(968, 26, '_edit_last', '1'),
(969, 26, '_wp_page_template', 'default'),
(970, 26, '_edit_lock', '1570155614:1'),
(1109, 241, '_edit_lock', '1593317269:1'),
(1110, 241, '_edit_last', '1'),
(1111, 241, '_yoast_wpseo_content_score', '60'),
(1151, 249, '_email', 'nguyenvanhoai1280@gmail.com'),
(1152, 249, '_name', 'admin'),
(1153, 249, '_props', 'a:2:{s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";}'),
(1154, 249, '_last_contacted', '2020-06-26 17:25:02'),
(1155, 250, '_email', 'wapuu@wordpress.example'),
(1156, 250, '_name', 'A WordPress Commenter'),
(1157, 250, '_props', 'a:0:{}'),
(1158, 250, '_last_contacted', '2019-10-02 09:00:17'),
(1189, 263, '_wp_attached_file', '2019/10/luxury.jpg'),
(1190, 263, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:607;s:4:\"file\";s:18:\"2019/10/luxury.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"luxury-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"luxury-300x178.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:178;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"luxury-768x455.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:455;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"luxury-1024x607.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:607;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:18:\"luxury-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1231, 269, 'mphb_key', 'booking_269_5d96b1a0d6cd02.46570895'),
(1232, 269, 'mphb_check_in_date', '2019-10-05'),
(1233, 269, 'mphb_check_out_date', '2019-10-06'),
(1234, 269, 'mphb_note', ''),
(1235, 269, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(1236, 269, 'mphb_first_name', 'hoài'),
(1237, 269, 'mphb_last_name', 'nguyễn'),
(1238, 269, 'mphb_phone', '0129754374'),
(1239, 269, 'mphb_country', 'AZ'),
(1240, 269, 'mphb_state', ''),
(1241, 269, 'mphb_city', ''),
(1242, 269, 'mphb_zip', ''),
(1243, 269, 'mphb_address1', ''),
(1244, 269, 'mphb_total_price', '1000000'),
(1245, 269, 'mphb_ical_prodid', ''),
(1246, 269, 'mphb_ical_summary', ''),
(1247, 269, 'mphb_ical_description', ''),
(1248, 269, 'mphb_language', 'vi'),
(1249, 269, '_mphb_checkout_id', '9079a0a19cd241e194d4306ca70b52f8'),
(1250, 270, '_mphb_room_id', '258'),
(1251, 270, '_mphb_rate_id', '261'),
(1252, 270, '_mphb_adults', '2'),
(1253, 270, '_mphb_children', '0'),
(1254, 270, '_mphb_services', 'a:0:{}'),
(1255, 270, '_mphb_guest_name', 'nguyễn văn hoài'),
(1256, 270, '_mphb_uid', 'e70a40e34b71444b866e7a439c258a05@localhost'),
(1257, 269, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng VIP\",\"rate\":\"Gi\\u00e1 ph\\u00f2ng VIP\",\"list\":{\"2019-10-05\":\"1000000\"},\"total\":\"1000000\",\"discount\":\"0\",\"discount_total\":\"1000000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"1000000\",\"discount_total\":\"1000000\"}],\"total\":\"1000000\"}'),
(1258, 269, '_edit_lock', '1570439318:1'),
(1259, 269, '_edit_last', '1'),
(1260, 269, '_id', '269'),
(1261, 269, 'mphb_coupon_id', ''),
(1317, 273, '_edit_lock', '1592473521:1'),
(1318, 273, '_wp_page_template', 'templates/contact.php'),
(1319, 273, '_edit_last', '1'),
(1320, 273, '_yoast_wpseo_content_score', '30'),
(1340, 278, '_menu_item_type', 'post_type'),
(1341, 278, '_menu_item_menu_item_parent', '0'),
(1342, 278, '_menu_item_object_id', '273'),
(1343, 278, '_menu_item_object', 'page'),
(1344, 278, '_menu_item_target', ''),
(1345, 278, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1346, 278, '_menu_item_xfn', ''),
(1347, 278, '_menu_item_url', ''),
(1349, 280, '_wp_attached_file', '2019/09/an-uong.jpg'),
(1350, 280, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:4:\"file\";s:19:\"2019/09/an-uong.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"an-uong-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"an-uong-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"an-uong-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:20:\"an-uong-1024x650.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:19:\"an-uong-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1352, 281, '_wp_attached_file', '2019/09/massage.jpg'),
(1353, 281, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:696;s:6:\"height\";i:436;s:4:\"file\";s:19:\"2019/09/massage.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"massage-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"massage-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:19:\"massage-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1354, 282, '_wp_attached_file', '2019/09/xe-may.jpg'),
(1355, 282, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:530;s:6:\"height\";i:297;s:4:\"file\";s:18:\"2019/09/xe-may.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"xe-may-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"xe-may-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:18:\"xe-may-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1358, 285, '_menu_item_type', 'taxonomy'),
(1359, 285, '_menu_item_menu_item_parent', '0'),
(1360, 285, '_menu_item_object_id', '10'),
(1361, 285, '_menu_item_object', 'category'),
(1362, 285, '_menu_item_target', ''),
(1363, 285, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1364, 285, '_menu_item_xfn', ''),
(1365, 285, '_menu_item_url', ''),
(1376, 287, '_menu_item_type', 'custom'),
(1377, 287, '_menu_item_menu_item_parent', '0'),
(1378, 287, '_menu_item_object_id', '287'),
(1379, 287, '_menu_item_object', 'custom'),
(1380, 287, '_menu_item_target', ''),
(1381, 287, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1382, 287, '_menu_item_xfn', ''),
(1383, 287, '_menu_item_url', 'http://localhost:8080/hotel01/accommodation'),
(1388, 291, '_edit_lock', '1571372160:1'),
(1389, 292, '_wp_attached_file', '2019/10/Bach-Ma-Village-Hue-ivivu-13.jpg'),
(1390, 292, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1080;s:6:\"height\";i:1349;s:4:\"file\";s:40:\"2019/10/Bach-Ma-Village-Hue-ivivu-13.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"Bach-Ma-Village-Hue-ivivu-13-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"Bach-Ma-Village-Hue-ivivu-13-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"Bach-Ma-Village-Hue-ivivu-13-768x959.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:959;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"Bach-Ma-Village-Hue-ivivu-13-820x1024.jpg\";s:5:\"width\";i:820;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:41:\"Bach-Ma-Village-Hue-ivivu-13-1080x650.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:40:\"Bach-Ma-Village-Hue-ivivu-13-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1393, 291, '_thumbnail_id', '292'),
(1394, 291, '_edit_last', '1'),
(1397, 291, '_yoast_wpseo_primary_category', '10'),
(1398, 291, '_yoast_wpseo_content_score', '30'),
(1403, 1, '_wp_old_slug', 'hello-world'),
(1409, 291, '_wp_old_slug', 'huong-dan-duong-di-bach-ma-village-hue__trashed'),
(1520, 301, '_wp_attached_file', '2019/10/Superior-1-1.jpg'),
(1521, 301, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2019/10/Superior-1-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Superior-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Superior-1-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Superior-1-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"Superior-1-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"Superior-1-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"Superior-1-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1522, 302, '_wp_attached_file', '2019/10/Superior-2-1.jpg'),
(1523, 302, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2019/10/Superior-2-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Superior-2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Superior-2-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Superior-2-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"Superior-2-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"Superior-2-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"Superior-2-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1524, 303, '_wp_attached_file', '2019/10/Superior-3-1.jpg'),
(1525, 303, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2019/10/Superior-3-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Superior-3-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Superior-3-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Superior-3-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"Superior-3-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"Superior-3-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"Superior-3-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1539, 304, '_edit_last', '1'),
(1540, 304, '_edit_lock', '1592301349:1'),
(1541, 304, '_thumbnail_id', '302'),
(1542, 304, '_yoast_wpseo_primary_mphb_room_type_category', '4'),
(1543, 304, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1544, 304, 'mphb_adults_capacity', '2'),
(1545, 304, 'mphb_children_capacity', '0'),
(1546, 304, 'mphb_size', '28'),
(1547, 304, 'mphb_view', 'Từ cửa sổ phòng ngủ hoặc ban công riêng, quý khách có thể ngắm nhìn toàn cảnh thành phố Huế'),
(1548, 304, 'mphb_bed', 'Giường đôi Queen-size, Giường đôi King-size hoặc 02 giường đơn Twin-size'),
(1549, 304, 'mphb_gallery', '303,301,302'),
(1550, 304, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1551, 305, 'mphb_room_type_id', '304'),
(1552, 306, 'mphb_room_type_id', '304'),
(1553, 307, 'mphb_room_type_id', '304'),
(1554, 308, 'mphb_room_type_id', '304'),
(1555, 309, 'mphb_room_type_id', '304'),
(1556, 310, 'mphb_room_type_id', '304'),
(1557, 311, 'mphb_room_type_id', '304'),
(1558, 312, 'mphb_room_type_id', '304'),
(1559, 313, 'mphb_room_type_id', '304'),
(1560, 314, 'mphb_room_type_id', '304'),
(1561, 304, '_yoast_wpseo_content_score', '60'),
(1562, 316, '_edit_last', '1'),
(1563, 316, 'mphb_room_type_id', '304'),
(1564, 316, 'mphb_description', ''),
(1565, 316, '_edit_lock', '1592301777:1'),
(1566, 316, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:1000000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:1:{i:0;a:3:{s:6:\"adults\";i:1;s:8:\"children\";i:0;s:6:\"prices\";a:1:{i:0;s:0:\"\";}}}}}}'),
(1567, 317, '_edit_last', '1'),
(1568, 317, '_edit_lock', '1592301330:1'),
(1569, 318, '_wp_attached_file', '2020/06/Deluxe-City-View-1-1.jpg'),
(1570, 318, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:32:\"2020/06/Deluxe-City-View-1-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"Deluxe-City-View-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"Deluxe-City-View-1-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"Deluxe-City-View-1-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"Deluxe-City-View-1-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:33:\"Deluxe-City-View-1-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:32:\"Deluxe-City-View-1-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1571, 319, '_wp_attached_file', '2020/06/Deluxe-City-View-2.jpg'),
(1572, 319, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/Deluxe-City-View-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1573, 320, '_wp_attached_file', '2020/06/Deluxe-City-View-3.jpg'),
(1574, 320, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/Deluxe-City-View-3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-3-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-3-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-3-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-3-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1575, 321, '_wp_attached_file', '2020/06/Deluxe-City-View-4.jpg'),
(1576, 321, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/Deluxe-City-View-4.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-4-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-4-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-4-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-City-View-4-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"Deluxe-City-View-4-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1577, 317, '_thumbnail_id', '318'),
(1578, 317, '_yoast_wpseo_primary_mphb_room_type_category', ''),
(1579, 317, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1580, 317, 'mphb_adults_capacity', '2'),
(1581, 317, 'mphb_children_capacity', '0'),
(1582, 317, 'mphb_size', '34'),
(1583, 317, 'mphb_view', 'Từ cửa sổ phòng ngủ hoặc ban công riêng, quý khách có thể ngắm nhìn toàn cảnh thành phố Huế'),
(1584, 317, 'mphb_bed', 'Giường đôi Queen-size, Giường đôi King-size hoặc 02 giường đơn Twin-size'),
(1585, 317, 'mphb_gallery', '318,319,320,321'),
(1586, 317, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1587, 322, 'mphb_room_type_id', '317'),
(1588, 323, 'mphb_room_type_id', '317'),
(1589, 324, 'mphb_room_type_id', '317'),
(1590, 325, 'mphb_room_type_id', '317'),
(1591, 326, 'mphb_room_type_id', '317'),
(1592, 327, 'mphb_room_type_id', '317'),
(1593, 328, 'mphb_room_type_id', '317'),
(1594, 329, 'mphb_room_type_id', '317'),
(1595, 330, 'mphb_room_type_id', '317'),
(1596, 331, 'mphb_room_type_id', '317'),
(1597, 317, '_yoast_wpseo_content_score', '60'),
(1598, 332, '_edit_last', '1'),
(1599, 332, '_edit_lock', '1592301551:1'),
(1600, 332, 'mphb_room_type_id', '317'),
(1601, 332, 'mphb_description', ''),
(1602, 332, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:1500000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1603, 333, '_edit_last', '1'),
(1604, 333, '_edit_lock', '1592301307:1'),
(1605, 334, '_wp_attached_file', '2020/06/Deluxe-River-View-1.jpg'),
(1606, 334, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Deluxe-River-View-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1607, 335, '_wp_attached_file', '2020/06/Deluxe-River-View-2.jpg'),
(1608, 335, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Deluxe-River-View-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1609, 336, '_wp_attached_file', '2020/06/Deluxe-River-View-3.jpg'),
(1610, 336, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Deluxe-River-View-3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-3-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-3-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Deluxe-River-View-3-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Deluxe-River-View-3-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1611, 333, '_thumbnail_id', '334'),
(1612, 333, '_yoast_wpseo_primary_mphb_room_type_category', '4'),
(1613, 333, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1614, 333, 'mphb_adults_capacity', '2'),
(1615, 333, 'mphb_children_capacity', '0'),
(1616, 333, 'mphb_size', '34'),
(1617, 333, 'mphb_view', 'Ban công riêng hướng sông'),
(1618, 333, 'mphb_bed', 'Giường đôi Queen-size, Giường đôi King-size hoặc 02 giường đơn Twin-size'),
(1619, 333, 'mphb_gallery', '334,335,336'),
(1620, 333, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1621, 337, 'mphb_room_type_id', '333'),
(1622, 338, 'mphb_room_type_id', '333'),
(1623, 339, 'mphb_room_type_id', '333'),
(1624, 340, 'mphb_room_type_id', '333'),
(1625, 341, 'mphb_room_type_id', '333'),
(1626, 342, 'mphb_room_type_id', '333'),
(1627, 343, 'mphb_room_type_id', '333'),
(1628, 344, 'mphb_room_type_id', '333'),
(1629, 345, 'mphb_room_type_id', '333'),
(1630, 346, 'mphb_room_type_id', '333'),
(1631, 333, '_yoast_wpseo_content_score', '60'),
(1632, 347, '_edit_last', '1'),
(1633, 347, '_edit_lock', '1592301517:1'),
(1634, 347, 'mphb_room_type_id', '333'),
(1635, 347, 'mphb_description', ''),
(1636, 347, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:1500000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1637, 348, '_edit_last', '1'),
(1638, 348, '_edit_lock', '1592301284:1'),
(1639, 349, '_wp_attached_file', '2020/06/Signature-Suite-1-2.jpg'),
(1640, 349, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Signature-Suite-1-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-1-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-1-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-1-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-1-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-1-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-1-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1641, 350, '_wp_attached_file', '2020/06/Signature-Suite-2-2.jpg'),
(1642, 350, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Signature-Suite-2-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-2-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-2-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-2-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-2-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-2-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-2-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1643, 351, '_wp_attached_file', '2020/06/Signature-Suite-3-2.jpg'),
(1644, 351, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Signature-Suite-3-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-3-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-3-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-3-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-3-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-3-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-3-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1645, 352, '_wp_attached_file', '2020/06/Signature-Suite-4-2.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1646, 352, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Signature-Suite-4-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-4-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-4-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-4-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-4-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Signature-Suite-4-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Signature-Suite-4-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1647, 348, '_thumbnail_id', '350'),
(1648, 348, '_yoast_wpseo_primary_mphb_room_type_category', '3'),
(1649, 348, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1650, 348, 'mphb_adults_capacity', '2'),
(1651, 348, 'mphb_children_capacity', '0'),
(1652, 348, 'mphb_size', '50'),
(1653, 348, 'mphb_view', 'Ban công riêng hướng sông'),
(1654, 348, 'mphb_bed', 'Giường đôi King-size'),
(1655, 348, 'mphb_gallery', '349,350,351,352'),
(1656, 348, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1657, 353, 'mphb_room_type_id', '348'),
(1658, 354, 'mphb_room_type_id', '348'),
(1659, 355, 'mphb_room_type_id', '348'),
(1660, 356, 'mphb_room_type_id', '348'),
(1661, 357, 'mphb_room_type_id', '348'),
(1662, 358, 'mphb_room_type_id', '348'),
(1663, 359, 'mphb_room_type_id', '348'),
(1664, 360, 'mphb_room_type_id', '348'),
(1665, 361, 'mphb_room_type_id', '348'),
(1666, 362, 'mphb_room_type_id', '348'),
(1667, 348, '_yoast_wpseo_content_score', '60'),
(1668, 363, '_edit_last', '1'),
(1669, 363, '_edit_lock', '1592301467:1'),
(1670, 363, 'mphb_room_type_id', '348'),
(1671, 363, 'mphb_description', ''),
(1672, 363, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:2000000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1673, 364, '_edit_last', '1'),
(1674, 364, '_edit_lock', '1592396173:1'),
(1675, 365, '_wp_attached_file', '2020/06/Junior-King-Suite-1.jpg'),
(1676, 365, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Junior-King-Suite-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Junior-King-Suite-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Junior-King-Suite-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1677, 366, '_wp_attached_file', '2020/06/Junior-King-Suite-2.jpg'),
(1678, 366, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:31:\"2020/06/Junior-King-Suite-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Junior-King-Suite-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:32:\"Junior-King-Suite-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:31:\"Junior-King-Suite-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1679, 364, '_thumbnail_id', '366'),
(1680, 364, '_yoast_wpseo_primary_mphb_room_type_category', '3'),
(1681, 364, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1682, 364, 'mphb_adults_capacity', '2'),
(1683, 364, 'mphb_children_capacity', '2'),
(1684, 364, 'mphb_size', '75'),
(1685, 364, 'mphb_view', 'Ban công riêng hoặc cửa sổ phòng hướng sông'),
(1686, 364, 'mphb_bed', 'Giường đôi King-size'),
(1687, 364, 'mphb_gallery', '365,366'),
(1688, 364, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1689, 367, 'mphb_room_type_id', '364'),
(1690, 368, 'mphb_room_type_id', '364'),
(1691, 369, 'mphb_room_type_id', '364'),
(1692, 370, 'mphb_room_type_id', '364'),
(1693, 371, 'mphb_room_type_id', '364'),
(1694, 364, '_yoast_wpseo_content_score', '60'),
(1695, 372, '_edit_last', '1'),
(1696, 372, 'mphb_room_type_id', '364'),
(1697, 372, 'mphb_description', ''),
(1698, 372, '_edit_lock', '1592301428:1'),
(1699, 372, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:2500000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1700, 373, '_edit_last', '1'),
(1701, 373, '_edit_lock', '1593166808:1'),
(1702, 374, '_wp_attached_file', '2020/06/King-Suite-1.jpg'),
(1703, 374, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2020/06/King-Suite-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"King-Suite-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"King-Suite-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"King-Suite-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"King-Suite-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"King-Suite-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"King-Suite-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1704, 375, '_wp_attached_file', '2020/06/King-Suite-2.jpg'),
(1705, 375, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2020/06/King-Suite-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"King-Suite-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"King-Suite-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"King-Suite-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"King-Suite-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"King-Suite-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"King-Suite-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1706, 376, '_wp_attached_file', '2020/06/King-Suite-3.jpg'),
(1707, 376, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:24:\"2020/06/King-Suite-3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"King-Suite-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"King-Suite-3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"King-Suite-3-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"King-Suite-3-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:25:\"King-Suite-3-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:24:\"King-Suite-3-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1708, 377, '_wp_attached_file', '2020/06/King-Suite-Garden.jpg'),
(1709, 377, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:29:\"2020/06/King-Suite-Garden.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"King-Suite-Garden-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"King-Suite-Garden-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"King-Suite-Garden-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"King-Suite-Garden-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:30:\"King-Suite-Garden-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:29:\"King-Suite-Garden-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1710, 373, '_thumbnail_id', '374'),
(1711, 373, '_yoast_wpseo_primary_mphb_room_type_category', '3'),
(1712, 373, '_yoast_wpseo_primary_mphb_room_type_facility', '8'),
(1713, 373, 'mphb_adults_capacity', '2'),
(1714, 373, 'mphb_children_capacity', '0'),
(1715, 373, 'mphb_size', '100'),
(1716, 373, 'mphb_view', 'Ban công riêng hướng sông'),
(1717, 373, 'mphb_bed', 'Giường đôi King-size'),
(1718, 373, 'mphb_gallery', '374,375,376,377'),
(1719, 373, 'mphb_services', 'a:4:{i:0;s:3:\"395\";i:1;s:3:\"391\";i:2;s:3:\"390\";i:3;s:3:\"384\";}'),
(1720, 378, 'mphb_room_type_id', '373'),
(1721, 379, 'mphb_room_type_id', '373'),
(1722, 380, 'mphb_room_type_id', '373'),
(1723, 381, 'mphb_room_type_id', '373'),
(1724, 382, 'mphb_room_type_id', '373'),
(1725, 373, '_yoast_wpseo_content_score', '60'),
(1726, 383, '_edit_last', '1'),
(1727, 383, '_edit_lock', '1592301402:1'),
(1728, 383, 'mphb_room_type_id', '373'),
(1729, 383, 'mphb_description', ''),
(1730, 383, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"220\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:3000000;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1743, 384, '_edit_last', '1'),
(1744, 384, '_edit_lock', '1592474391:1'),
(1745, 385, '_wp_attached_file', '2020/06/nhahang.jpg'),
(1746, 385, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:724;s:6:\"height\";i:531;s:4:\"file\";s:19:\"2020/06/nhahang.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"nhahang-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"nhahang-300x220.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:19:\"nhahang-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 5D Mark II\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1387105995\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"135\";s:3:\"iso\";s:3:\"160\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1747, 386, '_wp_attached_file', '2020/06/Venus-Restaurant-1.jpg'),
(1748, 386, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/Venus-Restaurant-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Venus-Restaurant-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"Venus-Restaurant-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1749, 387, '_wp_attached_file', '2020/06/Venus-Restaurant-2.jpg'),
(1750, 387, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/Venus-Restaurant-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Venus-Restaurant-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"Venus-Restaurant-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"Venus-Restaurant-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1751, 388, '_wp_attached_file', '2020/06/VIP-Dinning-room-2.jpg'),
(1752, 388, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:30:\"2020/06/VIP-Dinning-room-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"VIP-Dinning-room-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"VIP-Dinning-room-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"VIP-Dinning-room-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"VIP-Dinning-room-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:31:\"VIP-Dinning-room-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:30:\"VIP-Dinning-room-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1753, 384, '_thumbnail_id', '388'),
(1754, 384, 'mphb_price', '1000000'),
(1755, 384, 'mphb_price_periodicity', 'once'),
(1756, 384, 'mphb_min_quantity', '1'),
(1757, 384, 'mphb_is_auto_limit', '0'),
(1758, 384, 'mphb_max_quantity', ''),
(1759, 384, 'mphb_price_quantity', 'once'),
(1760, 384, '_yoast_wpseo_content_score', '60'),
(1761, 390, '_edit_last', '1'),
(1762, 390, '_edit_lock', '1592473580:1'),
(1763, 390, 'mphb_price', '200000'),
(1764, 390, 'mphb_price_periodicity', 'once'),
(1765, 390, 'mphb_min_quantity', '1'),
(1766, 390, 'mphb_is_auto_limit', '0'),
(1767, 390, 'mphb_max_quantity', ''),
(1768, 390, 'mphb_price_quantity', 'per_adult'),
(1769, 390, '_yoast_wpseo_content_score', '60'),
(1770, 390, '_thumbnail_id', '386'),
(1771, 391, '_edit_last', '1'),
(1772, 391, '_edit_lock', '1592473619:1'),
(1773, 392, '_wp_attached_file', '2020/06/Lunar-Bar-1.jpg'),
(1774, 392, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:23:\"2020/06/Lunar-Bar-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"Lunar-Bar-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:24:\"Lunar-Bar-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1775, 393, '_wp_attached_file', '2020/06/Lunar-Bar-2.jpg'),
(1776, 393, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:23:\"2020/06/Lunar-Bar-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"Lunar-Bar-2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:24:\"Lunar-Bar-2-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:23:\"Lunar-Bar-2-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1777, 394, '_wp_attached_file', '2020/06/View-from-Rooftop-Bar-1.jpg'),
(1778, 394, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2362;s:6:\"height\";i:1772;s:4:\"file\";s:35:\"2020/06/View-from-Rooftop-Bar-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"View-from-Rooftop-Bar-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"View-from-Rooftop-Bar-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"View-from-Rooftop-Bar-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"View-from-Rooftop-Bar-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:36:\"View-from-Rooftop-Bar-1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:35:\"View-from-Rooftop-Bar-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1779, 391, '_thumbnail_id', '394'),
(1780, 391, 'mphb_price', '500000'),
(1781, 391, 'mphb_price_periodicity', 'per_night'),
(1782, 391, 'mphb_min_quantity', '1'),
(1783, 391, 'mphb_is_auto_limit', '0'),
(1784, 391, 'mphb_max_quantity', ''),
(1785, 391, 'mphb_price_quantity', 'per_adult'),
(1786, 391, '_yoast_wpseo_content_score', '60'),
(1787, 395, '_edit_last', '1'),
(1788, 395, '_edit_lock', '1593166532:1'),
(1789, 396, '_wp_attached_file', '2020/06/moonspa_vi.jpg'),
(1790, 396, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:708;s:6:\"height\";i:311;s:4:\"file\";s:22:\"2020/06/moonspa_vi.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"moonspa_vi-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"moonspa_vi-300x132.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:132;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:22:\"moonspa_vi-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1791, 395, '_thumbnail_id', '396'),
(1792, 395, 'mphb_price', '200000'),
(1793, 395, 'mphb_price_periodicity', 'once'),
(1794, 395, 'mphb_min_quantity', '1'),
(1795, 395, 'mphb_is_auto_limit', '0'),
(1796, 395, 'mphb_max_quantity', ''),
(1797, 395, 'mphb_price_quantity', 'per_adult'),
(1798, 395, '_yoast_wpseo_content_score', '60'),
(1813, 398, '_edit_lock', '1592291084:1'),
(1814, 398, '_wp_trash_meta_status', 'publish'),
(1815, 398, '_wp_trash_meta_time', '1592291099'),
(1816, 399, '_wp_trash_meta_status', 'publish'),
(1817, 399, '_wp_trash_meta_time', '1592291160'),
(1819, 401, '_edit_lock', '1592292023:1'),
(1820, 402, '_wp_attached_file', '2020/06/home_slide1.jpg'),
(1821, 402, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:23:\"2020/06/home_slide1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"home_slide1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"home_slide1-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"home_slide1-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"home_slide1-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:24:\"home_slide1-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:23:\"home_slide1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1822, 403, '_wp_attached_file', '2020/06/MoonlightHotel-Dinning-Special-Slide.jpg'),
(1823, 403, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:48:\"2020/06/MoonlightHotel-Dinning-Special-Slide.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Dinning-Special-Slide-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Dinning-Special-Slide-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Dinning-Special-Slide-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:49:\"MoonlightHotel-Dinning-Special-Slide-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:49:\"MoonlightHotel-Dinning-Special-Slide-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Dinning-Special-Slide-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1824, 404, '_wp_attached_file', '2020/06/MoonlightHotel-Leisure-Breaks-Slide.jpg'),
(1825, 404, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:47:\"2020/06/MoonlightHotel-Leisure-Breaks-Slide.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Leisure-Breaks-Slide-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Leisure-Breaks-Slide-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Leisure-Breaks-Slide-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Leisure-Breaks-Slide-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:48:\"MoonlightHotel-Leisure-Breaks-Slide-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Leisure-Breaks-Slide-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1826, 405, '_wp_attached_file', '2020/06/MoonlightHotel-Moonshine-Spa-Slide.jpg'),
(1827, 405, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:46:\"2020/06/MoonlightHotel-Moonshine-Spa-Slide.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"MoonlightHotel-Moonshine-Spa-Slide-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"MoonlightHotel-Moonshine-Spa-Slide-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:46:\"MoonlightHotel-Moonshine-Spa-Slide-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Moonshine-Spa-Slide-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:47:\"MoonlightHotel-Moonshine-Spa-Slide-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:46:\"MoonlightHotel-Moonshine-Spa-Slide-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1828, 406, '_wp_attached_file', '2020/06/MoonlightHotel-Slide-03.jpg'),
(1829, 406, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:35:\"2020/06/MoonlightHotel-Slide-03.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"MoonlightHotel-Slide-03-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"MoonlightHotel-Slide-03-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"MoonlightHotel-Slide-03-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"MoonlightHotel-Slide-03-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:36:\"MoonlightHotel-Slide-03-1650x650.jpg\";s:5:\"width\";i:1650;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:35:\"MoonlightHotel-Slide-03-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1830, 401, '_thumbnail_id', '406'),
(1831, 401, '_edit_last', '1'),
(1832, 401, '_yoast_wpseo_content_score', '60'),
(1833, 408, '_edit_lock', '1592292129:1'),
(1834, 408, '_thumbnail_id', '405'),
(1835, 408, '_edit_last', '1'),
(1836, 408, '_yoast_wpseo_content_score', '60'),
(1837, 410, '_edit_lock', '1592292194:1'),
(1838, 410, '_thumbnail_id', '403'),
(1839, 410, '_edit_last', '1'),
(1840, 410, '_yoast_wpseo_content_score', '60'),
(1841, 412, '_edit_lock', '1592293413:1'),
(1842, 412, '_thumbnail_id', '402'),
(1843, 412, '_edit_last', '1'),
(1844, 412, '_yoast_wpseo_content_score', '60'),
(1845, 414, '_edit_lock', '1592292292:1'),
(1846, 414, '_thumbnail_id', '404'),
(1847, 414, '_edit_last', '1'),
(1848, 414, '_yoast_wpseo_content_score', '60'),
(1849, 416, '_edit_lock', '1592292360:1'),
(1850, 416, '_wp_trash_meta_status', 'publish'),
(1851, 416, '_wp_trash_meta_time', '1592292391'),
(1852, 417, '_wp_trash_meta_status', 'publish'),
(1853, 417, '_wp_trash_meta_time', '1592292435'),
(1854, 418, '_wp_trash_meta_status', 'publish'),
(1855, 418, '_wp_trash_meta_time', '1592292451'),
(1856, 420, 'mphb_key', 'booking_420_5ee878ca0a4151.16425875'),
(1857, 420, 'mphb_check_in_date', '2020-06-17'),
(1858, 420, 'mphb_check_out_date', '2020-06-18'),
(1859, 420, 'mphb_note', ''),
(1860, 420, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(1861, 420, 'mphb_first_name', 'hoài'),
(1862, 420, 'mphb_last_name', 'Nguyễn'),
(1863, 420, 'mphb_phone', '028374374'),
(1864, 420, 'mphb_country', 'ME'),
(1865, 420, 'mphb_state', ''),
(1866, 420, 'mphb_city', ''),
(1867, 420, 'mphb_zip', ''),
(1868, 420, 'mphb_address1', ''),
(1869, 420, 'mphb_total_price', '5000000'),
(1870, 420, 'mphb_ical_prodid', ''),
(1871, 420, 'mphb_ical_summary', ''),
(1872, 420, 'mphb_ical_description', ''),
(1873, 420, 'mphb_language', 'vi'),
(1874, 420, '_mphb_checkout_id', 'f68cee57b0cd4fa588ccb58c36f4a538'),
(1875, 421, '_mphb_room_id', '367'),
(1876, 421, '_mphb_rate_id', '372'),
(1877, 421, '_mphb_adults', '2'),
(1878, 421, '_mphb_children', '2'),
(1879, 421, '_mphb_services', 'a:0:{}'),
(1880, 421, '_mphb_guest_name', 'hoai'),
(1881, 421, '_mphb_uid', 'a7d18ffa0e08491fb1a9826d4ba4bec6@localhost'),
(1882, 422, '_mphb_room_id', '368'),
(1883, 422, '_mphb_rate_id', '372'),
(1884, 422, '_mphb_adults', '2'),
(1885, 422, '_mphb_children', '2'),
(1886, 422, '_mphb_services', 'a:0:{}'),
(1887, 422, '_mphb_guest_name', 'trung'),
(1888, 422, '_mphb_uid', 'a5ebec76bf9e4433bd7c160d48ac472b@localhost'),
(1889, 420, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite\",\"list\":{\"2020-06-17\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite\",\"list\":{\"2020-06-17\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"}],\"total\":\"5000000\"}'),
(1890, 269, '_wp_trash_meta_status', 'confirmed'),
(1891, 269, '_wp_trash_meta_time', '1592293620'),
(1892, 269, '_wp_desired_post_slug', '269'),
(1893, 269, '_wp_trash_meta_comments_status', 'a:10:{i:33;s:1:\"1\";i:34;s:1:\"1\";i:35;s:1:\"1\";i:36;s:1:\"1\";i:37;s:1:\"1\";i:38;s:1:\"1\";i:39;s:1:\"1\";i:40;s:1:\"1\";i:41;s:1:\"1\";i:46;s:1:\"1\";}'),
(1894, 420, '_edit_lock', '1592294214:1'),
(1895, 420, '_edit_last', '1'),
(1896, 420, '_id', '420'),
(1897, 420, 'mphb_coupon_id', ''),
(1902, 427, '_wp_attached_file', '2020/06/cropped-logo.png'),
(1903, 427, '_wp_attachment_context', 'custom-logo'),
(1904, 427, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:154;s:6:\"height\";i:80;s:4:\"file\";s:24:\"2020/06/cropped-logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"cropped-logo-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1905, 428, '_edit_lock', '1592298522:1'),
(1913, 432, '_wp_attached_file', '2020/06/logo3.jpg'),
(1914, 432, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:37;s:6:\"height\";i:37;s:4:\"file\";s:17:\"2020/06/logo3.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1915, 428, '_wp_trash_meta_status', 'publish'),
(1916, 428, '_wp_trash_meta_time', '1592298534'),
(1917, 433, '_wp_attached_file', '2020/06/logo.png'),
(1918, 433, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:154;s:6:\"height\";i:70;s:4:\"file\";s:16:\"2020/06/logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1919, 434, '_edit_lock', '1592298623:1'),
(1920, 434, '_wp_trash_meta_status', 'publish'),
(1921, 434, '_wp_trash_meta_time', '1592298628'),
(1922, 435, '_wp_trash_meta_status', 'publish'),
(1923, 435, '_wp_trash_meta_time', '1592298822'),
(1924, 143, '_flamingo', 'a:1:{s:7:\"channel\";i:13;}'),
(1925, 436, '_subject', 'đặt phòng'),
(1926, 436, '_from', 'hoài <nguyenvanhoai1280@gmail.com>'),
(1927, 436, '_from_name', 'hoài'),
(1928, 436, '_from_email', 'nguyenvanhoai1280@gmail.com'),
(1929, 436, '_field_your-name', 'hoài'),
(1930, 436, '_field_your-email', 'nguyenvanhoai1280@gmail.com'),
(1931, 436, '_field_your-subject', 'đặt phòng'),
(1932, 436, '_field_your-message', 'tôi muốn đặt phòng'),
(1933, 436, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}'),
(1934, 436, '_meta', 'a:19:{s:13:\"serial_number\";i:1;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:38:\"http://localhost:8080/hotel01/lien-he/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:17 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(1935, 436, '_akismet', NULL),
(1936, 436, '_recaptcha', 'a:0:{}'),
(1937, 436, '_spam_log', 'a:0:{}'),
(1938, 436, '_consent', 'a:0:{}'),
(1939, 437, '_subject', 'đặt phòng'),
(1940, 437, '_from', 'hoài <nguyenvanhoai1280@gmail.com>'),
(1941, 437, '_from_name', 'hoài'),
(1942, 437, '_from_email', 'nguyenvanhoai1280@gmail.com'),
(1943, 437, '_field_your-name', 'hoài'),
(1944, 437, '_field_your-email', 'nguyenvanhoai1280@gmail.com'),
(1945, 437, '_field_your-subject', 'đặt phòng'),
(1946, 437, '_field_your-message', 'tôi muốn đặt phòng vip'),
(1947, 437, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}'),
(1948, 437, '_meta', 'a:19:{s:13:\"serial_number\";i:2;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:38:\"http://localhost:8080/hotel01/lien-he/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:18 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(1949, 437, '_akismet', NULL),
(1950, 437, '_recaptcha', 'a:0:{}'),
(1951, 437, '_spam_log', 'a:0:{}'),
(1952, 437, '_consent', 'a:0:{}'),
(1953, 438, '_subject', 'đặt phòng'),
(1954, 438, '_from', 'hoài <nguyenvanhoai1280@gmail.com>'),
(1955, 438, '_from_name', 'hoài'),
(1956, 438, '_from_email', 'nguyenvanhoai1280@gmail.com'),
(1957, 438, '_field_your-name', 'hoài'),
(1958, 438, '_field_your-email', 'nguyenvanhoai1280@gmail.com'),
(1959, 438, '_field_your-subject', 'đặt phòng'),
(1960, 438, '_field_your-message', 'ss'),
(1961, 438, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}'),
(1962, 438, '_meta', 'a:19:{s:13:\"serial_number\";i:3;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:38:\"http://localhost:8080/hotel01/lien-he/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:22 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(1963, 438, '_akismet', NULL),
(1964, 438, '_recaptcha', 'a:0:{}'),
(1965, 438, '_spam_log', 'a:0:{}'),
(1966, 438, '_consent', 'a:0:{}'),
(1967, 439, '_subject', 'đặt phòng'),
(1968, 439, '_from', 'hoài <nguyenthimynga0505@gmail.com>'),
(1969, 439, '_from_name', 'hoài'),
(1970, 439, '_from_email', 'nguyenthimynga0505@gmail.com'),
(1971, 439, '_field_your-name', 'hoài'),
(1972, 439, '_field_your-email', 'nguyenthimynga0505@gmail.com'),
(1973, 439, '_field_your-subject', 'đặt phòng'),
(1974, 439, '_field_your-message', 'đ'),
(1975, 439, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}'),
(1976, 439, '_meta', 'a:19:{s:13:\"serial_number\";i:4;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:30:\"http://localhost:8080/hotel01/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:25 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(1977, 439, '_akismet', NULL),
(1978, 439, '_recaptcha', 'a:0:{}'),
(1979, 439, '_spam_log', 'a:0:{}'),
(1980, 439, '_consent', 'a:0:{}'),
(1981, 440, '_subject', 'đặt phòng'),
(1982, 440, '_from', 'hoài <nguyenthimynga0505@gmail.com>'),
(1983, 440, '_from_name', 'hoài'),
(1984, 440, '_from_email', 'nguyenthimynga0505@gmail.com'),
(1985, 440, '_field_your-name', 'hoài'),
(1986, 440, '_field_your-email', 'nguyenthimynga0505@gmail.com'),
(1987, 440, '_field_your-subject', 'đặt phòng'),
(1988, 440, '_field_your-message', 'sda'),
(1989, 440, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}'),
(1990, 440, '_meta', 'a:19:{s:13:\"serial_number\";i:5;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:30:\"http://localhost:8080/hotel01/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:29 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(1991, 440, '_akismet', NULL),
(1992, 440, '_recaptcha', 'a:0:{}'),
(1993, 440, '_spam_log', 'a:0:{}'),
(1994, 440, '_consent', 'a:0:{}'),
(1995, 441, '_email', 'nguyenthimynga0505@gmail.com'),
(1996, 441, '_name', 'hoài'),
(1997, 441, '_props', 'a:0:{}'),
(1998, 441, '_last_contacted', '2020-06-26 17:24:11'),
(1999, 442, '_subject', 'đặt phòng'),
(2000, 442, '_from', 'hoài <nguyenthimynga0505@gmail.com>'),
(2001, 442, '_from_name', 'hoài'),
(2002, 442, '_from_email', 'nguyenthimynga0505@gmail.com'),
(2003, 442, '_field_your-name', 'hoài'),
(2004, 442, '_field_your-email', 'nguyenthimynga0505@gmail.com'),
(2005, 442, '_field_your-subject', 'đặt phòng'),
(2006, 442, '_field_your-message', 'cc'),
(2007, 442, '_fields', 'a:4:{s:9:\"your-name\";N;s:10:\"your-email\";N;s:12:\"your-subject\";N;s:12:\"your-message\";N;}');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2008, 442, '_meta', 'a:19:{s:13:\"serial_number\";i:6;s:9:\"remote_ip\";s:3:\"::1\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\";s:3:\"url\";s:30:\"http://localhost:8080/hotel01/\";s:4:\"date\";s:10:\"16/06/2020\";s:4:\"time\";s:12:\"4:38 chiều\";s:7:\"post_id\";s:0:\"\";s:9:\"post_name\";s:0:\"\";s:10:\"post_title\";s:0:\"\";s:8:\"post_url\";s:0:\"\";s:11:\"post_author\";s:0:\"\";s:17:\"post_author_email\";s:0:\"\";s:10:\"site_title\";s:15:\"Moonlight Hotel\";s:16:\"site_description\";s:31:\"Thiên đường nghĩ dưỡng\";s:8:\"site_url\";s:29:\"http://localhost:8080/hotel01\";s:16:\"site_admin_email\";s:27:\"nguyenvanhoai1280@gmail.com\";s:10:\"user_login\";s:0:\"\";s:10:\"user_email\";s:0:\"\";s:17:\"user_display_name\";s:0:\"\";}'),
(2009, 442, '_akismet', NULL),
(2010, 442, '_recaptcha', 'a:0:{}'),
(2011, 442, '_spam_log', 'a:0:{}'),
(2012, 442, '_consent', 'a:0:{}'),
(2013, 443, 'mphb_key', 'booking_443_5ee895a8a1b598.31664849'),
(2014, 443, 'mphb_check_in_date', '2020-06-17'),
(2015, 443, 'mphb_check_out_date', '2020-06-18'),
(2016, 443, 'mphb_note', 'yfg'),
(2017, 443, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2018, 443, 'mphb_first_name', 'hoài'),
(2019, 443, 'mphb_last_name', 'Nguyễn'),
(2020, 443, 'mphb_phone', '084367876'),
(2021, 443, 'mphb_country', 'AR'),
(2022, 443, 'mphb_state', ''),
(2023, 443, 'mphb_city', ''),
(2024, 443, 'mphb_zip', ''),
(2025, 443, 'mphb_address1', ''),
(2026, 443, 'mphb_total_price', '4500000'),
(2027, 443, 'mphb_ical_prodid', ''),
(2028, 443, 'mphb_ical_summary', ''),
(2029, 443, 'mphb_ical_description', ''),
(2030, 443, 'mphb_language', 'vi'),
(2031, 443, '_mphb_checkout_id', 'cbaa64ee2bff4effa1484b5bbb649bf1'),
(2032, 444, '_mphb_room_id', '322'),
(2033, 444, '_mphb_rate_id', '332'),
(2034, 444, '_mphb_adults', '2'),
(2035, 444, '_mphb_children', '0'),
(2036, 444, '_mphb_services', 'a:0:{}'),
(2037, 444, '_mphb_guest_name', 'hoai'),
(2038, 444, '_mphb_uid', '4b4f5e97055c49e899cb558074c94b19@localhost'),
(2039, 445, '_mphb_room_id', '323'),
(2040, 445, '_mphb_rate_id', '332'),
(2041, 445, '_mphb_adults', '2'),
(2042, 445, '_mphb_children', '0'),
(2043, 445, '_mphb_services', 'a:0:{}'),
(2044, 445, '_mphb_guest_name', 'trung'),
(2045, 445, '_mphb_uid', '238d6624495446d09344685e7dc87186@localhost'),
(2046, 446, '_mphb_room_id', '324'),
(2047, 446, '_mphb_rate_id', '332'),
(2048, 446, '_mphb_adults', '2'),
(2049, 446, '_mphb_children', '0'),
(2050, 446, '_mphb_services', 'a:0:{}'),
(2051, 446, '_mphb_guest_name', 'v'),
(2052, 446, '_mphb_uid', '00285d936cee4715aa6f4ce402e6673b@localhost'),
(2053, 443, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Deluxe City View\",\"rate\":\"Gi\\u00e1 ph\\u00f2ng Deluxe City View\",\"list\":{\"2020-06-17\":\"1500000\"},\"total\":\"1500000\",\"discount\":\"0\",\"discount_total\":\"1500000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"1500000\",\"discount_total\":\"1500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Deluxe City View\",\"rate\":\"Gi\\u00e1 ph\\u00f2ng Deluxe City View\",\"list\":{\"2020-06-17\":\"1500000\"},\"total\":\"1500000\",\"discount\":\"0\",\"discount_total\":\"1500000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"1500000\",\"discount_total\":\"1500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Deluxe City View\",\"rate\":\"Gi\\u00e1 ph\\u00f2ng Deluxe City View\",\"list\":{\"2020-06-17\":\"1500000\"},\"total\":\"1500000\",\"discount\":\"0\",\"discount_total\":\"1500000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"1500000\",\"discount_total\":\"1500000\"}],\"total\":\"4500000\"}'),
(2054, 443, '_edit_lock', '1592302250:1'),
(2055, 443, '_edit_last', '1'),
(2056, 443, '_id', '443'),
(2057, 443, 'mphb_coupon_id', ''),
(2060, 447, 'mphb_key', 'booking_447_5ee8992298bb25.77647488'),
(2061, 447, 'mphb_check_in_date', '2020-06-17'),
(2062, 447, 'mphb_check_out_date', '2020-06-18'),
(2063, 447, 'mphb_note', 'cho anh 1 phòng vip'),
(2064, 447, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2065, 447, 'mphb_first_name', 'Hoài'),
(2066, 447, 'mphb_last_name', 'Nguyễn'),
(2067, 447, 'mphb_phone', '0335163902'),
(2068, 447, 'mphb_country', 'VN'),
(2069, 447, 'mphb_state', ''),
(2070, 447, 'mphb_city', ''),
(2071, 447, 'mphb_zip', ''),
(2072, 447, 'mphb_address1', ''),
(2073, 447, 'mphb_total_price', '3000000'),
(2074, 447, 'mphb_ical_prodid', ''),
(2075, 447, 'mphb_ical_summary', ''),
(2076, 447, 'mphb_ical_description', ''),
(2077, 447, 'mphb_language', 'vi'),
(2078, 447, '_mphb_checkout_id', '3b7b3e496e564285830ec931ba7dd61e'),
(2079, 448, '_mphb_room_id', '378'),
(2080, 448, '_mphb_rate_id', '383'),
(2081, 448, '_mphb_adults', '2'),
(2082, 448, '_mphb_children', '0'),
(2083, 448, '_mphb_services', 'a:4:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:2;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:3;a:3:{s:2:\"id\";i:384;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2084, 448, '_mphb_guest_name', 'Nguyễn Văn Hoài'),
(2085, 448, '_mphb_uid', '96b5508a29314d868ef8daee0bb94fa0@localhost'),
(2086, 447, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng King Suite 3.000.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-17\":\"3000000\"},\"total\":\"3000000\",\"discount\":\"0\",\"discount_total\":\"3000000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"VIP DINING ROOM\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"3000000\",\"discount_total\":\"3000000\"}],\"total\":\"3000000\"}'),
(2087, 447, '_edit_lock', '1592302680:1'),
(2088, 447, '_edit_last', '1'),
(2089, 447, '_id', '447'),
(2090, 447, 'mphb_coupon_id', ''),
(2091, 449, 'mphb_key', 'booking_449_5ee89b24ed0ac1.63404989'),
(2092, 449, 'mphb_check_in_date', '2020-06-17'),
(2093, 449, 'mphb_check_out_date', '2020-06-18'),
(2094, 449, 'mphb_note', 'cho anh 1 phòng vip'),
(2095, 449, 'mphb_email', 'fesockfam@gmail.com'),
(2096, 449, 'mphb_first_name', 'Trung'),
(2097, 449, 'mphb_last_name', 'Trần'),
(2098, 449, 'mphb_phone', '0866949201'),
(2099, 449, 'mphb_country', 'VN'),
(2100, 449, 'mphb_state', ''),
(2101, 449, 'mphb_city', ''),
(2102, 449, 'mphb_zip', ''),
(2103, 449, 'mphb_address1', ''),
(2104, 449, 'mphb_total_price', '3000000'),
(2105, 449, 'mphb_ical_prodid', ''),
(2106, 449, 'mphb_ical_summary', ''),
(2107, 449, 'mphb_ical_description', ''),
(2108, 449, 'mphb_language', 'vi'),
(2109, 449, '_mphb_checkout_id', '42be07ad8bcc4deaacc99918c0aecbd7'),
(2110, 450, '_mphb_room_id', '379'),
(2111, 450, '_mphb_rate_id', '383'),
(2112, 450, '_mphb_adults', '2'),
(2113, 450, '_mphb_children', '0'),
(2114, 450, '_mphb_services', 'a:4:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:2;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:3;a:3:{s:2:\"id\";i:384;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2115, 450, '_mphb_guest_name', 'Trần Đình Minh Trung'),
(2116, 450, '_mphb_uid', 'fb4c811fb26a4b3ca6d57f1b871f7445@localhost'),
(2117, 449, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng King Suite 3.000.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-17\":\"3000000\"},\"total\":\"3000000\",\"discount\":\"0\",\"discount_total\":\"3000000\",\"adults\":\"2\",\"children\":\"0\",\"children_capacity\":\"0\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"VIP DINING ROOM\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"3000000\",\"discount_total\":\"3000000\"}],\"total\":\"3000000\"}'),
(2118, 449, '_edit_lock', '1592302326:1'),
(2119, 449, '_edit_last', '1'),
(2120, 449, '_id', '449'),
(2121, 449, 'mphb_coupon_id', ''),
(2122, 451, '_mphb_key', 'payment_451_5ee89b861f4911.61353730'),
(2123, 451, '_mphb_logs', 'a:3:{i:0;a:2:{s:4:\"date\";s:19:\"2020-06-16 17:14:30\";s:7:\"message\";s:69:\"Trạng thái thay đổi từ Mới thành Dự thảo tự động.\";}i:1;a:2:{s:4:\"date\";s:19:\"2020-06-16 17:14:44\";s:7:\"message\";s:75:\"Trạng thái thay đổi từ Dự thảo tự động thành Bản nháp.\";}i:2;a:2:{s:4:\"date\";s:19:\"2020-06-16 17:14:44\";s:7:\"message\";s:68:\"Trạng thái thay đổi từ Bản nháp thành Đã hoàn thành.\";}}'),
(2124, 451, '_edit_last', '1'),
(2125, 451, '_id', '451'),
(2126, 451, '_mphb_gateway', 'manual'),
(2127, 451, '_mphb_gateway_mode', 'live'),
(2128, 451, '_mphb_amount', '3000000'),
(2129, 451, '_mphb_fee', '0'),
(2130, 451, '_mphb_currency', 'VND'),
(2131, 451, '_mphb_payment_type', ''),
(2132, 451, '_mphb_transaction_id', ''),
(2133, 451, '_mphb_booking_id', '449'),
(2134, 451, '_mphb_first_name', 'Trung'),
(2135, 451, '_mphb_last_name', 'Trần'),
(2136, 451, '_mphb_email', 'fesockfam@gmail.com'),
(2137, 451, '_mphb_phone', '0866949201'),
(2138, 451, '_mphb_country', ''),
(2139, 451, '_mphb_address1', ''),
(2140, 451, '_mphb_address2', ''),
(2141, 451, '_mphb_city', ''),
(2142, 451, '_mphb_state', ''),
(2143, 451, '_mphb_zip', ''),
(2144, 451, '_edit_lock', '1592302348:1'),
(2179, 455, 'mphb_key', 'booking_455_5eea08f7a1cc31.76105058'),
(2180, 455, 'mphb_check_in_date', '2020-06-18'),
(2181, 455, 'mphb_check_out_date', '2020-06-19'),
(2182, 455, 'mphb_note', 'dat p'),
(2183, 455, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2184, 455, 'mphb_first_name', 'Hoài'),
(2185, 455, 'mphb_last_name', 'Nguyễn'),
(2186, 455, 'mphb_phone', '0335163902'),
(2187, 455, 'mphb_country', 'VN'),
(2188, 455, 'mphb_state', ''),
(2189, 455, 'mphb_city', ''),
(2190, 455, 'mphb_zip', ''),
(2191, 455, 'mphb_address1', ''),
(2192, 455, 'mphb_total_price', '5000000'),
(2193, 455, 'mphb_ical_prodid', ''),
(2194, 455, 'mphb_ical_summary', ''),
(2195, 455, 'mphb_ical_description', ''),
(2196, 455, 'mphb_language', 'vi'),
(2197, 455, '_mphb_checkout_id', '328a79ee912d452199cf1fe7f9e8a577'),
(2198, 456, '_mphb_room_id', '367'),
(2199, 456, '_mphb_rate_id', '372'),
(2200, 456, '_mphb_adults', '2'),
(2201, 456, '_mphb_children', '2'),
(2202, 456, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2203, 456, '_mphb_guest_name', 'Nguyễn Văn Hoài'),
(2204, 456, '_mphb_uid', '5f4452c8572c4eab9887dadc1a629daa@localhost'),
(2205, 457, '_mphb_room_id', '368'),
(2206, 457, '_mphb_rate_id', '372'),
(2207, 457, '_mphb_adults', '2'),
(2208, 457, '_mphb_children', '2'),
(2209, 457, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:384;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2210, 457, '_mphb_guest_name', 'trung'),
(2211, 457, '_mphb_uid', '5b9c36f28de34e03950d31cd62fd7dc9@localhost'),
(2212, 455, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-18\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-18\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"VIP DINING ROOM\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"}],\"total\":\"5000000\"}'),
(2213, 455, '_edit_lock', '1592396875:1'),
(2214, 455, '_edit_last', '1'),
(2215, 455, '_id', '455'),
(2216, 455, 'mphb_coupon_id', ''),
(2217, 458, '_mphb_key', 'payment_458_5eea0959218852.41549348'),
(2218, 458, '_mphb_logs', 'a:3:{i:0;a:2:{s:4:\"date\";s:19:\"2020-06-17 19:15:21\";s:7:\"message\";s:69:\"Trạng thái thay đổi từ Mới thành Dự thảo tự động.\";}i:1;a:2:{s:4:\"date\";s:19:\"2020-06-17 19:15:30\";s:7:\"message\";s:75:\"Trạng thái thay đổi từ Dự thảo tự động thành Bản nháp.\";}i:2;a:2:{s:4:\"date\";s:19:\"2020-06-17 19:15:31\";s:7:\"message\";s:68:\"Trạng thái thay đổi từ Bản nháp thành Đã hoàn thành.\";}}'),
(2219, 458, '_edit_last', '1'),
(2220, 458, '_id', '458'),
(2221, 458, '_mphb_gateway', 'manual'),
(2222, 458, '_mphb_gateway_mode', 'live'),
(2223, 458, '_mphb_amount', '5000000'),
(2224, 458, '_mphb_fee', '0'),
(2225, 458, '_mphb_currency', 'VND'),
(2226, 458, '_mphb_payment_type', ''),
(2227, 458, '_mphb_transaction_id', ''),
(2228, 458, '_mphb_booking_id', '455'),
(2229, 458, '_mphb_first_name', 'Hoài'),
(2230, 458, '_mphb_last_name', 'Nguyễn'),
(2231, 458, '_mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2232, 458, '_mphb_phone', '0335163902'),
(2233, 458, '_mphb_country', ''),
(2234, 458, '_mphb_address1', ''),
(2235, 458, '_mphb_address2', ''),
(2236, 458, '_mphb_city', ''),
(2237, 458, '_mphb_state', ''),
(2238, 458, '_mphb_zip', ''),
(2239, 458, '_edit_lock', '1592395992:1'),
(2240, 367, '_edit_lock', '1592467058:1'),
(2241, 459, 'mphb_key', 'booking_459_5eeb19473e9a39.03173917'),
(2242, 459, 'mphb_check_in_date', '2020-06-19'),
(2243, 459, 'mphb_check_out_date', '2020-06-20'),
(2244, 459, 'mphb_note', ''),
(2245, 459, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2246, 459, 'mphb_first_name', 'Hoài'),
(2247, 459, 'mphb_last_name', 'Nguyễn'),
(2248, 459, 'mphb_phone', '0335163902'),
(2249, 459, 'mphb_country', 'VN'),
(2250, 459, 'mphb_state', ''),
(2251, 459, 'mphb_city', ''),
(2252, 459, 'mphb_zip', ''),
(2253, 459, 'mphb_address1', ''),
(2254, 459, 'mphb_total_price', '5000000'),
(2255, 459, 'mphb_ical_prodid', ''),
(2256, 459, 'mphb_ical_summary', ''),
(2257, 459, 'mphb_ical_description', ''),
(2258, 459, 'mphb_language', 'vi'),
(2259, 459, '_mphb_checkout_id', '7b014161f6cf4ee0a688a7a6de995090'),
(2260, 460, '_mphb_room_id', '367'),
(2261, 460, '_mphb_rate_id', '372'),
(2262, 460, '_mphb_adults', '2'),
(2263, 460, '_mphb_children', '2'),
(2264, 460, '_mphb_services', 'a:3:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:2;a:3:{s:2:\"id\";i:384;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2265, 460, '_mphb_guest_name', 'Nguyễn Văn Hoài'),
(2266, 460, '_mphb_uid', '926b62711126424ba2f49fea4e748b46@localhost'),
(2267, 461, '_mphb_room_id', '368'),
(2268, 461, '_mphb_rate_id', '372'),
(2269, 461, '_mphb_adults', '2'),
(2270, 461, '_mphb_children', '2'),
(2271, 461, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2272, 461, '_mphb_guest_name', 'trung'),
(2273, 461, '_mphb_uid', 'fe53b1d9c28a4d74aac1398da4e772e9@localhost'),
(2274, 459, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-19\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"VIP DINING ROOM\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-19\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"2\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"}],\"total\":\"5000000\"}'),
(2275, 459, '_edit_lock', '1592469850:1'),
(2276, 305, '_edit_last', '1'),
(2277, 305, '_edit_lock', '1592466730:1'),
(2278, 306, '_edit_last', '1'),
(2279, 306, '_edit_lock', '1592466740:1'),
(2280, 307, '_edit_last', '1'),
(2281, 307, '_edit_lock', '1592466749:1'),
(2282, 308, '_edit_last', '1'),
(2283, 308, '_edit_lock', '1592466757:1'),
(2284, 309, '_edit_last', '1'),
(2285, 309, '_edit_lock', '1592466764:1'),
(2286, 310, '_edit_last', '1'),
(2287, 310, '_edit_lock', '1592466770:1'),
(2288, 311, '_edit_last', '1'),
(2289, 311, '_edit_lock', '1592466776:1'),
(2290, 312, '_edit_last', '1'),
(2291, 312, '_edit_lock', '1592466782:1'),
(2292, 313, '_edit_last', '1'),
(2293, 313, '_edit_lock', '1592466789:1'),
(2294, 314, '_edit_last', '1'),
(2295, 314, '_edit_lock', '1592466801:1'),
(2296, 322, '_edit_last', '1'),
(2297, 322, '_edit_lock', '1592466814:1'),
(2298, 323, '_edit_last', '1'),
(2299, 323, '_edit_lock', '1592466820:1'),
(2300, 324, '_edit_last', '1'),
(2301, 324, '_edit_lock', '1592466825:1'),
(2302, 325, '_edit_last', '1'),
(2303, 325, '_edit_lock', '1592466833:1'),
(2304, 326, '_edit_last', '1'),
(2305, 326, '_edit_lock', '1592466839:1'),
(2306, 327, '_edit_last', '1'),
(2307, 327, '_edit_lock', '1592466846:1'),
(2308, 328, '_edit_last', '1'),
(2309, 328, '_edit_lock', '1592466851:1'),
(2310, 329, '_edit_last', '1'),
(2311, 329, '_edit_lock', '1592466857:1'),
(2312, 330, '_edit_last', '1'),
(2313, 330, '_edit_lock', '1592466864:1'),
(2314, 331, '_edit_last', '1'),
(2315, 331, '_edit_lock', '1592466870:1'),
(2316, 338, '_edit_last', '1'),
(2317, 338, '_edit_lock', '1592466888:1'),
(2318, 339, '_edit_last', '1'),
(2319, 339, '_edit_lock', '1592466895:1'),
(2320, 340, '_edit_last', '1'),
(2321, 340, '_edit_lock', '1592466903:1'),
(2322, 341, '_edit_last', '1'),
(2323, 341, '_edit_lock', '1592466913:1'),
(2324, 342, '_edit_last', '1'),
(2325, 342, '_edit_lock', '1592466925:1'),
(2326, 343, '_edit_last', '1'),
(2327, 343, '_edit_lock', '1592466931:1'),
(2328, 344, '_edit_last', '1'),
(2329, 344, '_edit_lock', '1592466937:1'),
(2330, 345, '_edit_last', '1'),
(2331, 345, '_edit_lock', '1592466943:1'),
(2332, 346, '_edit_last', '1'),
(2333, 346, '_edit_lock', '1592466948:1'),
(2334, 337, '_edit_last', '1'),
(2335, 337, '_edit_lock', '1592466953:1'),
(2336, 360, '_edit_last', '1'),
(2337, 360, '_edit_lock', '1592466974:1'),
(2338, 361, '_edit_last', '1'),
(2339, 361, '_edit_lock', '1592466980:1'),
(2340, 362, '_edit_last', '1'),
(2341, 362, '_edit_lock', '1592466986:1'),
(2342, 353, '_edit_last', '1'),
(2343, 353, '_edit_lock', '1592466993:1'),
(2344, 354, '_edit_last', '1'),
(2345, 354, '_edit_lock', '1592467003:1'),
(2346, 355, '_edit_last', '1'),
(2347, 355, '_edit_lock', '1592467012:1'),
(2348, 356, '_edit_last', '1'),
(2349, 356, '_edit_lock', '1592467017:1'),
(2350, 357, '_edit_last', '1'),
(2351, 357, '_edit_lock', '1592467023:1'),
(2352, 358, '_edit_last', '1'),
(2353, 358, '_edit_lock', '1592467031:1'),
(2354, 359, '_edit_last', '1'),
(2355, 359, '_edit_lock', '1592467038:1'),
(2356, 371, '_edit_last', '1'),
(2357, 371, '_edit_lock', '1592467052:1'),
(2358, 367, '_edit_last', '1'),
(2359, 368, '_edit_last', '1'),
(2360, 368, '_edit_lock', '1592467064:1'),
(2361, 369, '_edit_last', '1'),
(2362, 369, '_edit_lock', '1592467071:1'),
(2363, 370, '_edit_last', '1'),
(2364, 370, '_edit_lock', '1592467078:1'),
(2365, 378, '_edit_last', '1'),
(2366, 378, '_edit_lock', '1592467093:1'),
(2367, 379, '_edit_last', '1'),
(2368, 379, '_edit_lock', '1592467099:1'),
(2369, 380, '_edit_last', '1'),
(2370, 380, '_edit_lock', '1592467108:1'),
(2371, 381, '_edit_last', '1'),
(2372, 381, '_edit_lock', '1592467115:1'),
(2373, 382, '_edit_last', '1'),
(2374, 382, '_edit_lock', '1592467120:1'),
(2375, 462, 'mphb_key', 'booking_462_5eeb2197941e38.83914393'),
(2376, 462, 'mphb_check_in_date', '2020-06-19'),
(2377, 462, 'mphb_check_out_date', '2020-06-20'),
(2378, 462, 'mphb_note', ''),
(2379, 462, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2380, 462, 'mphb_first_name', 'Hoài'),
(2381, 462, 'mphb_last_name', 'Nguyễn'),
(2382, 462, 'mphb_phone', '0335163902'),
(2383, 462, 'mphb_country', 'VN'),
(2384, 462, 'mphb_state', ''),
(2385, 462, 'mphb_city', ''),
(2386, 462, 'mphb_zip', ''),
(2387, 462, 'mphb_address1', ''),
(2388, 462, 'mphb_total_price', '5000000'),
(2389, 462, 'mphb_ical_prodid', ''),
(2390, 462, 'mphb_ical_summary', ''),
(2391, 462, 'mphb_ical_description', ''),
(2392, 462, 'mphb_language', 'vi'),
(2393, 462, '_mphb_checkout_id', '5f9831929263481bb20358d6be6dcc53'),
(2394, 463, '_mphb_room_id', '369'),
(2395, 463, '_mphb_rate_id', '372'),
(2396, 463, '_mphb_adults', '2'),
(2397, 463, '_mphb_children', '1'),
(2398, 463, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2399, 463, '_mphb_guest_name', 'Nguyễn Văn Hoài'),
(2400, 463, '_mphb_uid', '5b9a333a02424c9a85b71ad02ca30afa@localhost'),
(2401, 464, '_mphb_room_id', '370'),
(2402, 464, '_mphb_rate_id', '372'),
(2403, 464, '_mphb_adults', '1'),
(2404, 464, '_mphb_children', '1'),
(2405, 464, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2406, 464, '_mphb_guest_name', 'trung'),
(2407, 464, '_mphb_uid', 'd1f4597c5d874b149ecf37e0bbe6d9e1@localhost'),
(2408, 462, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-19\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"2\",\"children\":\"1\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"},{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-19\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"1\",\"children\":\"1\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"}],\"total\":\"5000000\"}'),
(2411, 466, '_mphb_key', 'payment_466_5eeb23544d4df6.21221999'),
(2412, 466, '_mphb_logs', 'a:3:{i:0;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:18:28\";s:7:\"message\";s:69:\"Trạng thái thay đổi từ Mới thành Dự thảo tự động.\";}i:1;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:18:44\";s:7:\"message\";s:75:\"Trạng thái thay đổi từ Dự thảo tự động thành Bản nháp.\";}i:2;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:18:44\";s:7:\"message\";s:68:\"Trạng thái thay đổi từ Bản nháp thành Đã hoàn thành.\";}}'),
(2413, 466, '_edit_last', '1'),
(2414, 466, '_id', '466'),
(2415, 466, '_mphb_gateway', 'manual'),
(2416, 466, '_mphb_gateway_mode', 'live'),
(2417, 466, '_mphb_amount', '5000000'),
(2418, 466, '_mphb_fee', '0'),
(2419, 466, '_mphb_currency', 'VND'),
(2420, 466, '_mphb_payment_type', ''),
(2421, 466, '_mphb_transaction_id', ''),
(2422, 466, '_mphb_booking_id', '462'),
(2423, 466, '_mphb_first_name', 'Hoài'),
(2424, 466, '_mphb_last_name', 'Nguyễn'),
(2425, 466, '_mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2426, 466, '_mphb_phone', '0335163902'),
(2427, 466, '_mphb_country', ''),
(2428, 466, '_mphb_address1', ''),
(2429, 466, '_mphb_address2', ''),
(2430, 466, '_mphb_city', ''),
(2431, 466, '_mphb_state', ''),
(2432, 466, '_mphb_zip', ''),
(2433, 466, '_edit_lock', '1592468187:1'),
(2434, 462, '_edit_lock', '1592468280:1'),
(2435, 462, '_edit_last', '1'),
(2436, 462, '_id', '462'),
(2437, 462, 'mphb_coupon_id', ''),
(2439, 467, '_mphb_key', 'payment_467_5eeb23c88053f8.07029774'),
(2440, 467, '_mphb_logs', 'a:3:{i:0;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:20:24\";s:7:\"message\";s:69:\"Trạng thái thay đổi từ Mới thành Dự thảo tự động.\";}i:1;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:20:44\";s:7:\"message\";s:75:\"Trạng thái thay đổi từ Dự thảo tự động thành Bản nháp.\";}i:2;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:20:44\";s:7:\"message\";s:68:\"Trạng thái thay đổi từ Bản nháp thành Đã hoàn thành.\";}}'),
(2441, 467, '_edit_last', '1'),
(2442, 467, '_id', '467'),
(2443, 467, '_mphb_gateway', 'manual'),
(2444, 467, '_mphb_gateway_mode', 'live'),
(2445, 467, '_mphb_amount', '0'),
(2446, 467, '_mphb_fee', '0'),
(2447, 467, '_mphb_currency', 'VND'),
(2448, 467, '_mphb_payment_type', ''),
(2449, 467, '_mphb_transaction_id', ''),
(2450, 467, '_mphb_booking_id', '462'),
(2451, 467, '_mphb_first_name', 'Hoài'),
(2452, 467, '_mphb_last_name', 'Nguyễn'),
(2453, 467, '_mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2454, 467, '_mphb_phone', '0335163902'),
(2455, 467, '_mphb_country', ''),
(2456, 467, '_mphb_address1', ''),
(2457, 467, '_mphb_address2', ''),
(2458, 467, '_mphb_city', ''),
(2459, 467, '_mphb_state', ''),
(2460, 467, '_mphb_zip', ''),
(2461, 467, '_edit_lock', '1592468309:1'),
(2465, 469, 'mphb_key', 'booking_469_5eeb2c3ad17834.94758871'),
(2466, 469, 'mphb_check_in_date', '2020-06-19'),
(2467, 469, 'mphb_check_out_date', '2020-06-20'),
(2468, 469, 'mphb_note', ''),
(2469, 469, 'mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2470, 469, 'mphb_first_name', 'Hoài'),
(2471, 469, 'mphb_last_name', 'Nguyễn'),
(2472, 469, 'mphb_phone', '0335163902'),
(2473, 469, 'mphb_country', 'VN'),
(2474, 469, 'mphb_state', ''),
(2475, 469, 'mphb_city', ''),
(2476, 469, 'mphb_zip', ''),
(2477, 469, 'mphb_address1', ''),
(2478, 469, 'mphb_total_price', '2500000'),
(2479, 469, 'mphb_ical_prodid', ''),
(2480, 469, 'mphb_ical_summary', ''),
(2481, 469, 'mphb_ical_description', ''),
(2482, 469, 'mphb_language', 'vi'),
(2483, 469, '_mphb_checkout_id', 'cadfe2cf0b9240baaf30447e798511d5'),
(2484, 470, '_mphb_room_id', '371'),
(2485, 470, '_mphb_rate_id', '372'),
(2486, 470, '_mphb_adults', '1'),
(2487, 470, '_mphb_children', '1'),
(2488, 470, '_mphb_services', 'a:3:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:390;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:2;a:3:{s:2:\"id\";i:384;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2489, 470, '_mphb_guest_name', 'Nguyễn Văn Hoài'),
(2490, 470, '_mphb_uid', '3ec7baf65e8b40ab8125bac65812de7b@localhost'),
(2491, 469, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-19\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"1\",\"children\":\"1\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"NH\\u00c0 H\\u00c0NG VENUS\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"},{\"title\":\"VIP DINING ROOM\",\"details\":\"<span class=\\\"mphb-price\\\">0&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span>\",\"total\":\"0\"}],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"2500000\",\"discount_total\":\"2500000\"}],\"total\":\"2500000\"}'),
(2492, 469, '_edit_lock', '1592470506:1'),
(2493, 469, '_edit_last', '1'),
(2494, 469, '_id', '469'),
(2495, 469, 'mphb_coupon_id', ''),
(2496, 471, '_mphb_key', 'payment_471_5eeb2c79bd3963.06281925'),
(2497, 471, '_mphb_logs', 'a:3:{i:0;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:57:29\";s:7:\"message\";s:69:\"Trạng thái thay đổi từ Mới thành Dự thảo tự động.\";}i:1;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:57:34\";s:7:\"message\";s:75:\"Trạng thái thay đổi từ Dự thảo tự động thành Bản nháp.\";}i:2;a:2:{s:4:\"date\";s:19:\"2020-06-18 15:57:34\";s:7:\"message\";s:68:\"Trạng thái thay đổi từ Bản nháp thành Đã hoàn thành.\";}}'),
(2498, 471, '_edit_last', '1'),
(2499, 471, '_id', '471'),
(2500, 471, '_mphb_gateway', 'manual'),
(2501, 471, '_mphb_gateway_mode', 'live'),
(2502, 471, '_mphb_amount', '2500000'),
(2503, 471, '_mphb_fee', '0'),
(2504, 471, '_mphb_currency', 'VND'),
(2505, 471, '_mphb_payment_type', ''),
(2506, 471, '_mphb_transaction_id', ''),
(2507, 471, '_mphb_booking_id', '469'),
(2508, 471, '_mphb_first_name', 'Hoài'),
(2509, 471, '_mphb_last_name', 'Nguyễn'),
(2510, 471, '_mphb_email', 'nguyenvanhoai1280@gmail.com'),
(2511, 471, '_mphb_phone', '0335163902'),
(2512, 471, '_mphb_country', ''),
(2513, 471, '_mphb_address1', ''),
(2514, 471, '_mphb_address2', ''),
(2515, 471, '_mphb_city', ''),
(2516, 471, '_mphb_state', ''),
(2517, 471, '_mphb_zip', ''),
(2518, 471, '_edit_lock', '1592470520:1'),
(2545, 249, '_wp_old_date', '2019-10-02'),
(2546, 441, '_wp_old_date', '2020-06-16'),
(2547, 486, '_wp_trash_meta_status', 'publish'),
(2548, 486, '_wp_trash_meta_time', '1593227836'),
(2549, 487, '_edit_lock', '1593228225:1'),
(2550, 487, '_customize_restore_dismissed', '1'),
(2551, 488, '_edit_lock', '1593230763:1'),
(2552, 488, '_customize_restore_dismissed', '1'),
(2553, 489, '_wp_trash_meta_status', 'publish'),
(2554, 489, '_wp_trash_meta_time', '1593230855'),
(2555, 490, '_wp_trash_meta_status', 'publish'),
(2556, 490, '_wp_trash_meta_time', '1593231344'),
(2557, 491, '_edit_lock', '1593233965:1'),
(2558, 491, '_customize_restore_dismissed', '1'),
(2559, 492, '_wp_trash_meta_status', 'publish'),
(2560, 492, '_wp_trash_meta_time', '1593233999'),
(2561, 493, 'mphb_key', 'booking_493_5ef705ab122bc8.45008813'),
(2562, 493, 'mphb_check_in_date', '2020-06-28'),
(2563, 493, 'mphb_check_out_date', '2020-06-29'),
(2564, 493, 'mphb_note', ''),
(2565, 493, 'mphb_email', 'vanhoang.htra@gmail.com'),
(2566, 493, 'mphb_first_name', 'Hoàng'),
(2567, 493, 'mphb_last_name', 'Nguyễn'),
(2568, 493, 'mphb_phone', '02232904'),
(2569, 493, 'mphb_country', 'VN'),
(2570, 493, 'mphb_state', ''),
(2571, 493, 'mphb_city', ''),
(2572, 493, 'mphb_zip', ''),
(2573, 493, 'mphb_address1', ''),
(2574, 493, 'mphb_total_price', '3200000'),
(2575, 493, 'mphb_ical_prodid', ''),
(2576, 493, 'mphb_ical_summary', ''),
(2577, 493, 'mphb_ical_description', ''),
(2578, 493, 'mphb_language', 'vi'),
(2579, 493, '_mphb_checkout_id', '56b1175c12744b4585ba00a4e3b8adee'),
(2580, 494, '_mphb_room_id', '367'),
(2581, 494, '_mphb_rate_id', '372'),
(2582, 494, '_mphb_adults', '1'),
(2583, 494, '_mphb_children', '0'),
(2584, 494, '_mphb_services', 'a:2:{i:0;a:3:{s:2:\"id\";i:395;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}i:1;a:3:{s:2:\"id\";i:391;s:6:\"adults\";i:1;s:8:\"quantity\";i:1;}}'),
(2585, 494, '_mphb_guest_name', 'Nguyễn Văn Hoàng'),
(2586, 494, '_mphb_uid', '96940c7a594d4b65a6d41146702f8c1c@localhost'),
(2587, 493, '_mphb_booking_price_breakdown', '{\"rooms\":[{\"room\":{\"type\":\"Ph\\u00f2ng Junior King Suite\",\"rate\":\"Gi\\u00e1 Ph\\u00f2ng Junior King Suite 2.500.000 vn\\u0111 / m\\u1ed7i \\u0111\\u00eam\",\"list\":{\"2020-06-28\":\"2500000\"},\"total\":\"2500000\",\"discount\":\"0\",\"discount_total\":\"2500000\",\"adults\":\"1\",\"children\":\"0\",\"children_capacity\":\"2\"},\"services\":{\"list\":[{\"title\":\"SPA MOONSHINE\",\"details\":\"<span class=\\\"mphb-price\\\">200,000&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span> &#215; 1 ng\\u01b0\\u1eddi l\\u1edbn\",\"total\":\"200000\"},{\"title\":\"BAR\",\"details\":\"<span class=\\\"mphb-price\\\">500,000&nbsp;<span class=\\\"mphb-currency\\\">&#8363;</span></span> &#215; 1 \\u0111\\u00eam &#215; 1 ng\\u01b0\\u1eddi l\\u1edbn\",\"total\":\"500000\"}],\"total\":\"700000\"},\"fees\":{\"list\":[],\"total\":\"0\"},\"taxes\":{\"room\":{\"list\":[],\"total\":\"0\"},\"services\":{\"list\":[],\"total\":\"0\"},\"fees\":{\"list\":[],\"total\":\"0\"}},\"total\":\"3200000\",\"discount_total\":\"3200000\"}],\"total\":\"3200000\"}'),
(2588, 493, '_edit_lock', '1593247262:1'),
(2589, 493, '_edit_last', '1'),
(2590, 493, '_id', '493'),
(2591, 493, 'mphb_coupon_id', ''),
(2593, 495, '_edit_lock', '1593311074:1'),
(2594, 496, '_wp_attached_file', '2020/06/huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1.jpg'),
(2595, 496, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:500;s:4:\"file\";s:62:\"2020/06/huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:62:\"huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:62:\"huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(2598, 495, '_thumbnail_id', '496'),
(2599, 495, '_edit_last', '1'),
(2602, 495, '_yoast_wpseo_primary_category', '10'),
(2603, 495, '_yoast_wpseo_content_score', '90'),
(2604, 498, '_edit_lock', '1593311448:1'),
(2605, 499, '_wp_attached_file', '2020/06/dac-san-hue-2-bun-bo-hue.jpg'),
(2606, 499, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:678;s:4:\"file\";s:36:\"2020/06/dac-san-hue-2-bun-bo-hue.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"dac-san-hue-2-bun-bo-hue-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"dac-san-hue-2-bun-bo-hue-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"dac-san-hue-2-bun-bo-hue-768x509.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:509;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"dac-san-hue-2-bun-bo-hue-1024x678.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:678;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"home_slider_img\";a:4:{s:4:\"file\";s:37:\"dac-san-hue-2-bun-bo-hue-1024x650.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"home_blog_img\";a:4:{s:4:\"file\";s:36:\"dac-san-hue-2-bun-bo-hue-360x270.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(2609, 498, '_thumbnail_id', '499'),
(2610, 498, '_edit_last', '1'),
(2613, 498, '_yoast_wpseo_primary_category', '10'),
(2614, 498, '_yoast_wpseo_content_score', '60'),
(2615, 501, '_wp_trash_meta_status', 'publish'),
(2616, 501, '_wp_trash_meta_time', '1593311646'),
(2617, 502, '_wp_trash_meta_status', 'publish'),
(2618, 502, '_wp_trash_meta_time', '1593311669'),
(2619, 503, '_wp_trash_meta_status', 'publish'),
(2620, 503, '_wp_trash_meta_time', '1593312409'),
(2621, 504, '_edit_lock', '1593312896:1'),
(2622, 504, '_wp_trash_meta_status', 'publish'),
(2623, 504, '_wp_trash_meta_time', '1593312911'),
(2624, 506, '_wp_trash_meta_status', 'publish'),
(2625, 506, '_wp_trash_meta_time', '1593312982'),
(2626, 507, '_edit_lock', '1593313974:1'),
(2627, 507, '_customize_restore_dismissed', '1'),
(2628, 508, '_wp_trash_meta_status', 'publish'),
(2629, 508, '_wp_trash_meta_time', '1593314025'),
(2630, 509, '_wp_trash_meta_status', 'publish'),
(2631, 509, '_wp_trash_meta_time', '1593317811'),
(2632, 510, '_edit_lock', '1593317866:1'),
(2633, 510, '_customize_restore_dismissed', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=511 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-09-06 01:50:01', '2019-09-05 18:50:01', '<!-- wp:paragraph -->\n<p>Lượn xe máy trên đèo Hải Vân không cảm thấy căng thẳng mà chỉ như đang bay lên cùng gió, cùng mây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khi bắt đầu dấn thân vào con đường ăn chơi bụi bặm bằng xe máy cũng là lúc tôi mê những con đèo. Cảm giác uốn lượn, quanh co lúc lên cao vút, lúc xuống vùn vụt khiến tôi phấn khích kỳ lạ. Bởi vậy mà suốt một thời gian dài tôi miệt mài \"cày\" những con đèo xứ Bắc với suy nghĩ: \"Đã đi đèo càng hiểm trở cảm giác càng mạnh, càng hay\".</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-4-1499820351587.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 1\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-1-1499820344338.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-2-1499820346861.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 3\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-3-1499820349180.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 4\"/><figcaption><em> Hải Vân mùa lau trắng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Rồi một lần đến Đà Nẵng,&nbsp;chạy xe máy&nbsp;ra Huế tôi nhận ra lâu nay mình đã thiếu sót khi trong bản đồ chinh phục những cung đường thiếu vắng đệ nhất hùng quan nước Nam:&nbsp;Đèo Hải Vân.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>So với những con đèo phía Bắc, đèo Hải Vân quá hiền. Một bên núi non mướt mát, một bên biển rộng mênh mông. Đường rộng, uốn lượn nhẹ nhàng với vài cái cua cùi chỏ không quá gắt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-5-1499820353589.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 5\"/><figcaption><em> Đi trên đèo Hải Vân rất dễ dàng bắt gặp những bãi biển trắng muốt làm đường viền cho biển </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Lần đầu tiên đi một con đèo mà không phải căng 4 giác quan lên để&nbsp;điều khiển xe&nbsp;tôi thấy hơi là lạ. Thư thả nên tôi chạy chậm, ngắm nghía cảnh quan và nhận ra lượn trên một con đèo hiền cảm giác thật bình yên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-7-1499820357593.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 6\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-6-1499820355570.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 7\"/><figcaption><em> Và thấy cả tuyến đường sắt đẹp uốn lượn giữa núi đồi xanh mát </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù không hiểm trở bằng những con đèo phía Bắc nhưng đèo Hải Vân đủ cao để đưa người ta lên tận cùng cảm xúc phiêu bồng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Cũng có núi cao vòi vọi, cũng có vực thẳm sâu hút nhưng núi non lúc nào cũng đầy hoa cỏ rập rờn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-8-1499820359584.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 8\"/><figcaption><em> Một khúc cua dịu dàng trên đèo Hải Vân </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Hôm tôi đi nhằm lúc hoa cỏ lau nở trắng. Lượn đèo trong tiếng gió vi vu, giữa những ngọn cỏ lau phất phới tôi có cảm giác mình như đang bay lên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trên đỉnh đèo Hải Vân là di tích Hải Vân Quan. Được xây dựng từ thời nhà Nguyễn, Hải Vân Quan giờ đây chỉ là những phế tích hoang tàn. Nhưng đứng bên dưới những phiến đá đồ sộ, nhìn bao quát cảnh quan mới hiểu hết câu ca dao:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>\"Đi bộ thì khiếp Hải Vân</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>Đi thuyền thì khiếp sóng thần Hang Dơi\"</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-9-1499820361662.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 9\"/><figcaption> <em>Từ Hải Vân Quan, bạn men theo con đường nhỏ là đến một nơi khoáng đạt, tuyệt vời như thế này </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Men theo con đường nhỏ bên hông di tích này, đi khoảng độ 1,5 km nữa sẽ có thể ngắm toàn cảnh con đèo cũng như&nbsp;vịnh Lăng Cô&nbsp;(tỉnh Thừa Thiên Huế).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đây thực sự là một nơi tuyệt vời để hít thở, nhìn ngắm và thư giãn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-12-1499820372303.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 10\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-10-1499820365426.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 11\"/><figcaption><em> Đến Hải Vân, bạn sẽ cảm thấy như mình đang bay lên cùng bềnh bồng mây trắng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù ở Đà Nẵng nhiệt độ lên đến 35 nhưng ở đây chỉ khoảng 22. Gió mát lồng lộng đưa những vạt mây thi thoảng sà xuống mát lạnh rồi bay đi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ớ phía Bắc, vịnh Lăng Cô hiện ra xanh ngắt với đường viền cát trắng đến nao lòng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Tôi thích núi hơn là thích biển bởi đứng giữa núi đồi bỗng thấy mình mạnh mẽ. Còn đứng trước biển dễ khiến người ta cô đơn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-11-1499820369100.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 12\"/><figcaption><em> Một chú bò thơ thẩn cùng mây </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tuy nhiên, khi đứng nhìn biển từ đệ nhất hùng quan nước Nam ngày hôm đó, tôi bỗng nhận ra núi không làm mình mạnh mẽ, biển cũng không làm mình cô đơn, cảm xúc duy nhất là sự bình yên, thanh sạch chưa từng trải qua.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khi tâm sự cảm xúc này với một người bạn Đà Nẵng, bạn nói: \"Hải Vân không chỉ là một con đèo, nó như một vật thể sống, chuyển mình từng phút, từng giây. Nên dù có đi bao nhiêu lần cũng không bao giờ thấy nhàm chán bởi mỗi lần là một cảm xúc khác nhau. Nếu có dịp hãy quay lại\".</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-13-1499820375592.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 13\"/><figcaption><em> Biển Lăng Cô nhìn Hải Vân </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nhất định, nếu có dịp tôi sẽ quay lại Hải Vân. Ngày đó không xa đâu!</p>\n<!-- /wp:paragraph -->', 'Phiêu bồng trên Hải Vân Quan', '', 'publish', 'open', 'open', '', 'phieu-bong-tren-hai-van-quan', '', '', '2019-10-30 14:52:23', '2019-10-30 07:52:23', '', 0, 'http://localhost/wordpress/?p=1', 0, 'post', '', 0),
(6, 1, '2019-09-06 02:20:00', '2019-09-05 19:20:00', '<!-- wp:paragraph -->\n<p>Trong dịp Tết, nhiều hoạt động sôi động diễn ra tại Hoàng cung Huế. Du khách có thể tìm hiểu về hoạt động đổi gác tại Ngọ Môn và tham gia các trò chơi dân gian, tận hưởng những bữa ăn cung đình Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trung tâm Bảo tồn Di tích Cố đô Huế vừa công bố nhiều chương trình hấp dẫn trong dịp Tết Nguyên đán mừng năm mới Mậu Tuất 2018 tại Hoàng Cung Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Theo đó, nghi lễ đầu tiên là Thướng Tiêu hay còn gọi là Dựng nêu. Đây là một nghi thức truyền thống của dân tộc và cũng là một nghi lễ quan trọng vào đầu năm mới của triều Nguyễn. Ngoài những quan niệm tâm linh của dân gian, lễ dựng nêu của triều Nguyễn còn có mục đich để báo hiệu ngày Tết đã tới.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-1-1518507137-90-width490height327.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 1\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Cô đô Huế hiện nay, lễ Dựng nêu tổ chức vào ngày 23 tháng Chạp tại Thế Miếu (từ 9h sáng) và điện Long An (từ 10h sáng) do Trung tâm Bảo tồn Di tích Cố đô Huế tái hiện lần đầu tiên từ năm 2013 và đã trở thành một truyền thống không thể thiếu ở khu di sản Huế khi bắt đầu một cái Tết cổ truyền.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đặc biệt, năm nay, sau nghi thức dựng nêu tại điện Long An, từ 10h30, tại khu vực nhà Tế Tửu, Trung tâm Bảo tồn Di tích Cố đô Huế còn tổ chức chương trình “Hương xưa bánh Tết”, có ý nghĩa là một khởi động đầu năm với những trải nghiệm về hương sắc Tết cũ qua những sắc màu truyền thống.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Chương trình “Hương xưa bánh Tết” bao gồm các âm điệu ca Huế; các trò chơi cung đình và dân gian (đổ xăm hường và bài vụ); trình diễn thư pháp tặng chữ, đặc biệt là hội thi gói bánh chưng, bánh tét... có sức gợi về cái Tết cổ truyền của dân tộc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Được biết trong cổ sử Việt Nam, tương truyền, vua Hùng Vương thứ sáu muốn tìm người tài kế vị, đã cho vời các hoàng tử lại và truyền rằng sẽ truyền ngôi cho người nào cung tiến được món sản vật thể hiện lòng hiếu đạo để tiến cúng tiên vương. Hoàng tử Lang Liêu đã dâng hai loại bánh chưng, bánh dày với biểu tượng trời tròn đất vuông được chế biến từ gạo nếp. Kể từ đó, bánh chưng đi vào lịch sử dân tộc, trở thành một nét văn hóa đặc sắc. Mỗi khi Tết đến xuân về, trên mâm cỗ cúng tổ tiên của người Việt Nam không thể thiếu bánh chưng, bánh tét.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trong không gian tràn ngập sắc xuân với các loại trang phục truyền thống, những đôi câu đối thắm, những sắc hoa xuân, du khách sẽ có cơ hội trải nghiệm qua những hình bóng của nếp xưa xứ Huế, nhất là không khí gói bánh chưng, bánh tét cũng những niêu bánh chưng nghi ngút, đượm nồng phong vị Tết.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trong Tết, nhiều hoạt động diễn ra tại Hoàng cung Huế. Nhân Tết Nguyên đán Mậu Tuất theo quy định, từ ngày mồng 1 đến mồng 3 Tết (16/2 – 18/2), khu di sản Huế sẽ mở cửa miễn phí đối với người Việt Nam. Trong dịp này, Trung tâm Bảo tồn Di tích Cố đô Huế sẽ tổ chức nhiều hoạt động vui Tết tại Hoàng cung (Đại Nội) để phục vụ nhân dân với nhiều hoạt động phong phú. Cụ thể như :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ngày mùng 1 Tết: Buổi sáng sẽ có lễ Đổi gác tại Ngọ Môn (lúc 9h); Múa Lân sư rồng tại sân trước điện Thái Hòa (lúc 9h30); Các trò chơi cung đình, trình diễn thư pháp tại Sân sau điện Thái Hòa (lúc 10h); Trình tấu Đại nhạc tại Thế Miếu (lúc 10h30). Buổi chiều sẽ có chương trình nghệ thuật \"Âm sắc cung đình\" tại Sân Điện Thái Hòa (từ 15h30 đến 16h15).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-3-1518507137-862-width800height536.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 3\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ngày Mùng 2 Tết: Buổi sáng có lễ Đổi gác tại Ngọ Môn (lúc 9h); Chương trình nghệ thuật \"Âm sắc cung đình\"tại Sân Điện Thái Hòa (từ 9h30 đến 10h15). Buổi chiều sẽ có trình diễn Võ thuật cổ truyền tại Sân Điện Thái Hòa (lúc 14h30); Múa Lân sư rồng tại Sân điện Cần Chánh (lúc 15h).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Mùng 3 Tết vào buổi sáng có lễ Đổi gác tại Ngọ Môn (lúc 9h); Trình tấu tiểu nhạc tại sân trước điện Thái Hòa (lúc 9h30); Múa lân sư rồng tại Sân điện Cần Chánh (lúc 10h); Trình tấu Đại nhạc tại Thế Miếu (lúc 10h30). Buổi chiều sẽ diễn ra trình diễn Võ thuật cổ truyền tại Sân trước điện Thái Hòa (lúc 14h và 15h30; Trình tấu tiểu nhạc tại sân trước điện Thái Hòa (lúc 14h30); Trình tấu Đại nhạc tại Thế Miếu (lúc 16h).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ngày 22.2 nhằm mùng 7 Tết sẽ có Lễ Hạ Nêu tại Thế Miếu (lúc 9h) và tại điện Long An (lúc 10h).</p>\n<!-- /wp:paragraph -->', 'Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung', '', 'publish', 'open', 'open', '', 've-hue-dip-tet-trai-nghiem-cuoc-song-chon-hoang-cung', '', '', '2019-09-23 15:42:13', '2019-09-23 08:42:13', '', 0, 'http://localhost/wordpress/?p=6', 0, 'post', '', 0),
(7, 1, '2019-09-06 02:19:50', '2019-09-06 02:19:50', '', 'download', '', 'inherit', 'open', 'closed', '', 'download', '', '', '2019-09-06 02:19:50', '2019-09-06 02:19:50', '', 6, 'http://localhost/wordpress/wp-content/uploads/2019/09/download.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2019-09-06 02:20:00', '2019-09-06 02:20:00', '', '120$/day', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-09-06 02:20:00', '2019-09-06 02:20:00', '', 6, 'http://localhost/wordpress/2019/09/06/6-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2019-09-06 03:00:09', '2019-09-06 03:00:09', '', 'Room Luxury', '', 'publish', 'open', 'closed', '', 'room-luxury', '', '', '2019-09-06 03:00:09', '2019-09-06 03:00:09', '', 0, 'http://localhost/wordpress/?post_type=hb_room&#038;p=17', 0, 'hb_room', '', 0),
(18, 1, '2019-09-06 03:00:09', '2019-09-06 03:00:09', '', 'Room Luxury', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2019-09-06 03:00:09', '2019-09-06 03:00:09', '', 17, 'http://localhost/wordpress/2019/09/06/17-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2019-09-06 07:33:05', '2019-09-06 00:33:05', '[mphb_rooms]', 'Loại phòng', '', 'publish', 'closed', 'closed', '', 'loai-phong', '', '', '2019-09-24 14:32:20', '2019-09-24 07:32:20', '', 0, 'http://localhost/wordpress/accommodations/', 0, 'page', '', 0),
(22, 1, '2019-09-06 07:33:05', '2019-09-06 00:33:05', '[mphb_availability_search]', 'Tìm kiếm sẵn có', '', 'publish', 'closed', 'closed', '', 'tim-kiem-san-co', '', '', '2019-09-24 14:33:54', '2019-09-24 07:33:54', '', 0, 'http://localhost/wordpress/search-availability/', 0, 'page', '', 0),
(23, 1, '2019-09-06 07:33:06', '2019-09-06 00:33:06', '[mphb_search_results]', 'Kết quả tìm kiếm', '', 'publish', 'closed', 'closed', '', 'ket-qua-tim-kiem', '', '', '2019-09-24 14:33:28', '2019-09-24 07:33:28', '', 0, 'http://localhost/wordpress/search-results/', 0, 'page', '', 0),
(24, 1, '2019-09-06 07:33:06', '2019-09-06 00:33:06', '[mphb_checkout]', 'Xác nhận đặt phòng', '', 'publish', 'closed', 'closed', '', 'xac-nhan-dat-phong', '', '', '2019-09-24 14:29:40', '2019-09-24 07:29:40', '', 0, 'http://localhost/wordpress/booking-confirmation/', 0, 'page', '', 0),
(25, 1, '2019-09-06 07:33:06', '2019-09-06 00:33:06', '[mphb_booking_confirmation]', 'Xác nhận đặt phòng', '', 'publish', 'closed', 'closed', '', 'xac-nhan-dat-phong', '', '', '2020-06-15 10:08:36', '2020-06-15 03:08:36', '', 24, 'http://localhost/wordpress/booking-confirmation/booking-confirmed/', 0, 'page', '', 0),
(26, 1, '2019-09-06 07:33:06', '2019-09-06 00:33:06', 'Your reservation is canceled.', 'Hủy đặt phòng', '', 'publish', 'closed', 'closed', '', 'huy-dat-phong', '', '', '2019-09-24 14:35:50', '2019-09-24 07:35:50', '', 24, 'http://localhost/wordpress/booking-confirmation/booking-canceled/', 0, 'page', '', 0),
(27, 1, '2019-09-06 07:33:06', '2019-09-06 00:33:06', '[mphb_booking_confirmation]', 'Thanh toán thành công', '', 'publish', 'closed', 'closed', '', 'thanh-toan-thanh-cong', '', '', '2020-06-15 10:08:36', '2020-06-15 03:08:36', '', 24, 'http://localhost/wordpress/booking-confirmation/payment-success/', 0, 'page', '', 0),
(28, 1, '2019-09-06 07:33:07', '2019-09-06 00:33:07', 'Unfortunately, your transaction cannot be completed at this time. Please try again or contact us.', 'Giao dịch thất bại', '', 'publish', 'closed', 'closed', '', 'giao-dich-that-bai', '', '', '2019-09-24 14:35:24', '2019-09-24 07:35:24', '', 24, 'http://localhost/wordpress/booking-confirmation/transaction-failed/', 0, 'page', '', 0),
(54, 1, '2019-09-06 07:59:23', '2019-09-06 07:59:23', '', 'Noel', '', 'trash', 'closed', 'closed', '', 'noel__trashed', '', '', '2019-09-23 16:55:52', '2019-09-23 09:55:52', '', 0, 'http://localhost/wordpress/?post_type=mphb_season&#038;p=54', 0, 'mphb_season', '', 0),
(109, 1, '2019-09-06 09:02:27', '2019-09-06 09:02:27', '', 'Trang chủ', '', 'publish', 'closed', 'closed', '', 'trang-chu', '', '', '2020-06-28 11:08:48', '2020-06-28 04:08:48', '', 0, 'http://localhost/wordpress/?p=109', 1, 'nav_menu_item', '', 0),
(128, 1, '2019-09-07 02:53:46', '2019-09-07 02:53:46', '', 'page-title', '', 'inherit', 'open', 'closed', '', 'page-title', '', '', '2019-09-07 02:53:46', '2019-09-07 02:53:46', '', 0, 'http://localhost/wordpress/wp-content/uploads/2019/09/page-title.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2019-09-07 03:15:02', '2019-09-07 03:15:02', '', 'normal_11-571252810', '', 'inherit', 'open', 'closed', '', 'normal_11-571252810', '', '', '2019-09-07 03:15:02', '2019-09-07 03:15:02', '', 0, 'http://localhost/wordpress/wp-content/uploads/2019/09/normal_11-571252810.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2019-09-07 03:47:12', '2019-09-07 03:47:12', '<label> Tên của bạn (bắt buộc)\r\n    [text* your-name] </label>\r\n\r\n<label> Địa chỉ Email (bắt buộc)\r\n    [email* your-email] </label>\r\n\r\n<label> Tiêu đề:\r\n    [text your-subject] </label>\r\n\r\n<label> Thông điệp\r\n    [textarea your-message] </label>\r\n\r\n\r\n\r\n[submit \"Gửi đi\"]\n1\nHotel.com \"[your-subject]\"\nMoonlight Hotel <wordpress@moonlight.com>\nnguyenvanhoai1280@gmail.com\nGửi đến từ: [your-name] <[your-email]>\r\nTiêu đề: [your-subject]\r\n\r\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website Hotel.com (http://localhost:8080/hotel01)\nReply-To: [your-email]\n\n\n\n\nHotel.com \"[your-subject]\"\nHotel.com <nguyenvanhoai1280@gmail.com>\n[your-email]\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website Hotel.com (http://localhost/wordpress)\nReply-To: nguyenvanhoai1280@gmail.com\n\n\n\nXin cảm ơn, form đã được gửi thành công.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nCó một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nBạn phải chấp nhận điều khoản trước khi gửi form.\nMục này là bắt buộc.\nNhập quá số kí tự cho phép.\nNhập ít hơn số kí tự tối thiểu.\nĐịnh dạng ngày tháng không hợp lệ.\nNgày này trước ngày sớm nhất được cho phép.\nNgày này quá ngày gần nhất được cho phép.\nTải file lên không thành công.\nBạn không được phép tải lên file theo định dạng này.\nFile kích thước quá lớn.\nTải file lên không thành công.\nĐịnh dạng số không hợp lệ.\nCon số nhỏ hơn số nhỏ nhất cho phép.\nCon số lớn hơn số lớn nhất cho phép.\nCâu trả lời chưa đúng.\nBạn đã nhập sai mã CAPTCHA.\nĐịa chỉ e-mail không hợp lệ.\nURL không hợp lệ.\nSố điện thoại không hợp lệ.', 'Form contact', '', 'publish', 'closed', 'closed', '', 'form-contact', '', '', '2020-06-16 17:21:00', '2020-06-16 10:21:00', '', 0, 'http://localhost/wordpress/?post_type=wpcf7_contact_form&#038;p=143', 0, 'wpcf7_contact_form', '', 0),
(154, 1, '2019-09-10 01:12:45', '2019-09-09 18:12:45', '<!-- wp:paragraph -->\n<p> Huế nổi tiếng với công trình kiến trúc cổ kính, một không gian an yên, tĩnh lặng, nhẹ nhàng đến dịu dàng mà có lẽ bạn sẽ khó tìm thấy nét cuốn hút ấy ở nơi khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495.jpg\" alt=\"\"/><figcaption> <em>Cổng Ngọ Môn lung linh huyền ảo khi về đêm</em> </figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nhắc đến Huế, không thể không nhắc đến Đại Nội kinh thành Huế. Một quần thể kiến trúc cung đình vàng son một thời. Là điểm tham quan du lịch nổi tiếng nhất của tỉnh Thừa Thiên Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đặc biệt nhất là du khách có thể khám phá đại nội Huế trong mọi thời điểm trong ngày. Nếu như ban ngày, Hoàng Thành Huế đẹp kỳ vỹ bởi khối kiến trúc cổ đồ sộ, tinh xảo, cổ kính thì khi về đêm, Hoàng Thành Huế lại trở nên lung linh, huyền ảo và đầy kỳ bí.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-2-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-3-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 3\"/><figcaption> <em>Mái nhà, cổng chào và cây cối 2 bên đều phát sáng, khiến đại nội càng trở nên huyền ảo, kỳ bí </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-4-1508496003-width660height880.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 4\"/><figcaption><em> Góc hành lang trong đại nội, bạn sẽ có cảm giác như lạc vào trong một bộ phim cổ trang </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-5-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 5\"/><figcaption><em> Đại Nội ban ngày nguy nga, tráng lệ </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-7-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 6\"/><figcaption><em> Hành lang cổ kính, nhuốm màu thời gian </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-8-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 7\"/><figcaption> <em>Cổng ra đại nội là một công trình kiến trúc đồ sộ, tinh xảo </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Huế còn nổi tiếng với các lăng tẩm của các vị vua triều Nguyễn. Đây cũng là những công trình kiến trúc cổ, có quy mô lớn. Một số đã bị tàn phá, một số vẫn và đang được gìn giữ và tu sửa.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-9-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 8\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-10-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 9\"/><figcaption><em> Lăng Minh Mạng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-11-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 10\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-13-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 11\"/><figcaption><em> Lăng Khải Định </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-14-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 12\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-15-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 13\"/><figcaption><em> Lăng Tự Đức </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một điểm nổi tiếng khác mà khi nhắc đến ai cũng sẽ nghĩ đến Huế đó là Chùa Thiên Mụ. Đây là ngôi chùa được xây dựng sớm nhất ở thành phố Huế và là điểm thu hút khách du lịch mỗi tại Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-16-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 14\"/><figcaption><em> Chùa Thiên Mụ là ngôi chùa xây dựng sớm nhất tại Huế </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế còn có một cây cầu gỗ, với nét kiến trúc độc đáo – là một chiếc cầu vòm bằng gỗ, mái bằng ngói, bắc qua con mương. Đây là chiếc cầu gỗ được xếp vào loại hiếm và có giá trị nghệ thuật cao nhất trong các loại cầu cổ ở Việt Nam.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-17-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 15\"/><figcaption><em> Hình ảnh con thuyền, bụi tre và cây cầu tạo cảm giác thanh bình, yên ả </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-18-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 16\"/><figcaption> <em>Cầu ngói Thanh Toàn được công nhận là di tích văn hóa cấp quốc gia </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Đến Huế, hãy ghé thăm cầu Trường Tiền, ngắm con sông Hương êm đềm, hiền hòa. Gió mát, nhẹ, dịu cũng sẽ cho bạn cảm giác thư thái, nhẹ nhàng đến lạ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-19-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 17\"/><figcaption> <em>Cầu Trường Tiền, bắc ngang qua con sông Hương xanh thơ mộng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế, còn có một công viên bỏ hoang đổ nát nhưng vẫn đầy sức hấp dẫn với du khách, đặc biệt là với khách nước ngoài đến đây khám phá.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-20-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 18\"/><figcaption><em> Công viên bỏ hoang – hồ Thủy Tiên, thu hút được nhiều du khách đến thăm </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Huế còn sở hữu những ngọn đồi thông xanh cao vút rất đẹp.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-21-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 19\"/><figcaption><em> Con đường đất đỏ len lỏi giữa rừng thông xanh trên đồi Vọng Cảnh </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-22-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 20\"/><figcaption><em> Từ đồi Vọng Cảnh, có thể ngắm nhìn dòng sông, và những quả đồi nhấp nhô phía xa </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-23-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 21\"/><figcaption> Một bậc cầu thang tuyệt đẹp trên đồi Thiên An </figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một địa điểm tuyệt đẹp khác ở Huế không thể bỏ qua, đó chính là trường Quốc Học Huế. Ngôi trường không chỉ nổi tiếng với bề dày lịch sử hình thành và phát triển hơn 100 năm, nổi tiếng với các thế hệ học sinh, giáo viên giỏi, mà còn nổi tiếng bởi khối kiến trúc độc đáo pha trộn giữa Đông và Tây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-24-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 22\"/><figcaption> <em>Ngôi trường lâu đời với khối kiến trúc pha trộn giữa Đông và Tây </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-25-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 23\"/><figcaption> <em>Dãy nhà với gam màu đỏ nâu nổi bật </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Đã có khi nào bạn tự hỏi, tại sao Huế trong mỗi giai điệu, mỗi ca từ, mỗi lời thơ lại có thể đằm thắm và dịu dàng đến thế? Tôi đã đi tìm câu trả lời ấy trong một lần đến Huế. Không ồn ào tấp nập, không rực rỡ đèn hoa, không xô bồ, bon chen, Huế mang cho mình một nét rất riêng, rất khác biệt mà khó có thể diễn tả được bằng lời, chỉ có thể tự mình cảm nhận. Qua từng góc phố, qua từng mái lá, hàng cây, qua buổi chiều mát hóng gió trên bờ sông Hương đầy thơ mộng. Tất cả đã tạo nên một nét hấp dẫn mang tên Huế.</p>\n<!-- /wp:paragraph -->', 'Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này', '', 'publish', 'open', 'open', '', 'ai-noi-di-hue-chan-thi-chua-check-in-nhung-dia-danh-dep-quen-sau-nay', '', '', '2019-09-23 15:31:58', '2019-09-23 08:31:58', '', 0, 'http://localhost/wordpress/?p=154', 0, 'post', '', 0),
(155, 1, '2019-09-10 01:12:45', '2019-09-10 01:12:45', '<!-- wp:paragraph -->\n<p>\n\n[mphb_availability_search]\n\n</p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-10 01:12:45', '2019-09-10 01:12:45', '', 154, 'http://localhost/wordpress/2019/09/10/154-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2019-09-10 01:12:52', '2019-09-10 01:12:52', '<!-- wp:paragraph -->\n<p>\n\n[mphb_availability_search]\n\n</p>\n<!-- /wp:paragraph -->', '120$/day', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-09-10 01:12:52', '2019-09-10 01:12:52', '', 6, 'http://localhost/wordpress/2019/09/10/6-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2019-09-10 01:23:06', '2019-09-10 01:23:06', '<!-- wp:paragraph -->\n<p> [mphb_rooms] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-10 01:23:06', '2019-09-10 01:23:06', '', 154, 'http://localhost/wordpress/2019/09/10/154-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2019-09-10 01:24:26', '2019-09-10 01:24:26', '<!-- wp:paragraph -->\n<p> [mphb_availability_search]  </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-10 01:24:26', '2019-09-10 01:24:26', '', 154, 'http://localhost/wordpress/2019/09/10/154-revision-v1/', 0, 'revision', '', 0),
(160, 1, '2019-09-10 03:05:19', '2019-09-10 03:05:19', '', 'Dịch vụ', '', 'publish', 'closed', 'closed', '', 'dich-vu', '', '', '2020-06-28 11:08:49', '2020-06-28 04:08:49', '', 0, 'http://localhost/wordpress/?p=160', 3, 'nav_menu_item', '', 0),
(168, 1, '2019-09-11 01:24:29', '2019-09-11 01:24:29', '<!-- wp:paragraph -->\n<p>  [mphb_room id=\"777\" title=\"true\" featured_image=\"true\"] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 01:24:29', '2019-09-11 01:24:29', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(169, 1, '2019-09-11 01:25:42', '2019-09-11 01:25:42', '<!-- wp:paragraph -->\n<p>  [mphb_room id=\"42\" title=\"true\" featured_image=\"true\"] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 01:25:42', '2019-09-11 01:25:42', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(170, 1, '2019-09-11 01:29:30', '2019-09-11 01:29:30', '<!-- wp:paragraph -->\n<p> [mphb_availability_search]  </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 01:29:30', '2019-09-11 01:29:30', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(173, 1, '2019-09-11 01:49:43', '2019-09-11 01:49:43', '', '89787233', '', 'inherit', 'open', 'closed', '', '89787233', '', '', '2019-09-11 01:49:43', '2019-09-11 01:49:43', '', 0, 'http://localhost/hotel01/wp-content/uploads/2019/09/89787233.jpg', 0, 'attachment', 'image/jpeg', 0),
(183, 1, '2019-09-11 02:11:17', '2019-09-11 02:11:17', '<!-- wp:paragraph -->\n<p>  [mphb_availability] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 02:11:17', '2019-09-11 02:11:17', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2019-09-11 02:12:40', '2019-09-11 02:12:40', '<!-- wp:paragraph -->\n<p> [mphb_availability id=\"42\"] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 02:12:40', '2019-09-11 02:12:40', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(185, 1, '2019-09-11 02:16:21', '2019-09-11 02:16:21', '<!-- wp:paragraph -->\n<p> [mphb_room id=\"172\"] </p>\n<!-- /wp:paragraph -->', '100$/Day', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 02:16:21', '2019-09-11 02:16:21', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(186, 1, '2019-09-11 02:18:13', '2019-09-11 02:18:13', '<!-- wp:paragraph -->\n<p> [mphb_room id=\"172\"] </p>\n<!-- /wp:paragraph -->', 'Phòng gia đình', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 02:18:13', '2019-09-11 02:18:13', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2019-09-11 02:24:00', '2019-09-11 02:24:00', '<!-- wp:paragraph -->\n<p> [mphb_room] </p>\n<!-- /wp:paragraph -->', 'Phòng gia đình', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-11 02:24:00', '2019-09-11 02:24:00', '', 154, 'http://localhost/hotel01/2019/09/11/154-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2019-09-23 15:28:12', '2019-09-23 08:28:12', '', '1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495', '', 'inherit', 'open', 'closed', '', '1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495', '', '', '2019-09-23 15:28:12', '2019-09-23 08:28:12', '', 154, 'http://localhost/hotel01/wp-content/uploads/2019/09/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(212, 1, '2019-09-23 15:28:44', '2019-09-23 08:28:44', '<!-- wp:paragraph -->\n<p> Huế nổi tiếng với công trình kiến trúc cổ kính, một không gian an yên, tĩnh lặng, nhẹ nhàng đến dịu dàng mà có lẽ bạn sẽ khó tìm thấy nét cuốn hút ấy ở nơi khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-1-1508496003-width660height495.jpg\" alt=\"\"/><figcaption> <em>Cổng Ngọ Môn lung linh huyền ảo khi về đêm</em> </figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nhắc đến Huế, không thể không nhắc đến Đại Nội kinh thành Huế. Một quần thể kiến trúc cung đình vàng son một thời. Là điểm tham quan du lịch nổi tiếng nhất của tỉnh Thừa Thiên Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đặc biệt nhất là du khách có thể khám phá đại nội Huế trong mọi thời điểm trong ngày. Nếu như ban ngày, Hoàng Thành Huế đẹp kỳ vỹ bởi khối kiến trúc cổ đồ sộ, tinh xảo, cổ kính thì khi về đêm, Hoàng Thành Huế lại trở nên lung linh, huyền ảo và đầy kỳ bí.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-2-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-3-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 3\"/><figcaption> <em>Mái nhà, cổng chào và cây cối 2 bên đều phát sáng, khiến đại nội càng trở nên huyền ảo, kỳ bí </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-4-1508496003-width660height880.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 4\"/><figcaption><em> Góc hành lang trong đại nội, bạn sẽ có cảm giác như lạc vào trong một bộ phim cổ trang </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820287-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-5-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 5\"/><figcaption><em> Đại Nội ban ngày nguy nga, tráng lệ </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-7-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 6\"/><figcaption><em> Hành lang cổ kính, nhuốm màu thời gian </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-8-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 7\"/><figcaption> <em>Cổng ra đại nội là một công trình kiến trúc đồ sộ, tinh xảo </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Huế còn nổi tiếng với các lăng tẩm của các vị vua triều Nguyễn. Đây cũng là những công trình kiến trúc cổ, có quy mô lớn. Một số đã bị tàn phá, một số vẫn và đang được gìn giữ và tu sửa.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-9-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 8\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-10-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 9\"/><figcaption><em> Lăng Minh Mạng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-11-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 10\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-13-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 11\"/><figcaption><em> Lăng Khải Định </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820288-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-14-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 12\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-15-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 13\"/><figcaption><em> Lăng Tự Đức </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một điểm nổi tiếng khác mà khi nhắc đến ai cũng sẽ nghĩ đến Huế đó là Chùa Thiên Mụ. Đây là ngôi chùa được xây dựng sớm nhất ở thành phố Huế và là điểm thu hút khách du lịch mỗi tại Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-16-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 14\"/><figcaption><em> Chùa Thiên Mụ là ngôi chùa xây dựng sớm nhất tại Huế </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế còn có một cây cầu gỗ, với nét kiến trúc độc đáo – là một chiếc cầu vòm bằng gỗ, mái bằng ngói, bắc qua con mương. Đây là chiếc cầu gỗ được xếp vào loại hiếm và có giá trị nghệ thuật cao nhất trong các loại cầu cổ ở Việt Nam.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-17-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 15\"/><figcaption><em> Hình ảnh con thuyền, bụi tre và cây cầu tạo cảm giác thanh bình, yên ả </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-18-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 16\"/><figcaption> <em>Cầu ngói Thanh Toàn được công nhận là di tích văn hóa cấp quốc gia </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Đến Huế, hãy ghé thăm cầu Trường Tiền, ngắm con sông Hương êm đềm, hiền hòa. Gió mát, nhẹ, dịu cũng sẽ cho bạn cảm giác thư thái, nhẹ nhàng đến lạ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-19-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 17\"/><figcaption> <em>Cầu Trường Tiền, bắc ngang qua con sông Hương xanh thơ mộng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế, còn có một công viên bỏ hoang đổ nát nhưng vẫn đầy sức hấp dẫn với du khách, đặc biệt là với khách nước ngoài đến đây khám phá.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-20-1508496003-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 18\"/><figcaption><em> Công viên bỏ hoang – hồ Thủy Tiên, thu hút được nhiều du khách đến thăm </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Huế còn sở hữu những ngọn đồi thông xanh cao vút rất đẹp.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820289-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-21-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 19\"/><figcaption><em> Con đường đất đỏ len lỏi giữa rừng thông xanh trên đồi Vọng Cảnh </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-22-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 20\"/><figcaption><em> Từ đồi Vọng Cảnh, có thể ngắm nhìn dòng sông, và những quả đồi nhấp nhô phía xa </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-23-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 21\"/><figcaption> Một bậc cầu thang tuyệt đẹp trên đồi Thiên An </figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một địa điểm tuyệt đẹp khác ở Huế không thể bỏ qua, đó chính là trường Quốc Học Huế. Ngôi trường không chỉ nổi tiếng với bề dày lịch sử hình thành và phát triển hơn 100 năm, nổi tiếng với các thế hệ học sinh, giáo viên giỏi, mà còn nổi tiếng bởi khối kiến trúc độc đáo pha trộn giữa Đông và Tây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-24-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 22\"/><figcaption> <em>Ngôi trường lâu đời với khối kiến trúc pha trộn giữa Đông và Tây </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/4-2017/images/2017-10-24/1508820290-ghe-tham-kinh-do-nha-nguyen-de-tan-huong-tron-ven-su-an-yen-cua-cuoc-song-25-1508497039-width660height495.jpg\" alt=\"Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này - 23\"/><figcaption> <em>Dãy nhà với gam màu đỏ nâu nổi bật </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Đã có khi nào bạn tự hỏi, tại sao Huế trong mỗi giai điệu, mỗi ca từ, mỗi lời thơ lại có thể đằm thắm và dịu dàng đến thế? Tôi đã đi tìm câu trả lời ấy trong một lần đến Huế. Không ồn ào tấp nập, không rực rỡ đèn hoa, không xô bồ, bon chen, Huế mang cho mình một nét rất riêng, rất khác biệt mà khó có thể diễn tả được bằng lời, chỉ có thể tự mình cảm nhận. Qua từng góc phố, qua từng mái lá, hàng cây, qua buổi chiều mát hóng gió trên bờ sông Hương đầy thơ mộng. Tất cả đã tạo nên một nét hấp dẫn mang tên Huế.</p>\n<!-- /wp:paragraph -->', 'Ai nói đi Huế chán thì chưa check-in những địa danh đẹp quên sầu này', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2019-09-23 15:28:44', '2019-09-23 08:28:44', '', 154, 'http://localhost/hotel01/2019/09/23/154-revision-v1/', 0, 'revision', '', 0),
(214, 1, '2019-09-23 15:41:48', '2019-09-23 08:41:48', '', 'Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427', '', 'inherit', 'open', 'closed', '', 've-hue-dip-tet-trai-nghiem-cuoc-song-chon-hoang-cung-2-1518507137-960-width640height427', '', '', '2019-09-23 15:41:48', '2019-09-23 08:41:48', '', 6, 'http://localhost/hotel01/wp-content/uploads/2019/09/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427.jpg', 0, 'attachment', 'image/jpeg', 0),
(215, 1, '2019-09-23 15:41:59', '2019-09-23 08:41:59', '<!-- wp:paragraph -->\n<p>Trong dịp Tết, nhiều hoạt động sôi động diễn ra tại Hoàng cung Huế. Du khách có thể tìm hiểu về hoạt động đổi gác tại Ngọ Môn và tham gia các trò chơi dân gian, tận hưởng những bữa ăn cung đình Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trung tâm Bảo tồn Di tích Cố đô Huế vừa công bố nhiều chương trình hấp dẫn trong dịp Tết Nguyên đán mừng năm mới Mậu Tuất 2018 tại Hoàng Cung Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Theo đó, nghi lễ đầu tiên là Thướng Tiêu hay còn gọi là Dựng nêu. Đây là một nghi thức truyền thống của dân tộc và cũng là một nghi lễ quan trọng vào đầu năm mới của triều Nguyễn. Ngoài những quan niệm tâm linh của dân gian, lễ dựng nêu của triều Nguyễn còn có mục đich để báo hiệu ngày Tết đã tới.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-1-1518507137-90-width490height327.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 1\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Cô đô Huế hiện nay, lễ Dựng nêu tổ chức vào ngày 23 tháng Chạp tại Thế Miếu (từ 9h sáng) và điện Long An (từ 10h sáng) do Trung tâm Bảo tồn Di tích Cố đô Huế tái hiện lần đầu tiên từ năm 2013 và đã trở thành một truyền thống không thể thiếu ở khu di sản Huế khi bắt đầu một cái Tết cổ truyền.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đặc biệt, năm nay, sau nghi thức dựng nêu tại điện Long An, từ 10h30, tại khu vực nhà Tế Tửu, Trung tâm Bảo tồn Di tích Cố đô Huế còn tổ chức chương trình “Hương xưa bánh Tết”, có ý nghĩa là một khởi động đầu năm với những trải nghiệm về hương sắc Tết cũ qua những sắc màu truyền thống.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Chương trình “Hương xưa bánh Tết” bao gồm các âm điệu ca Huế; các trò chơi cung đình và dân gian (đổ xăm hường và bài vụ); trình diễn thư pháp tặng chữ, đặc biệt là hội thi gói bánh chưng, bánh tét... có sức gợi về cái Tết cổ truyền của dân tộc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-2-1518507137-960-width640height427.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Được biết trong cổ sử Việt Nam, tương truyền, vua Hùng Vương thứ sáu muốn tìm người tài kế vị, đã cho vời các hoàng tử lại và truyền rằng sẽ truyền ngôi cho người nào cung tiến được món sản vật thể hiện lòng hiếu đạo để tiến cúng tiên vương. Hoàng tử Lang Liêu đã dâng hai loại bánh chưng, bánh dày với biểu tượng trời tròn đất vuông được chế biến từ gạo nếp. Kể từ đó, bánh chưng đi vào lịch sử dân tộc, trở thành một nét văn hóa đặc sắc. Mỗi khi Tết đến xuân về, trên mâm cỗ cúng tổ tiên của người Việt Nam không thể thiếu bánh chưng, bánh tét.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trong không gian tràn ngập sắc xuân với các loại trang phục truyền thống, những đôi câu đối thắm, những sắc hoa xuân, du khách sẽ có cơ hội trải nghiệm qua những hình bóng của nếp xưa xứ Huế, nhất là không khí gói bánh chưng, bánh tét cũng những niêu bánh chưng nghi ngút, đượm nồng phong vị Tết.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trong Tết, nhiều hoạt động diễn ra tại Hoàng cung Huế. Nhân Tết Nguyên đán Mậu Tuất theo quy định, từ ngày mồng 1 đến mồng 3 Tết (16/2 – 18/2), khu di sản Huế sẽ mở cửa miễn phí đối với người Việt Nam. Trong dịp này, Trung tâm Bảo tồn Di tích Cố đô Huế sẽ tổ chức nhiều hoạt động vui Tết tại Hoàng cung (Đại Nội) để phục vụ nhân dân với nhiều hoạt động phong phú. Cụ thể như :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ngày mùng 1 Tết: Buổi sáng sẽ có lễ Đổi gác tại Ngọ Môn (lúc 9h); Múa Lân sư rồng tại sân trước điện Thái Hòa (lúc 9h30); Các trò chơi cung đình, trình diễn thư pháp tại Sân sau điện Thái Hòa (lúc 10h); Trình tấu Đại nhạc tại Thế Miếu (lúc 10h30). Buổi chiều sẽ có chương trình nghệ thuật \"Âm sắc cung đình\" tại Sân Điện Thái Hòa (từ 15h30 đến 16h15).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn.24h.com.vn/upload/1-2018/images/2018-02-13/Ve-Hue-dip-Tet-trai-nghiem-cuoc-song-chon-Hoang-cung-3-1518507137-862-width800height536.jpg\" alt=\"Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung - 3\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ngày Mùng 2 Tết: Buổi sáng có lễ Đổi gác tại Ngọ Môn (lúc 9h); Chương trình nghệ thuật \"Âm sắc cung đình\"tại Sân Điện Thái Hòa (từ 9h30 đến 10h15). Buổi chiều sẽ có trình diễn Võ thuật cổ truyền tại Sân Điện Thái Hòa (lúc 14h30); Múa Lân sư rồng tại Sân điện Cần Chánh (lúc 15h).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Mùng 3 Tết vào buổi sáng có lễ Đổi gác tại Ngọ Môn (lúc 9h); Trình tấu tiểu nhạc tại sân trước điện Thái Hòa (lúc 9h30); Múa lân sư rồng tại Sân điện Cần Chánh (lúc 10h); Trình tấu Đại nhạc tại Thế Miếu (lúc 10h30). Buổi chiều sẽ diễn ra trình diễn Võ thuật cổ truyền tại Sân trước điện Thái Hòa (lúc 14h và 15h30; Trình tấu tiểu nhạc tại sân trước điện Thái Hòa (lúc 14h30); Trình tấu Đại nhạc tại Thế Miếu (lúc 16h).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ngày 22.2 nhằm mùng 7 Tết sẽ có Lễ Hạ Nêu tại Thế Miếu (lúc 9h) và tại điện Long An (lúc 10h).</p>\n<!-- /wp:paragraph -->', 'Về Huế dịp Tết, trải nghiệm cuộc sống chốn Hoàng cung', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-09-23 15:41:59', '2019-09-23 08:41:59', '', 6, 'http://localhost/hotel01/2019/09/23/6-revision-v1/', 0, 'revision', '', 0),
(216, 1, '2019-09-23 15:42:32', '2019-09-23 08:42:32', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-09-23 15:42:32', '2019-09-23 08:42:32', '', 1, 'http://localhost/hotel01/2019/09/23/1-revision-v1/', 0, 'revision', '', 0),
(218, 1, '2019-09-23 15:51:11', '2019-09-23 08:51:11', '', '1499934736-1-1499820344338', '', 'inherit', 'open', 'closed', '', '1499934736-1-1499820344338', '', '', '2019-09-23 15:51:11', '2019-09-23 08:51:11', '', 1, 'http://localhost/hotel01/wp-content/uploads/2019/09/1499934736-1-1499820344338.jpg', 0, 'attachment', 'image/jpeg', 0),
(219, 1, '2019-09-23 15:51:32', '2019-09-23 08:51:32', '<!-- wp:paragraph -->\n<p>Lượn xe máy trên đèo Hải Vân không cảm thấy căng thẳng mà chỉ như đang bay lên cùng gió, cùng mây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khi bắt đầu dấn thân vào con đường ăn chơi bụi bặm bằng xe máy cũng là lúc tôi mê những con đèo. Cảm giác uốn lượn, quanh co lúc lên cao vút, lúc xuống vùn vụt khiến tôi phấn khích kỳ lạ. Bởi vậy mà suốt một thời gian dài tôi miệt mài \"cày\" những con đèo xứ Bắc với suy nghĩ: \"Đã đi đèo càng hiểm trở cảm giác càng mạnh, càng hay\".</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-4-1499820351587.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 1\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-1-1499820344338.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 2\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-2-1499820346861.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 3\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-3-1499820349180.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 4\"/><figcaption><em> Hải Vân mùa lau trắng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Rồi một lần đến Đà Nẵng,&nbsp;chạy xe máy&nbsp;ra Huế tôi nhận ra lâu nay mình đã thiếu sót khi trong bản đồ chinh phục những cung đường thiếu vắng đệ nhất hùng quan nước Nam:&nbsp;Đèo Hải Vân.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>So với những con đèo phía Bắc, đèo Hải Vân quá hiền. Một bên núi non mướt mát, một bên biển rộng mênh mông. Đường rộng, uốn lượn nhẹ nhàng với vài cái cua cùi chỏ không quá gắt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-5-1499820353589.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 5\"/><figcaption><em> Đi trên đèo Hải Vân rất dễ dàng bắt gặp những bãi biển trắng muốt làm đường viền cho biển </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Lần đầu tiên đi một con đèo mà không phải căng 4 giác quan lên để&nbsp;điều khiển xe&nbsp;tôi thấy hơi là lạ. Thư thả nên tôi chạy chậm, ngắm nghía cảnh quan và nhận ra lượn trên một con đèo hiền cảm giác thật bình yên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-7-1499820357593.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 6\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-6-1499820355570.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 7\"/><figcaption><em> Và thấy cả tuyến đường sắt đẹp uốn lượn giữa núi đồi xanh mát </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù không hiểm trở bằng những con đèo phía Bắc nhưng đèo Hải Vân đủ cao để đưa người ta lên tận cùng cảm xúc phiêu bồng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Cũng có núi cao vòi vọi, cũng có vực thẳm sâu hút nhưng núi non lúc nào cũng đầy hoa cỏ rập rờn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-8-1499820359584.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 8\"/><figcaption><em> Một khúc cua dịu dàng trên đèo Hải Vân </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Hôm tôi đi nhằm lúc hoa cỏ lau nở trắng. Lượn đèo trong tiếng gió vi vu, giữa những ngọn cỏ lau phất phới tôi có cảm giác mình như đang bay lên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Trên đỉnh đèo Hải Vân là di tích Hải Vân Quan. Được xây dựng từ thời nhà Nguyễn, Hải Vân Quan giờ đây chỉ là những phế tích hoang tàn. Nhưng đứng bên dưới những phiến đá đồ sộ, nhìn bao quát cảnh quan mới hiểu hết câu ca dao:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>\"Đi bộ thì khiếp Hải Vân</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>Đi thuyền thì khiếp sóng thần Hang Dơi\"</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-9-1499820361662.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 9\"/><figcaption> <em>Từ Hải Vân Quan, bạn men theo con đường nhỏ là đến một nơi khoáng đạt, tuyệt vời như thế này </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Men theo con đường nhỏ bên hông di tích này, đi khoảng độ 1,5 km nữa sẽ có thể ngắm toàn cảnh con đèo cũng như&nbsp;vịnh Lăng Cô&nbsp;(tỉnh Thừa Thiên Huế).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Đây thực sự là một nơi tuyệt vời để hít thở, nhìn ngắm và thư giãn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-12-1499820372303.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 10\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-10-1499820365426.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 11\"/><figcaption><em> Đến Hải Vân, bạn sẽ cảm thấy như mình đang bay lên cùng bềnh bồng mây trắng </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù ở Đà Nẵng nhiệt độ lên đến 35 nhưng ở đây chỉ khoảng 22. Gió mát lồng lộng đưa những vạt mây thi thoảng sà xuống mát lạnh rồi bay đi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ớ phía Bắc, vịnh Lăng Cô hiện ra xanh ngắt với đường viền cát trắng đến nao lòng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Tôi thích núi hơn là thích biển bởi đứng giữa núi đồi bỗng thấy mình mạnh mẽ. Còn đứng trước biển dễ khiến người ta cô đơn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-11-1499820369100.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 12\"/><figcaption><em> Một chú bò thơ thẩn cùng mây </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tuy nhiên, khi đứng nhìn biển từ đệ nhất hùng quan nước Nam ngày hôm đó, tôi bỗng nhận ra núi không làm mình mạnh mẽ, biển cũng không làm mình cô đơn, cảm xúc duy nhất là sự bình yên, thanh sạch chưa từng trải qua.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khi tâm sự cảm xúc này với một người bạn Đà Nẵng, bạn nói: \"Hải Vân không chỉ là một con đèo, nó như một vật thể sống, chuyển mình từng phút, từng giây. Nên dù có đi bao nhiêu lần cũng không bao giờ thấy nhàm chán bởi mỗi lần là một cảm xúc khác nhau. Nếu có dịp hãy quay lại\".</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"https://anh.24h.com.vn/upload/3-2017/images/2017-07-13/1499934736-13-1499820375592.jpg\" alt=\"Phiêu bồng trên Hải Vân Quan - 13\"/><figcaption><em> Biển Lăng Cô nhìn Hải Vân </em></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nhất định, nếu có dịp tôi sẽ quay lại Hải Vân. Ngày đó không xa đâu!</p>\n<!-- /wp:paragraph -->', 'Phiêu bồng trên Hải Vân Quan', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-09-23 15:51:32', '2019-09-23 08:51:32', '', 1, 'http://localhost/hotel01/2019/09/23/1-revision-v1/', 0, 'revision', '', 0),
(220, 1, '2019-09-23 16:57:14', '2019-09-23 09:57:14', '', 'Quanh năm', '', 'publish', 'closed', 'closed', '', 'quanh-nam', '', '', '2019-09-23 16:57:14', '2019-09-23 09:57:14', '', 0, 'http://localhost/hotel01/?post_type=mphb_season&#038;p=220', 0, 'mphb_season', '', 0),
(224, 1, '2019-09-24 14:29:40', '2019-09-24 07:29:40', '[mphb_checkout]', 'Xác nhận đặt phòng', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2019-09-24 14:29:40', '2019-09-24 07:29:40', '', 24, 'http://localhost/hotel01/2019/09/24/24-revision-v1/', 0, 'revision', '', 0),
(225, 1, '2019-09-24 14:31:58', '2019-09-24 07:31:58', '[mphb_rooms]', 'Phòng', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2019-09-24 14:31:58', '2019-09-24 07:31:58', '', 21, 'http://localhost/hotel01/2019/09/24/21-revision-v1/', 0, 'revision', '', 0),
(226, 1, '2019-09-24 14:32:20', '2019-09-24 07:32:20', '[mphb_rooms]', 'Loại phòng', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2019-09-24 14:32:20', '2019-09-24 07:32:20', '', 21, 'http://localhost/hotel01/2019/09/24/21-revision-v1/', 0, 'revision', '', 0),
(227, 1, '2019-09-24 14:33:28', '2019-09-24 07:33:28', '[mphb_search_results]', 'Kết quả tìm kiếm', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-09-24 14:33:28', '2019-09-24 07:33:28', '', 23, 'http://localhost/hotel01/2019/09/24/23-revision-v1/', 0, 'revision', '', 0),
(228, 1, '2019-09-24 14:33:54', '2019-09-24 07:33:54', '[mphb_availability_search]', 'Tìm kiếm sẵn có', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2019-09-24 14:33:54', '2019-09-24 07:33:54', '', 22, 'http://localhost/hotel01/2019/09/24/22-revision-v1/', 0, 'revision', '', 0),
(229, 1, '2019-09-24 14:34:34', '2019-09-24 07:34:34', 'Thank you for your payment. Your transaction has been completed and a receipt for your purchase has been emailed to you.', 'Thanh toán thành công', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2019-09-24 14:34:34', '2019-09-24 07:34:34', '', 27, 'http://localhost/hotel01/2019/09/24/27-revision-v1/', 0, 'revision', '', 0),
(230, 1, '2019-09-24 14:34:58', '2019-09-24 07:34:58', 'We are pleased to inform you that your reservation request has been received and confirmed.', 'Xác nhận đặt phòng', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2019-09-24 14:34:58', '2019-09-24 07:34:58', '', 25, 'http://localhost/hotel01/2019/09/24/25-revision-v1/', 0, 'revision', '', 0),
(231, 1, '2019-09-24 14:35:24', '2019-09-24 07:35:24', 'Unfortunately, your transaction cannot be completed at this time. Please try again or contact us.', 'Giao dịch thất bại', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2019-09-24 14:35:24', '2019-09-24 07:35:24', '', 28, 'http://localhost/hotel01/2019/09/24/28-revision-v1/', 0, 'revision', '', 0),
(232, 1, '2019-09-24 14:35:50', '2019-09-24 07:35:50', 'Your reservation is canceled.', 'Hủy đặt phòng', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2019-09-24 14:35:50', '2019-09-24 07:35:50', '', 26, 'http://localhost/hotel01/2019/09/24/26-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2019-09-25 15:05:05', '2019-09-25 08:05:05', '<!-- wp:paragraph -->\n<p>Trung tâm thể hình của khách sạn có đầy đủ các trang thiết bị tập luyện hiện đại giúp người tập thỏa mãn các mục tiêu rèn luyện cơ thể dẻo dai, săn chắc. Hãy hăng say tập luyện – toát mồ hôi và tiếp tục tập luyện để có một sức khỏe tốt cho bản thân.<br></p>\n<!-- /wp:paragraph -->', 'Giới thiệu', '', 'publish', 'closed', 'closed', '', 'gioi-thieu', '', '', '2020-06-28 09:55:41', '2020-06-28 02:55:41', '', 0, 'http://localhost/hotel01/?page_id=241', 0, 'page', '', 0),
(242, 1, '2019-09-25 15:05:05', '2019-09-25 08:05:05', '', 'Giới thiệu', '', 'inherit', 'closed', 'closed', '', '241-revision-v1', '', '', '2019-09-25 15:05:05', '2019-09-25 08:05:05', '', 241, 'http://localhost/hotel01/2019/09/25/241-revision-v1/', 0, 'revision', '', 0),
(249, 1, '2020-06-26 17:25:02', '2020-06-26 10:25:02', 'nguyenvanhoai1280@gmail.com\nadmin', 'nguyenvanhoai1280@gmail.com', '', 'publish', 'closed', 'closed', '', 'nguyenvanhoai1280-gmail-com', '', '', '2020-06-26 17:25:02', '2020-06-26 10:25:02', '', 0, 'http://localhost/hotel01/2019/10/02/nguyenvanhoai1280-gmail-com/', 0, 'flamingo_contact', '', 0),
(250, 1, '2019-10-02 09:00:17', '2019-10-02 02:00:17', 'wapuu@wordpress.example\nA WordPress Commenter', 'wapuu@wordpress.example', '', 'publish', 'closed', 'closed', '', 'wapuu-wordpress-example', '', '', '2019-10-02 09:00:17', '2019-10-02 02:00:17', '', 0, 'http://localhost/hotel01/2019/10/02/wapuu-wordpress-example/', 0, 'flamingo_contact', '', 0),
(263, 1, '2019-10-02 15:19:49', '2019-10-02 08:19:49', '', 'luxury', '', 'inherit', 'open', 'closed', '', 'luxury', '', '', '2019-10-02 15:19:49', '2019-10-02 08:19:49', '', 0, 'http://localhost/hotel01/wp-content/uploads/2019/10/luxury.jpg', 0, 'attachment', 'image/jpeg', 0),
(268, 1, '2019-10-04 09:08:28', '2019-10-04 02:08:28', 'Your reservation is canceled.', 'Hủy đặt phòng', '', 'inherit', 'closed', 'closed', '', '26-autosave-v1', '', '', '2019-10-04 09:08:28', '2019-10-04 02:08:28', '', 26, 'http://localhost/hotel01/26-autosave-v1/', 0, 'revision', '', 0),
(269, 1, '2019-10-04 09:44:46', '2019-10-04 02:44:46', '', '', '', 'trash', 'closed', 'closed', '', '269__trashed', '', '', '2020-06-16 14:47:00', '2020-06-16 07:47:00', '', 0, 'http://localhost/hotel01/?post_type=mphb_booking&#038;p=269', 0, 'mphb_booking', '', 10),
(270, 1, '2019-10-04 09:42:42', '2019-10-04 02:42:42', '', '', '', 'publish', 'closed', 'closed', '', '270', '', '', '2019-10-04 09:42:42', '2019-10-04 02:42:42', '', 269, 'http://localhost/hotel01/mphb_reserved_room/270/', 0, 'mphb_reserved_room', '', 0),
(273, 1, '2019-10-07 16:30:03', '2019-10-07 09:30:03', '', 'Liên hệ', '', 'publish', 'closed', 'closed', '', 'lien-he', '', '', '2020-06-18 16:45:20', '2020-06-18 09:45:20', '', 0, 'http://localhost/hotel01/?page_id=273', 0, 'page', '', 0),
(274, 1, '2019-10-07 16:30:03', '2019-10-07 09:30:03', '', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2019-10-07 16:30:03', '2019-10-07 09:30:03', '', 273, 'http://localhost/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(278, 1, '2019-10-07 16:56:44', '2019-10-07 09:56:44', ' ', '', '', 'publish', 'closed', 'closed', '', '278', '', '', '2020-06-28 11:08:49', '2020-06-28 04:08:49', '', 0, 'http://localhost/hotel01/?p=278', 5, 'nav_menu_item', '', 0),
(280, 1, '2019-10-09 14:35:10', '2019-10-09 07:35:10', '', 'an-uong', '', 'inherit', 'open', 'closed', '', 'an-uong-2', '', '', '2019-10-09 14:35:10', '2019-10-09 07:35:10', '', 0, 'http://localhost/hotel01/wp-content/uploads/2019/09/an-uong.jpg', 0, 'attachment', 'image/jpeg', 0),
(281, 1, '2019-10-09 14:35:51', '2019-10-09 07:35:51', '', 'massage', '', 'inherit', 'open', 'closed', '', 'massage-2', '', '', '2019-10-09 14:35:51', '2019-10-09 07:35:51', '', 0, 'http://localhost/hotel01/wp-content/uploads/2019/09/massage.jpg', 0, 'attachment', 'image/jpeg', 0),
(282, 1, '2019-10-09 14:36:49', '2019-10-09 07:36:49', '', 'xe-may', '', 'inherit', 'open', 'closed', '', 'xe-may', '', '', '2019-10-09 14:36:49', '2019-10-09 07:36:49', '', 0, 'http://localhost/hotel01/wp-content/uploads/2019/09/xe-may.jpg', 0, 'attachment', 'image/jpeg', 0),
(285, 1, '2019-10-09 16:04:49', '2019-10-09 09:04:49', ' ', '', '', 'publish', 'closed', 'closed', '', '285', '', '', '2020-06-28 11:08:49', '2020-06-28 04:08:49', '', 0, 'http://localhost/hotel01/?p=285', 4, 'nav_menu_item', '', 0),
(287, 1, '2019-10-09 17:11:27', '2019-10-09 10:11:27', '', 'Phòng', '', 'publish', 'closed', 'closed', '', 'phong-2', '', '', '2020-06-28 11:08:48', '2020-06-28 04:08:48', '', 0, 'http://localhost/hotel01/?p=287', 2, 'nav_menu_item', '', 0),
(291, 1, '2019-10-18 11:11:06', '2019-10-18 04:11:06', '<!-- wp:paragraph -->\n<p><strong><em>Cách trung tâm thành phố&nbsp;<a href=\"https://www.ivivu.com/blog/category/viet-nam/hue-viet-nam/\" target=\"_blank\" rel=\"noreferrer noopener\">Huế</a>&nbsp;khoảng 40 km,&nbsp;Bạch Mã Village là một khu dã ngoại giữa được xây dựng trên ý tưởng giống hệt nơi sinh sống của người lùn Hobbit trong bộ phim “Chúa tể của những chiếc nhẫn”.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Hướng dẫn đường đi&nbsp;<strong>Bạch Mã Village</strong>&nbsp;Huế: Từ trung tâm thành phố Huế theo hướng quốc lộ 1A đi Đà Nẵng. Đến thị trấn Phú Lộc, đi tiếp theo bảng chỉ dẫn vào Vườn Quốc gia Bạch Mã, rẽ phải vào đường Trần Đình Túc sau đó rẽ trái vào đường Lê Thúc Khánh. Đi thêm một đoạn, du khách sẽ nhìn thấy biển chỉ dẫn vào khu du lịch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305407,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/huong-dan-duong-di-bach-ma-village-hue-ivivu.jpg\" alt=\"huong-dan-duong-di-bach-ma-village-hue-ivivu\" class=\"wp-image-305407\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305379,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-11.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-11\" class=\"wp-image-305379\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305372,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-4.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-4\" class=\"wp-image-305372\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305396} -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-13.jpg\" alt=\"Ảnh: _tgvy_\" class=\"wp-image-305396\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù mới chính thức đi vào hoạt động chưa bao lâu nhưng&nbsp;<strong><em>Bạch Mã Village</em></strong>&nbsp;đã thu hút đông đảo người dân địa phương và cả du khách đến tham quan, khám phá. Nhờ cách bố trí không gian độc đáo, xen kẽ giữa các khu cắm trại, khu vực nhà hàng, khu tắm thác, đến&nbsp;Bạch Mã Village du khách sẽ cảm nhận được bầu thật không khí trong lành giữa núi rừng Bạch Mã.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305370,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-2.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-2\" class=\"wp-image-305370\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305375,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-7.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-7\" class=\"wp-image-305375\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305376,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-8.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-8\" class=\"wp-image-305376\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Bạch Mã Village</em>&nbsp;là khu cắm trại về đêm chuyên nghiệp mang chủ đề The Hobbit với các địa điểm check-in không khác gì trong phim. Với hệ thống chiếu sáng về đêm được đầu tư bài bản, các hồ tắm suối sẽ lung linh ở cả trên bờ lẫn dưới nước sẽ mang đến cho bạn những trải nghiệm độc đáo.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305373,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-5.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-5\" class=\"wp-image-305373\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bên cạnh những ngôi nhà Hobbit, du khách có thể ghé thăm khu vườn xanh um với nhiều loài hoa, thác và hồ nước trong xanh để chụp ảnh lưu niệm.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305398,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-14.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-14\" class=\"wp-image-305398\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305369,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-1.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-1\" class=\"wp-image-305369\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><strong><em>Giá vé dành cho khách tham quan:</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao 130cm trở lên: giá 100.000đ/vé</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao 90cm – 130cm: giá 60.000đ/vé</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao dưới 90cm: miễn phí</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305380,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-12.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-12\" class=\"wp-image-305380\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Địa chỉ: Bạch Mã Village – Thác Trượt Bạch Mã, thác Trượt Thủy Điện Phú Lộc, Bạch Mã, Huế</em></p>\n<!-- /wp:paragraph -->', 'Hướng dẫn đường đi Bạch Mã Village Huế', '', 'publish', 'open', 'open', '', 'huong-dan-duong-di-bach-ma-village-hue', '', '', '2019-10-30 14:56:38', '2019-10-30 07:56:38', '', 0, 'http://localhost/hotel01/?p=291', 0, 'post', '', 0),
(292, 1, '2019-10-18 11:10:46', '2019-10-18 04:10:46', '', 'Bach-Ma-Village-Hue-ivivu-13', '', 'inherit', 'open', 'closed', '', 'bach-ma-village-hue-ivivu-13', '', '', '2019-10-18 11:10:46', '2019-10-18 04:10:46', '', 291, 'http://localhost/hotel01/wp-content/uploads/2019/10/Bach-Ma-Village-Hue-ivivu-13.jpg', 0, 'attachment', 'image/jpeg', 0),
(293, 1, '2019-10-18 11:11:06', '2019-10-18 04:11:06', '<!-- wp:paragraph -->\n<p><strong><em>Cách trung tâm thành phố&nbsp;<a href=\"https://www.ivivu.com/blog/category/viet-nam/hue-viet-nam/\" target=\"_blank\" rel=\"noreferrer noopener\">Huế</a>&nbsp;khoảng 40 km,&nbsp;Bạch Mã Village là một khu dã ngoại giữa được xây dựng trên ý tưởng giống hệt nơi sinh sống của người lùn Hobbit trong bộ phim “Chúa tể của những chiếc nhẫn”.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Hướng dẫn đường đi&nbsp;<strong>Bạch Mã Village</strong>&nbsp;Huế: Từ trung tâm thành phố Huế theo hướng quốc lộ 1A đi Đà Nẵng. Đến thị trấn Phú Lộc, đi tiếp theo bảng chỉ dẫn vào Vườn Quốc gia Bạch Mã, rẽ phải vào đường Trần Đình Túc sau đó rẽ trái vào đường Lê Thúc Khánh. Đi thêm một đoạn, du khách sẽ nhìn thấy biển chỉ dẫn vào khu du lịch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305407,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/huong-dan-duong-di-bach-ma-village-hue-ivivu.jpg\" alt=\"huong-dan-duong-di-bach-ma-village-hue-ivivu\" class=\"wp-image-305407\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305379,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-11.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-11\" class=\"wp-image-305379\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305372,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-4.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-4\" class=\"wp-image-305372\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305396} -->\n<figure class=\"wp-block-image\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-13.jpg\" alt=\"Ảnh: _tgvy_\" class=\"wp-image-305396\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Dù mới chính thức đi vào hoạt động chưa bao lâu nhưng&nbsp;<strong><em>Bạch Mã Village</em></strong>&nbsp;đã thu hút đông đảo người dân địa phương và cả du khách đến tham quan, khám phá. Nhờ cách bố trí không gian độc đáo, xen kẽ giữa các khu cắm trại, khu vực nhà hàng, khu tắm thác, đến&nbsp;Bạch Mã Village du khách sẽ cảm nhận được bầu thật không khí trong lành giữa núi rừng Bạch Mã.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305370,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-2.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-2\" class=\"wp-image-305370\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305375,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-7.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-7\" class=\"wp-image-305375\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305376,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-8.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-8\" class=\"wp-image-305376\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Bạch Mã Village</em>&nbsp;là khu cắm trại về đêm chuyên nghiệp mang chủ đề The Hobbit với các địa điểm check-in không khác gì trong phim. Với hệ thống chiếu sáng về đêm được đầu tư bài bản, các hồ tắm suối sẽ lung linh ở cả trên bờ lẫn dưới nước sẽ mang đến cho bạn những trải nghiệm độc đáo.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305373,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-5.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-5\" class=\"wp-image-305373\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bên cạnh những ngôi nhà Hobbit, du khách có thể ghé thăm khu vườn xanh um với nhiều loài hoa, thác và hồ nước trong xanh để chụp ảnh lưu niệm.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305398,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-14.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-14\" class=\"wp-image-305398\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":305369,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-1.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-1\" class=\"wp-image-305369\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><strong><em>Giá vé dành cho khách tham quan:</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao 130cm trở lên: giá 100.000đ/vé</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao 90cm – 130cm: giá 60.000đ/vé</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Khách hàng cao dưới 90cm: miễn phí</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":305380,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://cdn3.ivivu.com/2019/08/Bach-Ma-Village-Hue-ivivu-12.jpg\" alt=\"Bach-Ma-Village-Hue-ivivu-12\" class=\"wp-image-305380\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Địa chỉ: Bạch Mã Village – Thác Trượt Bạch Mã, thác Trượt Thủy Điện Phú Lộc, Bạch Mã, Huế</em></p>\n<!-- /wp:paragraph -->', 'Hướng dẫn đường đi Bạch Mã Village Huế', '', 'inherit', 'closed', 'closed', '', '291-revision-v1', '', '', '2019-10-18 11:11:06', '2019-10-18 04:11:06', '', 291, 'http://localhost/hotel01/291-revision-v1/', 0, 'revision', '', 0),
(297, 1, '2020-06-15 10:08:36', '2020-06-15 03:08:36', '[mphb_booking_confirmation]', 'Xác nhận đặt phòng', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2020-06-15 10:08:36', '2020-06-15 03:08:36', '', 25, 'http://localhost:8080/hotel01/25-revision-v1/', 0, 'revision', '', 0),
(298, 1, '2020-06-15 10:08:36', '2020-06-15 03:08:36', '[mphb_booking_confirmation]', 'Thanh toán thành công', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2020-06-15 10:08:36', '2020-06-15 03:08:36', '', 27, 'http://localhost:8080/hotel01/27-revision-v1/', 0, 'revision', '', 0),
(301, 1, '2020-06-15 10:35:54', '2020-06-15 03:35:54', '', 'Superior-1-1', '', 'inherit', 'open', 'closed', '', 'superior-1-1', '', '', '2020-06-15 10:35:54', '2020-06-15 03:35:54', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2019/10/Superior-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(302, 1, '2020-06-15 10:35:57', '2020-06-15 03:35:57', '', 'Superior-2-1', '', 'inherit', 'open', 'closed', '', 'superior-2-1', '', '', '2020-06-15 10:35:57', '2020-06-15 03:35:57', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2019/10/Superior-2-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(303, 1, '2020-06-15 10:36:01', '2020-06-15 03:36:01', '', 'Superior-3-1', '', 'inherit', 'open', 'closed', '', 'superior-3-1', '', '', '2020-06-15 10:36:01', '2020-06-15 03:36:01', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2019/10/Superior-3-1.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(304, 1, '2020-06-15 10:44:27', '2020-06-15 03:44:27', '', 'Phòng Superior', '', 'publish', 'closed', 'closed', '', 'phong-superior', '', '', '2020-06-16 16:58:08', '2020-06-16 09:58:08', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=304', 0, 'mphb_room_type', '', 0),
(305, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 101', '', 'publish', 'closed', 'closed', '', 'phong-superior-1', '', '', '2020-06-18 14:52:10', '2020-06-18 07:52:10', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-1/', 0, 'mphb_room', '', 0),
(306, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 102', '', 'publish', 'closed', 'closed', '', 'phong-superior-2', '', '', '2020-06-18 14:52:20', '2020-06-18 07:52:20', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-2/', 0, 'mphb_room', '', 0),
(307, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 103', '', 'publish', 'closed', 'closed', '', 'phong-superior-3', '', '', '2020-06-18 14:52:29', '2020-06-18 07:52:29', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-3/', 0, 'mphb_room', '', 0),
(308, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 104', '', 'publish', 'closed', 'closed', '', 'phong-superior-4', '', '', '2020-06-18 14:52:37', '2020-06-18 07:52:37', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-4/', 0, 'mphb_room', '', 0),
(309, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 105', '', 'publish', 'closed', 'closed', '', 'phong-superior-5', '', '', '2020-06-18 14:52:44', '2020-06-18 07:52:44', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-5/', 0, 'mphb_room', '', 0),
(310, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 106', '', 'publish', 'closed', 'closed', '', 'phong-superior-6', '', '', '2020-06-18 14:52:50', '2020-06-18 07:52:50', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-6/', 0, 'mphb_room', '', 0),
(311, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 107', '', 'publish', 'closed', 'closed', '', 'phong-superior-7', '', '', '2020-06-18 14:52:56', '2020-06-18 07:52:56', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-7/', 0, 'mphb_room', '', 0),
(312, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 108', '', 'publish', 'closed', 'closed', '', 'phong-superior-8', '', '', '2020-06-18 14:53:02', '2020-06-18 07:53:02', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-8/', 0, 'mphb_room', '', 0),
(313, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 109', '', 'publish', 'closed', 'closed', '', 'phong-superior-9', '', '', '2020-06-18 14:53:09', '2020-06-18 07:53:09', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-9/', 0, 'mphb_room', '', 0),
(314, 1, '2020-06-15 10:44:28', '2020-06-15 03:44:28', '', 'Phòng Superior 110', '', 'publish', 'closed', 'closed', '', 'phong-superior-10', '', '', '2020-06-18 14:53:21', '2020-06-18 07:53:21', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-superior-10/', 0, 'mphb_room', '', 0),
(316, 1, '2020-06-15 10:59:28', '2020-06-15 03:59:28', '', 'Giá phòng superior 1.000.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', '316', '', '', '2020-06-16 17:01:58', '2020-06-16 10:01:58', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=316', 0, 'mphb_rate', '', 0),
(317, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view', '', '', '2020-06-16 16:57:49', '2020-06-16 09:57:49', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=317', 0, 'mphb_room_type', '', 0),
(318, 1, '2020-06-15 11:09:04', '2020-06-15 04:09:04', '', 'Deluxe-City-View-1-1', '', 'inherit', 'open', 'closed', '', 'deluxe-city-view-1-1', '', '', '2020-06-15 11:09:04', '2020-06-15 04:09:04', '', 317, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-City-View-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(319, 1, '2020-06-15 11:09:07', '2020-06-15 04:09:07', '', 'Deluxe-City-View-2', '', 'inherit', 'open', 'closed', '', 'deluxe-city-view-2', '', '', '2020-06-15 11:09:07', '2020-06-15 04:09:07', '', 317, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-City-View-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(320, 1, '2020-06-15 11:09:11', '2020-06-15 04:09:11', '', 'Deluxe-City-View-3', '', 'inherit', 'open', 'closed', '', 'deluxe-city-view-3', '', '', '2020-06-15 11:09:11', '2020-06-15 04:09:11', '', 317, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-City-View-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(321, 1, '2020-06-15 11:09:15', '2020-06-15 04:09:15', '', 'Deluxe-City-View-4', '', 'inherit', 'open', 'closed', '', 'deluxe-city-view-4', '', '', '2020-06-15 11:09:15', '2020-06-15 04:09:15', '', 317, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-City-View-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(322, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 201', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-1', '', '', '2020-06-18 14:53:34', '2020-06-18 07:53:34', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-1/', 0, 'mphb_room', '', 0),
(323, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 202', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-2', '', '', '2020-06-18 14:53:39', '2020-06-18 07:53:39', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-2/', 0, 'mphb_room', '', 0),
(324, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 203', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-3', '', '', '2020-06-18 14:53:45', '2020-06-18 07:53:45', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-3/', 0, 'mphb_room', '', 0),
(325, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 204', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-4', '', '', '2020-06-18 14:53:53', '2020-06-18 07:53:53', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-4/', 0, 'mphb_room', '', 0),
(326, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 205', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-5', '', '', '2020-06-18 14:53:59', '2020-06-18 07:53:59', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-5/', 0, 'mphb_room', '', 0),
(327, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 206', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-6', '', '', '2020-06-18 14:54:06', '2020-06-18 07:54:06', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-6/', 0, 'mphb_room', '', 0),
(328, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 207', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-7', '', '', '2020-06-18 14:54:11', '2020-06-18 07:54:11', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-7/', 0, 'mphb_room', '', 0),
(329, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 208', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-8', '', '', '2020-06-18 14:54:17', '2020-06-18 07:54:17', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-8/', 0, 'mphb_room', '', 0),
(330, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 209', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-9', '', '', '2020-06-18 14:54:24', '2020-06-18 07:54:24', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-9/', 0, 'mphb_room', '', 0),
(331, 1, '2020-06-15 11:09:56', '2020-06-15 04:09:56', '', 'Phòng Deluxe City View 210', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-city-view-10', '', '', '2020-06-18 14:54:30', '2020-06-18 07:54:30', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-city-view-10/', 0, 'mphb_room', '', 0),
(332, 1, '2020-06-15 11:11:29', '2020-06-15 04:11:29', '', 'Giá phòng Deluxe City View 1.500.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', 'gia-phong-deluxe-city-view', '', '', '2020-06-16 17:01:29', '2020-06-16 10:01:29', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=332', 0, 'mphb_rate', '', 0),
(333, 1, '2020-06-15 11:15:33', '2020-06-15 04:15:33', '', 'Phòng Deluxe River View', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view', '', '', '2020-06-16 16:57:21', '2020-06-16 09:57:21', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=333', 0, 'mphb_room_type', '', 0),
(334, 1, '2020-06-15 11:15:02', '2020-06-15 04:15:02', '', 'Deluxe-River-View-1', '', 'inherit', 'open', 'closed', '', 'deluxe-river-view-1', '', '', '2020-06-15 11:15:02', '2020-06-15 04:15:02', '', 333, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-River-View-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(335, 1, '2020-06-15 11:15:07', '2020-06-15 04:15:07', '', 'Deluxe-River-View-2', '', 'inherit', 'open', 'closed', '', 'deluxe-river-view-2', '', '', '2020-06-15 11:15:07', '2020-06-15 04:15:07', '', 333, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-River-View-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(336, 1, '2020-06-15 11:15:11', '2020-06-15 04:15:11', '', 'Deluxe-River-View-3', '', 'inherit', 'open', 'closed', '', 'deluxe-river-view-3', '', '', '2020-06-15 11:15:11', '2020-06-15 04:15:11', '', 333, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Deluxe-River-View-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(337, 1, '2020-06-15 11:15:33', '2020-06-15 04:15:33', '', 'Phòng Deluxe River View 301', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-1', '', '', '2020-06-18 14:55:53', '2020-06-18 07:55:53', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-1/', 0, 'mphb_room', '', 0),
(338, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 302', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-2', '', '', '2020-06-18 14:54:48', '2020-06-18 07:54:48', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-2/', 0, 'mphb_room', '', 0),
(339, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 303', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-3', '', '', '2020-06-18 14:54:55', '2020-06-18 07:54:55', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-3/', 0, 'mphb_room', '', 0),
(340, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 304', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-4', '', '', '2020-06-18 14:55:03', '2020-06-18 07:55:03', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-4/', 0, 'mphb_room', '', 0),
(341, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 305', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-5', '', '', '2020-06-18 14:55:13', '2020-06-18 07:55:13', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-5/', 0, 'mphb_room', '', 0),
(342, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 306', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-6', '', '', '2020-06-18 14:55:25', '2020-06-18 07:55:25', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-6/', 0, 'mphb_room', '', 0),
(343, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 307', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-7', '', '', '2020-06-18 14:55:31', '2020-06-18 07:55:31', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-7/', 0, 'mphb_room', '', 0),
(344, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 308', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-8', '', '', '2020-06-18 14:55:37', '2020-06-18 07:55:37', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-8/', 0, 'mphb_room', '', 0),
(345, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 309', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-9', '', '', '2020-06-18 14:55:43', '2020-06-18 07:55:43', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-9/', 0, 'mphb_room', '', 0),
(346, 1, '2020-06-15 11:15:34', '2020-06-15 04:15:34', '', 'Phòng Deluxe River View 310', '', 'publish', 'closed', 'closed', '', 'phong-deluxe-river-view-10', '', '', '2020-06-18 14:55:48', '2020-06-18 07:55:48', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-deluxe-river-view-10/', 0, 'mphb_room', '', 0),
(347, 1, '2020-06-15 11:15:59', '2020-06-15 04:15:59', '', 'Giá Phòng Deluxe River View 1.500.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', 'gia-phong-deluxe-river-view', '', '', '2020-06-16 17:00:52', '2020-06-16 10:00:52', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=347', 0, 'mphb_rate', '', 0),
(348, 1, '2020-06-15 11:20:19', '2020-06-15 04:20:19', '', 'Phòng Signature Suite', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite', '', '', '2020-06-16 16:56:43', '2020-06-16 09:56:43', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=348', 0, 'mphb_room_type', '', 0),
(349, 1, '2020-06-15 11:19:05', '2020-06-15 04:19:05', '', 'Signature-Suite-1-2', '', 'inherit', 'open', 'closed', '', 'signature-suite-1-2', '', '', '2020-06-15 11:19:05', '2020-06-15 04:19:05', '', 348, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Signature-Suite-1-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(350, 1, '2020-06-15 11:19:08', '2020-06-15 04:19:08', '', 'Signature-Suite-2-2', '', 'inherit', 'open', 'closed', '', 'signature-suite-2-2', '', '', '2020-06-15 11:19:08', '2020-06-15 04:19:08', '', 348, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Signature-Suite-2-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(351, 1, '2020-06-15 11:19:12', '2020-06-15 04:19:12', '', 'Signature-Suite-3-2', '', 'inherit', 'open', 'closed', '', 'signature-suite-3-2', '', '', '2020-06-15 11:19:12', '2020-06-15 04:19:12', '', 348, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Signature-Suite-3-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(352, 1, '2020-06-15 11:19:16', '2020-06-15 04:19:16', '', 'Signature-Suite-4-2', '', 'inherit', 'open', 'closed', '', 'signature-suite-4-2', '', '', '2020-06-15 11:19:16', '2020-06-15 04:19:16', '', 348, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Signature-Suite-4-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(353, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 401', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-1', '', '', '2020-06-18 14:56:33', '2020-06-18 07:56:33', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-1/', 0, 'mphb_room', '', 0),
(354, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 402', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-2', '', '', '2020-06-18 14:56:43', '2020-06-18 07:56:43', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-2/', 0, 'mphb_room', '', 0),
(355, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 403', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-3', '', '', '2020-06-18 14:56:52', '2020-06-18 07:56:52', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-3/', 0, 'mphb_room', '', 0),
(356, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 404', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-4', '', '', '2020-06-18 14:56:57', '2020-06-18 07:56:57', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-4/', 0, 'mphb_room', '', 0),
(357, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 405', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-5', '', '', '2020-06-18 14:57:03', '2020-06-18 07:57:03', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-5/', 0, 'mphb_room', '', 0),
(358, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 406', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-6', '', '', '2020-06-18 14:57:11', '2020-06-18 07:57:11', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-6/', 0, 'mphb_room', '', 0),
(359, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 407', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-7', '', '', '2020-06-18 14:57:18', '2020-06-18 07:57:18', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-7/', 0, 'mphb_room', '', 0),
(360, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 408', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-8', '', '', '2020-06-18 14:56:14', '2020-06-18 07:56:14', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-8/', 0, 'mphb_room', '', 0),
(361, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 409', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-9', '', '', '2020-06-18 14:56:20', '2020-06-18 07:56:20', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-9/', 0, 'mphb_room', '', 0),
(362, 1, '2020-06-15 11:20:20', '2020-06-15 04:20:20', '', 'Phòng Signature Suite 410', '', 'publish', 'closed', 'closed', '', 'phong-signature-suite-10', '', '', '2020-06-18 14:56:26', '2020-06-18 07:56:26', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-signature-suite-10/', 0, 'mphb_room', '', 0),
(363, 1, '2020-06-15 11:20:53', '2020-06-15 04:20:53', '', 'Giá Phòng Signature Suite 2.000.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', 'gia-phong-signature-suite', '', '', '2020-06-16 17:00:06', '2020-06-16 10:00:06', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=363', 0, 'mphb_rate', '', 0),
(364, 1, '2020-06-15 11:23:53', '2020-06-15 04:23:53', '', 'Phòng Junior King Suite', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite', '', '', '2020-06-16 16:56:12', '2020-06-16 09:56:12', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=364', 0, 'mphb_room_type', '', 0),
(365, 1, '2020-06-15 11:23:12', '2020-06-15 04:23:12', '', 'Junior-King-Suite-1', '', 'inherit', 'open', 'closed', '', 'junior-king-suite-1', '', '', '2020-06-15 11:23:12', '2020-06-15 04:23:12', '', 364, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Junior-King-Suite-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(366, 1, '2020-06-15 11:23:16', '2020-06-15 04:23:16', '', 'Junior-King-Suite-2', '', 'inherit', 'open', 'closed', '', 'junior-king-suite-2', '', '', '2020-06-15 11:23:16', '2020-06-15 04:23:16', '', 364, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Junior-King-Suite-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(367, 1, '2020-06-15 11:23:53', '2020-06-15 04:23:53', '', 'Phòng Junior King Suite 501', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite-1', '', '', '2020-06-18 14:57:38', '2020-06-18 07:57:38', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-junior-king-suite-1/', 0, 'mphb_room', '', 0),
(368, 1, '2020-06-15 11:23:53', '2020-06-15 04:23:53', '', 'Phòng Junior King Suite 502', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite-2', '', '', '2020-06-18 14:57:44', '2020-06-18 07:57:44', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-junior-king-suite-2/', 0, 'mphb_room', '', 0),
(369, 1, '2020-06-15 11:23:53', '2020-06-15 04:23:53', '', 'Phòng Junior King Suite 503', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite-3', '', '', '2020-06-18 14:57:51', '2020-06-18 07:57:51', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-junior-king-suite-3/', 0, 'mphb_room', '', 0),
(370, 1, '2020-06-15 11:23:53', '2020-06-15 04:23:53', '', 'Phòng Junior King Suite 504', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite-4', '', '', '2020-06-18 14:57:58', '2020-06-18 07:57:58', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-junior-king-suite-4/', 0, 'mphb_room', '', 0),
(371, 1, '2020-06-15 11:23:54', '2020-06-15 04:23:54', '', 'Phòng Junior King Suite 505', '', 'publish', 'closed', 'closed', '', 'phong-junior-king-suite-5', '', '', '2020-06-18 14:57:32', '2020-06-18 07:57:32', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-junior-king-suite-5/', 0, 'mphb_room', '', 0),
(372, 1, '2020-06-15 11:24:33', '2020-06-15 04:24:33', '', 'Giá Phòng Junior King Suite 2.500.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', 'gia-phong-junior-king-suite', '', '', '2020-06-16 16:59:28', '2020-06-16 09:59:28', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=372', 0, 'mphb_rate', '', 0),
(373, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite', '', 'publish', 'open', 'closed', '', 'phong-king-suite', '', '', '2020-06-26 17:18:15', '2020-06-26 10:18:15', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_type&#038;p=373', 0, 'mphb_room_type', '', 4),
(374, 1, '2020-06-15 11:26:28', '2020-06-15 04:26:28', '', 'King-Suite-1', '', 'inherit', 'open', 'closed', '', 'king-suite-1', '', '', '2020-06-15 11:26:28', '2020-06-15 04:26:28', '', 373, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/King-Suite-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(375, 1, '2020-06-15 11:26:31', '2020-06-15 04:26:31', '', 'King-Suite-2', '', 'inherit', 'open', 'closed', '', 'king-suite-2', '', '', '2020-06-15 11:26:31', '2020-06-15 04:26:31', '', 373, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/King-Suite-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(376, 1, '2020-06-15 11:26:35', '2020-06-15 04:26:35', '', 'King-Suite-3', '', 'inherit', 'open', 'closed', '', 'king-suite-3', '', '', '2020-06-15 11:26:35', '2020-06-15 04:26:35', '', 373, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/King-Suite-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(377, 1, '2020-06-15 11:26:39', '2020-06-15 04:26:39', '', 'King-Suite-Garden', '', 'inherit', 'open', 'closed', '', 'king-suite-garden', '', '', '2020-06-15 11:26:39', '2020-06-15 04:26:39', '', 373, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/King-Suite-Garden.jpg', 0, 'attachment', 'image/jpeg', 0),
(378, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite 601', '', 'publish', 'closed', 'closed', '', 'phong-king-suite-1', '', '', '2020-06-18 14:58:13', '2020-06-18 07:58:13', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-king-suite-1/', 0, 'mphb_room', '', 0),
(379, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite 602', '', 'publish', 'closed', 'closed', '', 'phong-king-suite-2', '', '', '2020-06-18 14:58:19', '2020-06-18 07:58:19', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-king-suite-2/', 0, 'mphb_room', '', 0),
(380, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite 603', '', 'publish', 'closed', 'closed', '', 'phong-king-suite-3', '', '', '2020-06-18 14:58:28', '2020-06-18 07:58:28', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-king-suite-3/', 0, 'mphb_room', '', 0),
(381, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite 604', '', 'publish', 'closed', 'closed', '', 'phong-king-suite-4', '', '', '2020-06-18 14:58:35', '2020-06-18 07:58:35', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-king-suite-4/', 0, 'mphb_room', '', 0),
(382, 1, '2020-06-15 11:27:02', '2020-06-15 04:27:02', '', 'Phòng King Suite 605', '', 'publish', 'closed', 'closed', '', 'phong-king-suite-5', '', '', '2020-06-18 14:58:40', '2020-06-18 07:58:40', '', 0, 'http://localhost:8080/hotel01/mphb_room/phong-king-suite-5/', 0, 'mphb_room', '', 0),
(383, 1, '2020-06-15 11:27:22', '2020-06-15 04:27:22', '', 'Giá Phòng King Suite 3.000.000 vnđ / mỗi đêm', '', 'publish', 'closed', 'closed', '', 'gia-phong-king-suite', '', '', '2020-06-16 16:59:01', '2020-06-16 09:59:01', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_rate&#038;p=383', 0, 'mphb_rate', '', 0),
(384, 1, '2020-06-15 11:38:29', '2020-06-15 04:38:29', 'Các món ăn theo phong cách Âu và A sẽ luôn làm hài lòng tất cả các vị thực khách. Thật tuyệt với khi vừa thưởng thức các món ăn ngon và ngắm nhìn sông Hương một cách êm đềm nhất.', 'VIP DINING ROOM', '', 'publish', 'closed', 'closed', '', 'vip-dining-room', '', '', '2020-06-18 16:50:47', '2020-06-18 09:50:47', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_service&#038;p=384', 0, 'mphb_room_service', '', 0),
(385, 1, '2020-06-15 11:37:09', '2020-06-15 04:37:09', '', 'nhahang', '', 'inherit', 'open', 'closed', '', 'nhahang', '', '', '2020-06-15 11:37:09', '2020-06-15 04:37:09', '', 384, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/nhahang.jpg', 0, 'attachment', 'image/jpeg', 0),
(386, 1, '2020-06-15 11:37:10', '2020-06-15 04:37:10', '', 'Venus-Restaurant-1', '', 'inherit', 'open', 'closed', '', 'venus-restaurant-1', '', '', '2020-06-15 11:37:10', '2020-06-15 04:37:10', '', 384, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Venus-Restaurant-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(387, 1, '2020-06-15 11:37:14', '2020-06-15 04:37:14', '', 'Venus-Restaurant-2', '', 'inherit', 'open', 'closed', '', 'venus-restaurant-2', '', '', '2020-06-15 11:37:14', '2020-06-15 04:37:14', '', 384, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Venus-Restaurant-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(388, 1, '2020-06-15 11:37:18', '2020-06-15 04:37:18', '', 'VIP-Dinning-room-2', '', 'inherit', 'open', 'closed', '', 'vip-dinning-room-2', '', '', '2020-06-15 11:37:18', '2020-06-15 04:37:18', '', 384, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/VIP-Dinning-room-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(389, 1, '2020-06-15 11:40:34', '2020-06-15 04:40:34', 'Các món ăn theo phong cách Âu và A sẽ luôn làm hài lòng tất cả các vị thực khách. Thật tuyệt với khi vừa thưởng thức các món ăn ngon và ngắm nhìn sông Hương một cách êm đềm nhất.<img class=\"size-medium wp-image-385 alignleft\" src=\"http://localhost:8080/hotel01/wp-content/uploads/2020/06/nhahang-300x220.jpg\" alt=\"\" width=\"300\" height=\"220\" />', 'VIP DINING ROOM', '', 'inherit', 'closed', 'closed', '', '384-autosave-v1', '', '', '2020-06-15 11:40:34', '2020-06-15 04:40:34', '', 384, 'http://localhost:8080/hotel01/384-autosave-v1/', 0, 'revision', '', 0),
(390, 1, '2020-06-15 11:43:36', '2020-06-15 04:43:36', 'Nhà hàng Venus là một địa điểm lý tưởng để vừa thưởng thức các món ăn ngon và ngắm nhìn sông Hương một cách nhẹ nhàng nhưng đầy thú vị. Với một không gian đẹp, các món ẩm thực Âu & Á phong phú, sẽ làm hài long tất cả các vị khách khi đã đặt chân tới đây.\r\n\r\n', 'NHÀ HÀNG VENUS', '', 'publish', 'open', 'closed', '', 'nha-hang-venus', '', '', '2020-06-18 16:48:39', '2020-06-18 09:48:39', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_service&#038;p=390', 0, 'mphb_room_service', '', 0),
(391, 1, '2020-06-15 11:46:51', '2020-06-15 04:46:51', 'Không gian mở trên Sirius Bar là một địa điểm lý tưởng để vùa thưởng thức một ly Coctail vừa thư giãn và ngắm nhìn khung cảnh thành phố một cách êm đềm nhất. Tạm xa rời những khung cảnh nhộn nhịp, ồn ào của thành phố, Sirius Bar là nơi để bạn có thể thư giãn đầu ốc vài giây phút, lắng động lại và cảm nhận cuộc sống thật thú vị và thoải mái.\r\n\r\n', 'BAR', '', 'publish', 'open', 'closed', '', 'bar', '', '', '2020-06-18 16:49:17', '2020-06-18 09:49:17', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_service&#038;p=391', 0, 'mphb_room_service', '', 0),
(392, 1, '2020-06-15 11:46:26', '2020-06-15 04:46:26', '', 'Lunar-Bar-1', '', 'inherit', 'open', 'closed', '', 'lunar-bar-1', '', '', '2020-06-15 11:46:26', '2020-06-15 04:46:26', '', 391, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Lunar-Bar-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(393, 1, '2020-06-15 11:46:30', '2020-06-15 04:46:30', '', 'Lunar-Bar-2', '', 'inherit', 'open', 'closed', '', 'lunar-bar-2', '', '', '2020-06-15 11:46:30', '2020-06-15 04:46:30', '', 391, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/Lunar-Bar-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(394, 1, '2020-06-15 11:46:34', '2020-06-15 04:46:34', '', 'View-from-Rooftop-Bar-1', '', 'inherit', 'open', 'closed', '', 'view-from-rooftop-bar-1', '', '', '2020-06-15 11:46:34', '2020-06-15 04:46:34', '', 391, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/View-from-Rooftop-Bar-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(395, 1, '2020-06-15 11:50:37', '2020-06-15 04:50:37', 'Moonshine Spa với những phương pháp trị liệu phong phú, các liệu pháp chăm sóc toàn thân, chăm sóc sắc đẹp đảm bảo mang lại cho bạn cảm giác tuyệt vời nhất. Chúng tôi-với đội ngũ chuyên viên bài bản rất vui để đưa bạn đắm mình trong các cung bậc thư giãn.\r\n<strong>Giờ phục vụ:</strong> Từ 10.00 sáng đến 10.00 tối hàng ngày', 'SPA MOONSHINE', '', 'publish', 'open', 'closed', '', 'spa-moonshine', '', '', '2020-06-18 16:47:54', '2020-06-18 09:47:54', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_room_service&#038;p=395', 0, 'mphb_room_service', '', 0),
(396, 1, '2020-06-15 11:50:33', '2020-06-15 04:50:33', '', 'moonspa_vi', '', 'inherit', 'open', 'closed', '', 'moonspa_vi', '', '', '2020-06-15 11:50:33', '2020-06-15 04:50:33', '', 395, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/moonspa_vi.jpg', 0, 'attachment', 'image/jpeg', 0),
(398, 1, '2020-06-16 14:04:59', '2020-06-16 07:04:59', '{\n    \"hotel_galaxy_option[address]\": {\n        \"value\": \"20 Ph\\u1ea1m Ng\\u0169 L\\u00e3o, th\\u00e0nh ph\\u1ed1 Hu\\u1ebf\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:04:44\"\n    },\n    \"hotel_galaxy_option[reservation_line]\": {\n        \"value\": \"+84 (0)234 3979797\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:04:59\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3beac3d5-d98b-44c7-afb6-86aa9b17ebaf', '', '', '2020-06-16 14:04:59', '2020-06-16 07:04:59', '', 0, 'http://localhost:8080/hotel01/?p=398', 0, 'customize_changeset', '', 0),
(399, 1, '2020-06-16 14:06:00', '2020-06-16 07:06:00', '{\n    \"hotel_galaxy_option[hotel_galaxy_developed_by_text]\": {\n        \"value\": \"- Moonlight\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:06:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8ac8b527-c126-49d1-aa82-4ecca14d49bc', '', '', '2020-06-16 14:06:00', '2020-06-16 07:06:00', '', 0, 'http://localhost:8080/hotel01/8ac8b527-c126-49d1-aa82-4ecca14d49bc/', 0, 'customize_changeset', '', 0),
(401, 1, '2020-06-16 14:20:18', '2020-06-16 07:20:18', '', 'Moonlight hotel slide', '', 'publish', 'closed', 'closed', '', 'moonlight-hotel-slide', '', '', '2020-06-16 14:20:19', '2020-06-16 07:20:19', '', 0, 'http://localhost:8080/hotel01/?page_id=401', 0, 'page', '', 0),
(402, 1, '2020-06-16 14:19:19', '2020-06-16 07:19:19', '', 'home_slide1', '', 'inherit', 'open', 'closed', '', 'home_slide1', '', '', '2020-06-16 14:19:19', '2020-06-16 07:19:19', '', 401, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/home_slide1.jpg', 0, 'attachment', 'image/jpeg', 0),
(403, 1, '2020-06-16 14:19:22', '2020-06-16 07:19:22', '', 'MoonlightHotel-Dinning-Special-Slide', '', 'inherit', 'open', 'closed', '', 'moonlighthotel-dinning-special-slide', '', '', '2020-06-16 14:19:22', '2020-06-16 07:19:22', '', 401, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/MoonlightHotel-Dinning-Special-Slide.jpg', 0, 'attachment', 'image/jpeg', 0),
(404, 1, '2020-06-16 14:19:24', '2020-06-16 07:19:24', '', 'MoonlightHotel-Leisure-Breaks-Slide', '', 'inherit', 'open', 'closed', '', 'moonlighthotel-leisure-breaks-slide', '', '', '2020-06-16 14:19:24', '2020-06-16 07:19:24', '', 401, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/MoonlightHotel-Leisure-Breaks-Slide.jpg', 0, 'attachment', 'image/jpeg', 0),
(405, 1, '2020-06-16 14:19:26', '2020-06-16 07:19:26', '', 'MoonlightHotel-Moonshine-Spa-Slide', '', 'inherit', 'open', 'closed', '', 'moonlighthotel-moonshine-spa-slide', '', '', '2020-06-16 14:19:26', '2020-06-16 07:19:26', '', 401, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/MoonlightHotel-Moonshine-Spa-Slide.jpg', 0, 'attachment', 'image/jpeg', 0),
(406, 1, '2020-06-16 14:19:28', '2020-06-16 07:19:28', '', 'MoonlightHotel-Slide-03', '', 'inherit', 'open', 'closed', '', 'moonlighthotel-slide-03', '', '', '2020-06-16 14:19:28', '2020-06-16 07:19:28', '', 401, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/MoonlightHotel-Slide-03.jpg', 0, 'attachment', 'image/jpeg', 0),
(407, 1, '2020-06-16 14:20:18', '2020-06-16 07:20:18', '', 'Moonlight hotel slide', '', 'inherit', 'closed', 'closed', '', '401-revision-v1', '', '', '2020-06-16 14:20:18', '2020-06-16 07:20:18', '', 401, 'http://localhost:8080/hotel01/401-revision-v1/', 0, 'revision', '', 0),
(408, 1, '2020-06-16 14:22:06', '2020-06-16 07:22:06', '', 'Moonlight hotel spa slide', '', 'publish', 'closed', 'closed', '', 'moonlight-hotel-spa-slide', '', '', '2020-06-16 14:22:07', '2020-06-16 07:22:07', '', 0, 'http://localhost:8080/hotel01/?page_id=408', 0, 'page', '', 0),
(409, 1, '2020-06-16 14:22:06', '2020-06-16 07:22:06', '', 'Moonlight hotel spa slide', '', 'inherit', 'closed', 'closed', '', '408-revision-v1', '', '', '2020-06-16 14:22:06', '2020-06-16 07:22:06', '', 408, 'http://localhost:8080/hotel01/408-revision-v1/', 0, 'revision', '', 0),
(410, 1, '2020-06-16 14:23:11', '2020-06-16 07:23:11', '', 'Moonlight hotel dinning slide', '', 'publish', 'closed', 'closed', '', 'moonlight-hotel-dinning-slide', '', '', '2020-06-16 14:23:13', '2020-06-16 07:23:13', '', 0, 'http://localhost:8080/hotel01/?page_id=410', 0, 'page', '', 0),
(411, 1, '2020-06-16 14:23:11', '2020-06-16 07:23:11', '', 'Moonlight hotel dinning slide', '', 'inherit', 'closed', 'closed', '', '410-revision-v1', '', '', '2020-06-16 14:23:11', '2020-06-16 07:23:11', '', 410, 'http://localhost:8080/hotel01/410-revision-v1/', 0, 'revision', '', 0),
(412, 1, '2020-06-16 14:23:58', '2020-06-16 07:23:58', '', 'Moonlight hotel home slide', '', 'publish', 'closed', 'closed', '', 'moonlight-hotel-home-slide', '', '', '2020-06-16 14:28:59', '2020-06-16 07:28:59', '', 0, 'http://localhost:8080/hotel01/?page_id=412', 0, 'page', '', 0),
(413, 1, '2020-06-16 14:23:58', '2020-06-16 07:23:58', '', 'Moonlight hotel home slide', '', 'inherit', 'closed', 'closed', '', '412-revision-v1', '', '', '2020-06-16 14:23:58', '2020-06-16 07:23:58', '', 412, 'http://localhost:8080/hotel01/412-revision-v1/', 0, 'revision', '', 0),
(414, 1, '2020-06-16 14:24:50', '2020-06-16 07:24:50', '', 'Moonlight hotel leisure break slide', '', 'publish', 'closed', 'closed', '', 'moonlight-hotel-leisure-break-slide', '', '', '2020-06-16 14:24:51', '2020-06-16 07:24:51', '', 0, 'http://localhost:8080/hotel01/?page_id=414', 0, 'page', '', 0),
(415, 1, '2020-06-16 14:24:50', '2020-06-16 07:24:50', '', 'Moonlight hotel leisure break slide', '', 'inherit', 'closed', 'closed', '', '414-revision-v1', '', '', '2020-06-16 14:24:50', '2020-06-16 07:24:50', '', 414, 'http://localhost:8080/hotel01/414-revision-v1/', 0, 'revision', '', 0),
(416, 1, '2020-06-16 14:26:31', '2020-06-16 07:26:31', '{\n    \"hotel-galaxy::Page_slider_1\": {\n        \"value\": \"412\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:26:31\"\n    },\n    \"hotel-galaxy::Page_slider_2\": {\n        \"value\": \"410\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:26:31\"\n    },\n    \"hotel-galaxy::Page_slider_3\": {\n        \"value\": \"408\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:26:31\"\n    },\n    \"hotel-galaxy::Page_slider_4\": {\n        \"value\": \"414\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:26:31\"\n    },\n    \"hotel-galaxy::Page_slider_5\": {\n        \"value\": \"401\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:26:31\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f4ad0e41-00fb-44ea-81e0-71c109d2b87d', '', '', '2020-06-16 14:26:31', '2020-06-16 07:26:31', '', 0, 'http://localhost:8080/hotel01/?p=416', 0, 'customize_changeset', '', 0),
(417, 1, '2020-06-16 14:27:15', '2020-06-16 07:27:15', '{\n    \"hotel_galaxy_option[slider_smartphone_res]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:27:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8a731611-a264-4da5-84f1-6e35a568a496', '', '', '2020-06-16 14:27:15', '2020-06-16 07:27:15', '', 0, 'http://localhost:8080/hotel01/8a731611-a264-4da5-84f1-6e35a568a496/', 0, 'customize_changeset', '', 0),
(418, 1, '2020-06-16 14:27:31', '2020-06-16 07:27:31', '{\n    \"hotel_galaxy_option[slider_smartphone_res]\": {\n        \"value\": false,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 07:27:31\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '392be279-3cff-423e-bd0e-c1371680999a', '', '', '2020-06-16 14:27:31', '2020-06-16 07:27:31', '', 0, 'http://localhost:8080/hotel01/392be279-3cff-423e-bd0e-c1371680999a/', 0, 'customize_changeset', '', 0),
(420, 1, '2020-06-16 14:48:20', '2020-06-16 07:48:20', '', '', '', 'confirmed', 'closed', 'closed', '', '420', '', '', '2020-06-16 14:48:20', '2020-06-16 07:48:20', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=420', 0, 'mphb_booking', '', 6),
(421, 1, '2020-06-16 14:46:18', '2020-06-16 07:46:18', '', '', '', 'publish', 'closed', 'closed', '', '421', '', '', '2020-06-16 14:46:18', '2020-06-16 07:46:18', '', 420, 'http://localhost:8080/hotel01/mphb_reserved_room/421/', 0, 'mphb_reserved_room', '', 0),
(422, 1, '2020-06-16 14:46:18', '2020-06-16 07:46:18', '', '', '', 'publish', 'closed', 'closed', '', '422', '', '', '2020-06-16 14:46:18', '2020-06-16 07:46:18', '', 420, 'http://localhost:8080/hotel01/mphb_reserved_room/422/', 0, 'mphb_reserved_room', '', 0),
(425, 1, '2020-06-16 15:46:30', '2020-06-16 08:46:30', 'Địa điểm: Từ tầng 3 đến 12', 'Phòng Deluxe City View', '', 'inherit', 'closed', 'closed', '', '317-autosave-v1', '', '', '2020-06-16 15:46:30', '2020-06-16 08:46:30', '', 317, 'http://localhost:8080/hotel01/317-autosave-v1/', 0, 'revision', '', 0),
(427, 1, '2020-06-16 15:55:10', '2020-06-16 08:55:10', 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2020-06-16 15:55:10', '2020-06-16 08:55:10', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/cropped-logo.png', 0, 'attachment', 'image/png', 0),
(428, 1, '2020-06-16 16:08:54', '2020-06-16 09:08:54', '{\n    \"hotel-galaxy::custom_logo\": {\n        \"value\": 427,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 08:56:12\"\n    },\n    \"site_icon\": {\n        \"value\": 432,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 09:08:54\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c14a0508-4a38-4996-941d-ec343531a5a4', '', '', '2020-06-16 16:08:54', '2020-06-16 09:08:54', '', 0, 'http://localhost:8080/hotel01/?p=428', 0, 'customize_changeset', '', 0),
(432, 1, '2020-06-16 16:08:40', '2020-06-16 09:08:40', '', 'logo3', '', 'inherit', 'open', 'closed', '', 'logo3', '', '', '2020-06-16 16:08:40', '2020-06-16 09:08:40', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/logo3.jpg', 0, 'attachment', 'image/jpeg', 0),
(433, 1, '2020-06-16 16:10:17', '2020-06-16 09:10:17', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2020-06-16 16:10:17', '2020-06-16 09:10:17', '', 0, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/logo.png', 0, 'attachment', 'image/png', 0),
(434, 1, '2020-06-16 16:10:28', '2020-06-16 09:10:28', '{\n    \"hotel-galaxy::custom_logo\": {\n        \"value\": 433,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 09:10:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd48ae355-fefd-4d31-b8c6-b81662c1a79c', '', '', '2020-06-16 16:10:28', '2020-06-16 09:10:28', '', 0, 'http://localhost:8080/hotel01/?p=434', 0, 'customize_changeset', '', 0),
(435, 1, '2020-06-16 16:13:42', '2020-06-16 09:13:42', '{\n    \"hotel_galaxy_option[hotel_galaxy_copyright]\": {\n        \"value\": \"Copyright 2020\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-16 09:13:42\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '5082211b-4855-42d6-8204-58773f013ce0', '', '', '2020-06-16 16:13:42', '2020-06-16 09:13:42', '', 0, 'http://localhost:8080/hotel01/5082211b-4855-42d6-8204-58773f013ce0/', 0, 'customize_changeset', '', 0),
(436, 0, '2020-06-16 16:17:11', '2020-06-16 09:17:11', 'hoài\nnguyenvanhoai1280@gmail.com\nđặt phòng\ntôi muốn đặt phòng\n1\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/lien-he/\n16/06/2020\n4:17 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong', '', '', '2020-06-16 16:17:11', '2020-06-16 09:17:11', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=436', 0, 'flamingo_inbound', '', 0),
(437, 0, '2020-06-16 16:18:46', '2020-06-16 09:18:46', 'hoài\nnguyenvanhoai1280@gmail.com\nđặt phòng\ntôi muốn đặt phòng vip\n2\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/lien-he/\n16/06/2020\n4:18 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong-2', '', '', '2020-06-16 16:18:46', '2020-06-16 09:18:46', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=437', 0, 'flamingo_inbound', '', 0),
(438, 0, '2020-06-16 16:22:23', '2020-06-16 09:22:23', 'hoài\nnguyenvanhoai1280@gmail.com\nđặt phòng\nss\n3\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/lien-he/\n16/06/2020\n4:22 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong-3', '', '', '2020-06-16 16:22:23', '2020-06-16 09:22:23', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=438', 0, 'flamingo_inbound', '', 0),
(439, 0, '2020-06-16 16:25:37', '2020-06-16 09:25:37', 'hoài\nnguyenthimynga0505@gmail.com\nđặt phòng\nđ\n4\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/\n16/06/2020\n4:25 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong-4', '', '', '2020-06-16 16:25:37', '2020-06-16 09:25:37', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=439', 0, 'flamingo_inbound', '', 0),
(440, 0, '2020-06-16 16:29:33', '2020-06-16 09:29:33', 'hoài\nnguyenthimynga0505@gmail.com\nđặt phòng\nsda\n5\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/\n16/06/2020\n4:29 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong-5', '', '', '2020-06-16 16:29:33', '2020-06-16 09:29:33', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=440', 0, 'flamingo_inbound', '', 0),
(441, 1, '2020-06-26 17:24:11', '2020-06-26 10:24:11', 'nguyenthimynga0505@gmail.com\nhoài', 'nguyenthimynga0505@gmail.com', '', 'publish', 'closed', 'closed', '', 'nguyenthimynga0505-gmail-com', '', '', '2020-06-26 17:24:11', '2020-06-26 10:24:11', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_contact&#038;p=441', 0, 'flamingo_contact', '', 0),
(442, 0, '2020-06-16 16:38:25', '2020-06-16 09:38:25', 'hoài\nnguyenthimynga0505@gmail.com\nđặt phòng\ncc\n6\n::1\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\nhttp://localhost:8080/hotel01/\n16/06/2020\n4:38 chiều\nMoonlight Hotel\nThiên đường nghĩ dưỡng\nhttp://localhost:8080/hotel01\nnguyenvanhoai1280@gmail.com', 'đặt phòng', '', 'publish', 'closed', 'closed', '', 'dat-phong-6', '', '', '2020-06-16 16:38:25', '2020-06-16 09:38:25', '', 0, 'http://localhost:8080/hotel01/?post_type=flamingo_inbound&p=442', 0, 'flamingo_inbound', '', 0),
(443, 1, '2020-06-16 16:51:38', '2020-06-16 09:51:38', '', '', '', 'confirmed', 'closed', 'closed', '', '443', '', '', '2020-06-16 16:52:27', '2020-06-16 09:52:27', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=443', 0, 'mphb_booking', '', 8),
(444, 1, '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', '', '', 'publish', 'closed', 'closed', '', '444', '', '', '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', 443, 'http://localhost:8080/hotel01/mphb_reserved_room/444/', 0, 'mphb_reserved_room', '', 0),
(445, 1, '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', '', '', 'publish', 'closed', 'closed', '', '445', '', '', '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', 443, 'http://localhost:8080/hotel01/mphb_reserved_room/445/', 0, 'mphb_reserved_room', '', 0),
(446, 1, '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', '', '', 'publish', 'closed', 'closed', '', '446', '', '', '2020-06-16 16:49:28', '2020-06-16 09:49:28', '', 443, 'http://localhost:8080/hotel01/mphb_reserved_room/446/', 0, 'mphb_reserved_room', '', 0),
(447, 1, '2020-06-16 17:05:29', '2020-06-16 10:05:29', '', '', '', 'confirmed', 'closed', 'closed', '', '447', '', '', '2020-06-16 17:05:29', '2020-06-16 10:05:29', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=447', 0, 'mphb_booking', '', 6),
(448, 1, '2020-06-16 17:04:18', '2020-06-16 10:04:18', '', '', '', 'publish', 'closed', 'closed', '', '448', '', '', '2020-06-16 17:04:18', '2020-06-16 10:04:18', '', 447, 'http://localhost:8080/hotel01/mphb_reserved_room/448/', 0, 'mphb_reserved_room', '', 0),
(449, 1, '2020-06-16 17:13:45', '2020-06-16 10:13:45', '', '', '', 'confirmed', 'closed', 'closed', '', '449', '', '', '2020-06-16 17:13:45', '2020-06-16 10:13:45', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=449', 0, 'mphb_booking', '', 6),
(450, 1, '2020-06-16 17:12:53', '2020-06-16 10:12:53', '', '', '', 'publish', 'closed', 'closed', '', '450', '', '', '2020-06-16 17:12:53', '2020-06-16 10:12:53', '', 449, 'http://localhost:8080/hotel01/mphb_reserved_room/450/', 0, 'mphb_reserved_room', '', 0),
(451, 1, '2020-06-16 17:14:44', '2020-06-16 10:14:44', '', 'Lưu bản nháp tự động', '', 'mphb-p-completed', 'closed', 'closed', '', 'luu-ban-nhap-tu-dong', '', '', '2020-06-16 17:14:44', '2020-06-16 10:14:44', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_payment&#038;p=451', 0, 'mphb_payment', '', 0),
(455, 1, '2020-06-17 19:15:02', '2020-06-17 12:15:02', '', '', '', 'confirmed', 'closed', 'closed', '', '455', '', '', '2020-06-17 19:15:02', '2020-06-17 12:15:02', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=455', 0, 'mphb_booking', '', 6),
(456, 1, '2020-06-17 19:13:43', '2020-06-17 12:13:43', '', '', '', 'publish', 'closed', 'closed', '', '456', '', '', '2020-06-17 19:13:43', '2020-06-17 12:13:43', '', 455, 'http://localhost:8080/hotel01/mphb_reserved_room/456/', 0, 'mphb_reserved_room', '', 0),
(457, 1, '2020-06-17 19:13:43', '2020-06-17 12:13:43', '', '', '', 'publish', 'closed', 'closed', '', '457', '', '', '2020-06-17 19:13:43', '2020-06-17 12:13:43', '', 455, 'http://localhost:8080/hotel01/mphb_reserved_room/457/', 0, 'mphb_reserved_room', '', 0),
(458, 1, '2020-06-17 19:15:30', '2020-06-17 12:15:30', '', 'Lưu bản nháp tự động', '', 'mphb-p-completed', 'closed', 'closed', '', 'luu-ban-nhap-tu-dong-2', '', '', '2020-06-17 19:15:30', '2020-06-17 12:15:30', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_payment&#038;p=458', 0, 'mphb_payment', '', 0),
(459, 1, '2020-06-18 14:35:35', '0000-00-00 00:00:00', '', '', '', 'pending', 'closed', 'closed', '', '', '', '', '2020-06-18 14:35:35', '2020-06-18 07:35:35', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=459', 0, 'mphb_booking', '', 4),
(460, 1, '2020-06-18 14:35:35', '2020-06-18 07:35:35', '', '', '', 'publish', 'closed', 'closed', '', '460', '', '', '2020-06-18 14:35:35', '2020-06-18 07:35:35', '', 459, 'http://localhost:8080/hotel01/mphb_reserved_room/460/', 0, 'mphb_reserved_room', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(461, 1, '2020-06-18 14:35:35', '2020-06-18 07:35:35', '', '', '', 'publish', 'closed', 'closed', '', '461', '', '', '2020-06-18 14:35:35', '2020-06-18 07:35:35', '', 459, 'http://localhost:8080/hotel01/mphb_reserved_room/461/', 0, 'mphb_reserved_room', '', 0),
(462, 1, '2020-06-18 15:19:41', '2020-06-18 08:19:41', '', '', '', 'confirmed', 'closed', 'closed', '', '462', '', '', '2020-06-18 15:20:12', '2020-06-18 08:20:12', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=462', 0, 'mphb_booking', '', 7),
(463, 1, '2020-06-18 15:11:03', '2020-06-18 08:11:03', '', '', '', 'publish', 'closed', 'closed', '', '463', '', '', '2020-06-18 15:11:03', '2020-06-18 08:11:03', '', 462, 'http://localhost:8080/hotel01/mphb_reserved_room/463/', 0, 'mphb_reserved_room', '', 0),
(464, 1, '2020-06-18 15:11:03', '2020-06-18 08:11:03', '', '', '', 'publish', 'closed', 'closed', '', '464', '', '', '2020-06-18 15:11:03', '2020-06-18 08:11:03', '', 462, 'http://localhost:8080/hotel01/mphb_reserved_room/464/', 0, 'mphb_reserved_room', '', 0),
(466, 1, '2020-06-18 15:18:44', '2020-06-18 08:18:44', '', 'Lưu bản nháp tự động', '', 'mphb-p-completed', 'closed', 'closed', '', 'luu-ban-nhap-tu-dong-4', '', '', '2020-06-18 15:18:44', '2020-06-18 08:18:44', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_payment&#038;p=466', 0, 'mphb_payment', '', 0),
(467, 1, '2020-06-18 15:20:44', '2020-06-18 08:20:44', '', 'Lưu bản nháp tự động', '', 'mphb-p-completed', 'closed', 'closed', '', 'luu-ban-nhap-tu-dong-5', '', '', '2020-06-18 15:20:44', '2020-06-18 08:20:44', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_payment&#038;p=467', 0, 'mphb_payment', '', 0),
(469, 1, '2020-06-18 15:57:15', '2020-06-18 08:57:15', '', '', '', 'confirmed', 'closed', 'closed', '', '469', '', '', '2020-06-18 15:57:15', '2020-06-18 08:57:15', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=469', 0, 'mphb_booking', '', 6),
(470, 1, '2020-06-18 15:56:26', '2020-06-18 08:56:26', '', '', '', 'publish', 'closed', 'closed', '', '470', '', '', '2020-06-18 15:56:26', '2020-06-18 08:56:26', '', 469, 'http://localhost:8080/hotel01/mphb_reserved_room/470/', 0, 'mphb_reserved_room', '', 0),
(471, 1, '2020-06-18 15:57:34', '2020-06-18 08:57:34', '', 'Lưu bản nháp tự động', '', 'mphb-p-completed', 'closed', 'closed', '', 'luu-ban-nhap-tu-dong-3', '', '', '2020-06-18 15:57:34', '2020-06-18 08:57:34', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_payment&#038;p=471', 0, 'mphb_payment', '', 0),
(472, 1, '2020-06-18 16:20:46', '2020-06-18 09:20:46', '<!-- wp:motopress-hotel-booking/booking-confirmation /-->', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:20:46', '2020-06-18 09:20:46', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(473, 1, '2020-06-18 16:22:07', '2020-06-18 09:22:07', '<!-- wp:motopress-hotel-booking/booking-confirmation /-->\n\n<!-- wp:motopress-hotel-booking/checkout /-->', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:22:07', '2020-06-18 09:22:07', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(474, 1, '2020-06-18 16:22:56', '2020-06-18 09:22:56', '<!-- wp:motopress-hotel-booking/booking-confirmation /-->\n\n<!-- wp:motopress-hotel-booking/checkout /-->\n\n<!-- wp:motopress-hotel-booking/availability /-->', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:22:56', '2020-06-18 09:22:56', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(475, 1, '2020-06-18 16:24:17', '2020-06-18 09:24:17', '<!-- wp:html -->\n<div class=\"map\" style=\"overflow:hidden;width: 537px;position: relative;\">\n                                    <iframe width=\"537\" height=\"251\" src=\"https://maps.google.com/maps?width=537&amp;height=251&amp;hl=en&amp;q=1%20Station%20St%20Highett+(Title)&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"></iframe>\n\n                                    <style>\n                                        #gmap_canvas img {\n                                            max-width: none!important;\n                                            background: none!important\n                                        }\n                                    </style>\n                                </div><br />\n<!-- /wp:html -->', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:24:17', '2020-06-18 09:24:17', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(483, 1, '2020-06-18 16:34:41', '2020-06-18 09:34:41', '<!-- wp:html -->\n<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4550.042869712686!2d107.59081855779567!3d16.46972685715659!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3141a13cd1fb6a3d%3A0xb69ec59e61660f7a!2sMoonlight%20Hotel%20Hue!5e0!3m2!1svi!2s!4v1592472489058!5m2!1svi!2s\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>\n<!-- /wp:html -->', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:34:41', '2020-06-18 09:34:41', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(484, 1, '2020-06-18 16:45:19', '2020-06-18 09:45:19', '', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '273-revision-v1', '', '', '2020-06-18 16:45:19', '2020-06-18 09:45:19', '', 273, 'http://localhost:8080/hotel01/273-revision-v1/', 0, 'revision', '', 0),
(486, 1, '2020-06-27 10:17:16', '2020-06-27 03:17:16', '{\n    \"hotel-galaxy::Page_about_1\": {\n        \"value\": \"241\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 03:17:16\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0164affd-3ec2-4c68-a8af-a93cb7bddfb9', '', '', '2020-06-27 10:17:16', '2020-06-27 03:17:16', '', 0, 'http://localhost:8080/hotel01/0164affd-3ec2-4c68-a8af-a93cb7bddfb9/', 0, 'customize_changeset', '', 0),
(487, 1, '2020-06-27 10:20:32', '0000-00-00 00:00:00', '{\n    \"hotel-galaxy::Page_about_6\": {\n        \"value\": \"241\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 03:20:32\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'c90a86e5-d2b4-465d-9d22-19a869028e66', '', '', '2020-06-27 10:20:32', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/hotel01/?p=487', 0, 'customize_changeset', '', 0),
(488, 1, '2020-06-27 10:25:05', '0000-00-00 00:00:00', '{\n    \"hotel-galaxy::Page_about_6\": {\n        \"value\": \"414\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 03:25:05\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'dd1af8b6-d6b2-4ab9-8629-b18ad38fd5b1', '', '', '2020-06-27 10:25:05', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/hotel01/?p=488', 0, 'customize_changeset', '', 0),
(489, 1, '2020-06-27 11:07:35', '2020-06-27 04:07:35', '{\n    \"hotel-galaxy::Page_about\": {\n        \"value\": \"412\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:07:35\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c23277de-7fbf-45ed-9f32-349869e53107', '', '', '2020-06-27 11:07:35', '2020-06-27 04:07:35', '', 0, 'http://localhost:8080/hotel01/c23277de-7fbf-45ed-9f32-349869e53107/', 0, 'customize_changeset', '', 0),
(490, 1, '2020-06-27 11:15:44', '2020-06-27 04:15:44', '{\n    \"hotel-galaxy::Page_about\": {\n        \"value\": \"414\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:15:44\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c7bf2082-15ca-49f9-9ad6-29f915915c5f', '', '', '2020-06-27 11:15:44', '2020-06-27 04:15:44', '', 0, 'http://localhost:8080/hotel01/c7bf2082-15ca-49f9-9ad6-29f915915c5f/', 0, 'customize_changeset', '', 0),
(491, 1, '2020-06-27 11:36:44', '0000-00-00 00:00:00', '{\n    \"hotel_galaxy_option[about_show]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:36:44\"\n    },\n    \"hotel_galaxy_option[about_title]\": {\n        \"value\": \"Kh\\u00e1ch s\\u1ea1n\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:36:44\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '2127703e-6336-4603-af1c-30e1f3ffa332', '', '', '2020-06-27 11:36:44', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/hotel01/?p=491', 0, 'customize_changeset', '', 0),
(492, 1, '2020-06-27 11:59:59', '2020-06-27 04:59:59', '{\n    \"hotel_galaxy_option[about_show]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:59:59\"\n    },\n    \"hotel_galaxy_option[about_title]\": {\n        \"value\": \"kh\\u00e1ch s\\u1ea1n\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-27 04:59:59\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0f326797-a8d2-4491-af28-a2660b64a8ec', '', '', '2020-06-27 11:59:59', '2020-06-27 04:59:59', '', 0, 'http://localhost:8080/hotel01/0f326797-a8d2-4491-af28-a2660b64a8ec/', 0, 'customize_changeset', '', 0),
(493, 1, '2020-06-27 15:40:35', '2020-06-27 08:40:35', '', '', '', 'confirmed', 'closed', 'closed', '', '493', '', '', '2020-06-27 15:41:05', '2020-06-27 08:41:05', '', 0, 'http://localhost:8080/hotel01/?post_type=mphb_booking&#038;p=493', 0, 'mphb_booking', '', 7),
(494, 1, '2020-06-27 15:39:07', '2020-06-27 08:39:07', '', '', '', 'publish', 'closed', 'closed', '', '494', '', '', '2020-06-27 15:39:07', '2020-06-27 08:39:07', '', 493, 'http://localhost:8080/hotel01/mphb_reserved_room/494/', 0, 'mphb_reserved_room', '', 0),
(495, 1, '2020-06-28 09:09:31', '2020-06-28 02:09:31', '<!-- wp:paragraph -->\n<p>\n\nVới nét thâm trầm cổ kính đầy quyến rũ, Cố đô Huế đã chinh phục trái tim của nhiều du khách đến từ nước ngoài. Cùng xem loạt ảnh đẹp mê mẩn về xứ Huế do các nhiếp ảnh gia quốc tế thực hiện.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%201.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cảnh hoàng hôn huyền ảo trên sông Hương, dòng sông biểu tượng của Cố đô Huế. Ảnh: David Duffy / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%202.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cầu Trường Tiền lộng lẫy trong ráng chiều màu tím. Ảnh: David Duffy / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%203.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cổng Hiển Nhơn của Hoàng thành Huế trong buổi chiều tà. Ảnh: Ravi Putcha / 500px.com.&nbsp;</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%204.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Quốc kỳ Việt Nam tung bay kiêu hãnh trên Kỳ đài Huế. Ảnh: Aitor Caminero / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%205.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Lầu tứ phương vô sự rực sáng anh đèn, soi bóng xuống mặt nước phẳng lặng của hào thành. Ảnh: Julia Elisabeth / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%206.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Những người dân chài Huế đánh lưới trên sông. Ảnh: Julia Elisabeth / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%207.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Trong lăng vua Minh Mạng. Ảnh: Olivier Sylvain / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%208.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Sắc màu rực rỡ tại Trường lang của Hoàng thành Huế. Ảnh: Olivier Sylvain / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%209.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Kiến trúc thanh thoát của lầu bát giác trước điện Kiến Trung ở Hoàng thành Huế. Ảnh: Paul Lynch / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%2010.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Nét hoài cổ của tòa Minh Lâu trong lăng vua Minh Mạng. Ảnh: Paul Lynch / 500px.com.</em></p>\n<!-- /wp:paragraph -->', 'Cố đô Huế đẹp yên bình, hiền hoà qua ống kính người nước ngoài', '', 'publish', 'open', 'open', '', 'co-do-hue-dep-yen-binh-hien-hoa-qua-ong-kinh-nguoi-nuoc-ngoai', '', '', '2020-06-28 09:09:33', '2020-06-28 02:09:33', '', 0, 'http://localhost:8080/hotel01/?p=495', 0, 'post', '', 0),
(496, 1, '2020-06-28 09:09:03', '2020-06-28 02:09:03', '', 'huetourism_Co do Hue dep qua ong kinh nuoc ngoai 1', '', 'inherit', 'open', 'closed', '', 'huetourism_co-do-hue-dep-qua-ong-kinh-nuoc-ngoai-1', '', '', '2020-06-28 09:09:03', '2020-06-28 02:09:03', '', 495, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/huetourism_Co-do-Hue-dep-qua-ong-kinh-nuoc-ngoai-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(497, 1, '2020-06-28 09:09:31', '2020-06-28 02:09:31', '<!-- wp:paragraph -->\n<p>\n\nVới nét thâm trầm cổ kính đầy quyến rũ, Cố đô Huế đã chinh phục trái tim của nhiều du khách đến từ nước ngoài. Cùng xem loạt ảnh đẹp mê mẩn về xứ Huế do các nhiếp ảnh gia quốc tế thực hiện.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%201.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cảnh hoàng hôn huyền ảo trên sông Hương, dòng sông biểu tượng của Cố đô Huế. Ảnh: David Duffy / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%202.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cầu Trường Tiền lộng lẫy trong ráng chiều màu tím. Ảnh: David Duffy / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%203.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Cổng Hiển Nhơn của Hoàng thành Huế trong buổi chiều tà. Ảnh: Ravi Putcha / 500px.com.&nbsp;</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%204.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Quốc kỳ Việt Nam tung bay kiêu hãnh trên Kỳ đài Huế. Ảnh: Aitor Caminero / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%205.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Lầu tứ phương vô sự rực sáng anh đèn, soi bóng xuống mặt nước phẳng lặng của hào thành. Ảnh: Julia Elisabeth / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%206.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Những người dân chài Huế đánh lưới trên sông. Ảnh: Julia Elisabeth / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%207.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Trong lăng vua Minh Mạng. Ảnh: Olivier Sylvain / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%208.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Sắc màu rực rỡ tại Trường lang của Hoàng thành Huế. Ảnh: Olivier Sylvain / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%209.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Kiến trúc thanh thoát của lầu bát giác trước điện Kiến Trung ở Hoàng thành Huế. Ảnh: Paul Lynch / 500px.com.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"http://visithue.vn/Portals/0/AmazingHue/BestOfHue/2020/huetourism_Co%20do%20Hue%20dep%20qua%20ong%20kinh%20nuoc%20ngoai%2010.jpg\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p><em>Nét hoài cổ của tòa Minh Lâu trong lăng vua Minh Mạng. Ảnh: Paul Lynch / 500px.com.</em></p>\n<!-- /wp:paragraph -->', 'Cố đô Huế đẹp yên bình, hiền hoà qua ống kính người nước ngoài', '', 'inherit', 'closed', 'closed', '', '495-revision-v1', '', '', '2020-06-28 09:09:31', '2020-06-28 02:09:31', '', 495, 'http://localhost:8080/hotel01/495-revision-v1/', 0, 'revision', '', 0),
(498, 1, '2020-06-28 09:28:00', '2020-06-28 02:28:00', '<!-- wp:paragraph -->\n<p><strong><em>Ngoài những món đặc sản&nbsp;<a href=\"https://blog.traveloka.com/vn/resort-hue-ecolodge/\">Huế</a>&nbsp;nức tiếng như cơm hến, bún bò Huế, bánh bèo thì bạn còn hẳn một danh sách các món ngon nhất định phải thử khi đến Cố đô đấy.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>1. Cơm hến / Bún hến</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Một bát cơm huế đúng chuẩn “Huế” phải là cơm nguội để qua đêm, như vậy mới có thể giữ được cái giòn của rau và hương thơm của các gia vị. Đúng với tính cách “ăn cay nói nặng” của người Huế, món đặc sản Huế này phải đủ vị, mặn mà và đặc biệt là phải cay thật cay. Khi đến Huế, nếu bạn không dặn kỹ thì bát cơm hến của bạn đảm bảo sẽ khiến bạn bỏng lưỡi mà thôi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23871} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-1-com-hen.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23871\"/><figcaption>Không phải ai cũng có thể thưởng thức món cơm hến chuẩn đặc sản Huế do vị cay nồng của chúng. @wiktorkomorniczak</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Hiện nay, bạn có thể dễ dàng ăn cơm hến, bún hến ở mọi tỉnh thành nhưng nếu đã từng một lần thử cơm hến ở Huế, bạn sẽ phải thốt lên rằng “Đây mới là cơm hến đúng chuẩn!”. Cũng có lẽ vì cái cay, cái đậm đà hương vị đó mà món đặc sản Huế cơm hến này khiến người khác nhớ mãi không thôi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Cơm hến Đập Đá&nbsp;– 1 Hàn Mặc Tử, Vỹ Dạ.</em></li><li><em>Quán chị Nhỏ trong ngõ ngã tư Phạm Hồng Thái – Trương Định.</em></li><li><em>Quán ở số 2 Trương Định.</em></li><li><em>Quán Cháo – Bún – Cơm hến&nbsp;– 98 Nguyễn Huệ.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>2. Bún bò Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Khác với người miền Nam, nơi mà tô bún bò Huế có vị ngọt thanh dễ chịu từ xương, người Huế họ dùng xác ruốt để chắt lấy vị cho bát bún. Chính vì thế, bát bún bò Huế truyền thống muốn chuẩn vị là phải mặn nồng, đậm đà hơn nhiều. Một điểm khác biệt giữa bún bò ở Huế với ở những vùng miền khác chính là sợi bún. Với món này, người Huế đặc biệt dùng bún gạo sợi nhỏ, hay còn gọi là bún tươi, loại bún mà bạn thường ăn khi gỏi cuốn, hoặc bún riêu, bún măng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23872} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-2-bun-bo-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23872\"/><figcaption>Sợi bún bó Huế đúng gốc nhỏ hơn rất nhiều so với loại người miền Nam hay ăn. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23873} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-2-bun-bo-hue-2-e1523423838112.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23873\"/><figcaption>Người Huế chỉ thường ăn bún bò vào buổi sáng. @eat.travel.with.diep</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bạn muốn thưởng thức món đặc sản Huế này thì phải thật nhanh chân vì bún bò Huế chỉ được bán vào buổi sáng mà thôi. Mỗi sáng, chỉ cần bát bún bò đầy đủ thịt bò, giò heo, chả Huế, chả tôm là đã chứa đủ năng lượng cho một ngày làm việc rồi. Có lẽ một trong những thông tục ưa thích của người dân xứ Cố đô chính là chậm rãi thưởng thức một bát bún bò, nhấm nháp một tách trà và chia sẻ những câu chuyện với nhau.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bún bò Huế –&nbsp;14 Lý Thường Kiệt</em></li><li><em>Bún bà Tuyết&nbsp;–&nbsp;37 Nguyễn Công Trứ</em></li><li><em>Bún bà Tâm&nbsp;–&nbsp;43 Nguyễn Công Trứ</em></li><li><em>Bún bà Mỹ –&nbsp;71 Nguyễn Công Trứ</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>3. Mè xửng</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Mè xửng, hay còn gọi là kẹo mè xửng, là một trong những món ăn luôn xuất hiện trên bàn trà của người Huế. Người Huế xưa thường vừa uống trà, vừa nhâm nhi miếng mè xửng nhỏ, đây cũng là một trong những thú vui tao nhã. Thật ra, ở Huế không vội được đâu, ăn mè xửng cũng thế. Với món đặc sản Huế dinh dính này, bạn chỉ có thể được trong miệng mới có thể cảm nhận hết vị ngọt, cái dẻo và thơm mát mà chúng mang lại.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23874} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-3-keo-me-xung.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23874\"/><figcaption>Mè vừng là thức quà bánh thường được du khách mua về làm quà. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Do nhu cầu của du khách tăng cao, bạn có thể bắt gặp nhiều loại mè xửng như mè dẻo, mè giòn, mè đen, mè gương. Mỗi loại lại có cái ngon và sự thú vị riêng, tuy nhiên bạn cũng cần cẩn thận khi mua mè xửng về làm quà. Khi mua mè xửng, bạn nên kiểm tra màu sắc và độ dẻo của chúng. Nếu mè xửng có màu vàng trong, khi bóp hoặc bẻ thấy mềm nhẹ nhưng không gãy, thả tay ra lại trở về hình dạng cũ là mè xửng loại tốt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Bạn có thể thưởng thức mè xửng ngon và mua về làm quà tại:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Mè xửng Thiên Hương&nbsp;– 20 Chi Lăng.</em></li><li><em>Mè xửng Nam Thuận – 135 Huỳnh Thúc Kháng.</em></li><li><em>Chợ Đông Ba&nbsp;–&nbsp;Trần Hưng Đạo, Phú Hòa.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>4. Chè Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Quả không ngoa khi gọi Huế là kinh đô của các loại chè và chè hẻm là một trong những đặc trưng của xứ Huế. Cứ đi chừng vài bước, bạn sẽ lại bắt gặp một tiệm hoặc gánh chè rong trong hẻm. Chính vì thế, chè trở thành một món đặc sản Huế không thể thiếu trong danh sách những món cần thử của bạn được.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23876} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-4-che-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23876\"/><figcaption>Những nồi chè đầy sắc màu. @chutrieulong</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23877} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-4-che-hue-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23877\"/><figcaption>Chè Hẻm – Số 1 Kiệt 29 Hùng Vương. @linhgumiho</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Những món chè ngon và lạ được bán quanh năm suốt tháng có thể kể đến như chè bột lọc thịt quay, chè chuối khoai môn, chè đậu ngự, chè ngô, chè hạt sen… Vào những ngày oi bức mà được thử một bát chè với đá thì mát lạnh không gì sánh được. Mỗi loại chè có một hương vị đặc biệt riêng nên nếu có thời gian thì bạn nhất định phải thử hết nhé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Chè Hẻm – 17 Hùng Vương.</em></li><li><em>Chè Sao –&nbsp;60 Phan Chu Trinh.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>5. Nem lụi Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Người ta thường kháo nhau rằng nem lụi là một trong những điều tuyệt vời về ẩm thực Huế. Món ăn được chế biến dân dã và đơn giản, nhưng nhờ vào sự thích đậm đà, nhiều hương vị của người Huế mà món đặc sản Huế này có hương thơm có thể khiến lòng thực khách xuyến xao.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23897} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-nem-lui-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23897\"/><figcaption>Nem lụi là một trong những món ăn “đặc sệt” Huế. @bachuaviahe</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nem lụi Huế thường được ăn kèm với rau sống, thơm, khế, giá, ớt như cuộn thịt của người miền Nam. Điều khác biệt ở món ăn này chính là món nước chấm đặc biệt có tên gọi là “nước lèo”. Đảm bảo bạn ăn một lần là sẽ “thèm thuồng” mãi đến ngày về khi thử qua nem lụi Huế tại các địa chỉ sau:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bún Thịt Nướng &amp; Nem Lụi Bà Tý&nbsp;– 81 Đào Duy Từ.</em></li><li><em>Tài Phú&nbsp;–&nbsp;2 Điện Biên Phủ, P. Vĩnh Ninh.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>6. Tré Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Thoạt nhìn, nhiều du khách sẽ dễ bị nhầm lẫn giữa tré Huế và nem chả Huế vì thật chất hai món đặc sản Huế này có “họ hàng” với nhau, tuy nhiên, cách làm của chúng lại khác nhau nên bạn cần hỏi kỹ trước khi mua nhé. Vị của tré thơm mùi thính, vị ngọt đậm, hơi chua. Tré Huế có hai loại là tré heo và tré bò.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23879} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-6-tre-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23879\"/><figcaption>Tré Huế khi được gói vào trong lá thì thật khó phân biệt với nem chả. @o0o.bichngoc.o0o</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tuy nhiên, món tré Huế không có một cách làm cụ thể nào cả nên mùi vị, màu sắc cũng đa dạng tùy vào sở thích của người làm. Trên bàn ăn của gia đình người Huế, tré là một món khai vị hoặc nhấm với rượu không thể thiếu. Nem và tré Huế phải mua ở phố Đào Duy Từ mới đúng chuẩn vì phố Đào Duy Từ&nbsp;chuyên sản xuất và bán nem chả tré từ xưa đến nay ở Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Nem Chả Tré Đông Ba Huế&nbsp;–&nbsp;25 Đào Duy Từ, Phú Bình.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>7. Bánh canh Nam Phổ</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh canh Nam Phổ xuất phát từ làng… Nam Phổ. Đây là món hàng rong phổ biến tại làng này, một nơi cách trung tâm thành phố khoảng 10 km. Bạn sẽ thấy nước bánh có hơi đục và kẹo do bánh canh Nam Phổ được nấu từ bột gạo và bột lọc theo tỉ lệ 3 gạo – 1 lọc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23880} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-7-banh-canh-nam-pho.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23880\"/><figcaption>Món bánh canh nổi tiếng ở Huế. @trungbuii</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23881} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-7-banh-canh-nam-pho-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23881\"/><figcaption>Không cần phải đi đến làng Nam Phổ mới ăn được món đặc sản Huế này, ngay trong trung tâm thành phố Huế cũng có rất nhiều nơi bán. @danangcuisine</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nước dùng bánh canh còn có thịt ba chỉ và tôm. Khi ăn, bạn nhớ thêm chút ớt tăng độ cay để cảm nhận trọn vẹn cái ngon đúng chất Huế. Bánh canh Nam Phổ là món đặc sản Huế ưa thích của nhiều khách du lịch và cả người dân địa phương. Cứ mỗi buổi chiều, song song với các gánh chè rong chính là sự hiện diện của những gánh bánh canh Nam Phổ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán Thúy chuyên bánh Canh Nam Phổ&nbsp;– 16 Phạm Hồng Thái.</em></li><li><em>Bánh canh Nam Phổ – 374 Chi Lăng.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:image {\"id\":36810,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"https://www.traveloka.com/vi-vn/flight?utm_source=blog.traveloka.com&amp;utm_medium=referral&amp;utm_campaign=VN-FL-OM-Button-FLCTA-AVC2018080167-ContentMiddle\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2017/08/timvemaybayngay-300x55.png\" alt=\"\" class=\"wp-image-36810\"/></a></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ôi thèm quá đi mất, tìm vé máy bay rẻ đến Huế ngay thôi!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>8. Tôm chua Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Tôm chua là một món đặc sản Huế bình dị mà bạn khó có thể thấy ở những tỉnh thành khác. Bản thân tôm đã có vị thanh mát, ngọt dịu nay được pha với cay nồng từ các loại gia vị chẳng những không át được vị mát lành vốn có của tôm mà còn thật hài hòa và quyến rũ khi ăn cùng với các món ăn kèm khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23882} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-8-tom-chua-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23882\"/><figcaption>Vị chua chua cay cay của món tôm chua đảm bảo sẽ khiến bạn nhớ mãi không quên. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nếu để ý kỹ bạn sẽ thấy đây là một món đặc sản Huế đại diện cho nét tính cách cầu kỳ và tỉ mẫn của người dân nơi đây. Khi chế biến, họ đặc biệt không sử dụng loại tôm biển to mà chỉ chọn tôm nước ngọt, tôm sông, tôm đất nhỏ. Lý do là vì tôm nhỏ thì dễ thấm đều gia vị hơn và khi bày biện lên dĩa, chén hay xếp trong hũ trông cũng đẹp mắt hơn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Tôm chua Huế thường được ăn kèm như gỏi cuốn với thịt luộc, bánh tráng cùng các loại rau sống. Ngoài ra, nếu bạn không có nhiều thời gian để cuốn bánh tráng, bạn cũng có thể ăn tôm chua với cơm nóng. Món tôm chua ngon nhất là phải được mua ở đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Tôm chua 21 Đặng Trần Côn.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>9. Vả trộn</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế, khi có ai rủ bạn ăn “vả” tức là họ muốn bạn ăn chơi, ăn cho vui miệng. Có lẽ vì thế mà trái vả ở Huế thường để dùng làm món ăn chơi, khai vị. Đã đến đây thì bạn nhất định phải ăn thử trái vả vì đây mới đúng là đặc sản Huế, chỉ Huế mới có vả mà thôi, đảm bảo không đụng hàng với bất kỳ xứ nào khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23883} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-9-va-tron.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23883\"/><figcaption>Trái vả chỉ có ở Huế. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23884} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-9-va-tron-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23884\"/><figcaption>Vả trộn thường được ăn chung với bánh tráng nướng. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một sự thật thú vị rằng khi đi ăn ở Huế, từ nhà hàng cho đến quán bình dân, bạn sẽ dễ dàng bắt gặp món vả trộn trong thực đơn chứng tỏ được độ yêu thích của người dân nơi đây dành cho loại trái này. Bánh tráng nướng là “cặp bài trùng” với vả trộn. Xúc miếng vả trộn bằng bánh tráng, bỏ vào miệng thì mới đúng là cách ăn của người Huế. Vả trộn là một món ăn phổ biến, bạn có thể dễ dàng tìm thấy món ăn này ở bất kỳ hàng quán nào ở Huế, nhất là những quán “nhậu” bình dân tại đây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>10. Kẹo cau</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Tên gọi “kẹo cau” xuất phát từ hình dáng giống trái cau của loại kẹo này, trông giống một quả cau được bổ ra. Đây là một thức quà vặt mà trẻ con rất thích, gồm có phần nước đường bên trong màu vàng nhạt đã khô lại, tượng trưng cho hạt cau, còn phần ngoài màu trắng, là thịt cau, làm bằng bột trộn đường.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23885} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-10-keo-cau.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23885\"/><figcaption>Kẹo cau (trái) là món ăn vặt gắn liền với tuổi thơ của nhiều người dân địa phương. @hanhle87</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Món đặc sản Huế này đã xuất hiện từ khá lâu. Ban đầu, kẹo để nguyên viên tròn, thường được gói trong lá chuối khô nhưng ngày nay, kẹo được bổ ra và gói trong giấy bóng kiếng sạch sẽ. Bạn dễ dàng mua kẹo cau ở các khu chợ lớn nhỏ, các quầy tạp hóa, hoặc ngay tại các điểm tham quan.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>11. Bánh bèo</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nhắc đến Cố đô và những món đặc sản Huế thì làm sao có thể bỏ qua vô vàn các loại “bánh” nơi đây, từ ngọt đến mặn, Huế đúng là thiên đường của bánh. Mở đầu danh sách này nhất định phải kể đến món bánh bèo trứ danh.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23886} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-11-banh-beo.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23886\"/><figcaption>Đến Huế mà không ăn bánh bèo Huế thì “phí” cả chuyến đi. @yensplate</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Thưởng thức bánh bèo Huế đúng nghĩa phải là bánh được làm trong từng chén nhỏ và sắp lên cái mẹt tre. Trên mặt những chiếc bánh trắng muốt ấy là màu cam đỏ của tôm chấy, màu vàng của hành phi và tóp mỡ cùng màu xanh của mỡ hành. Chan chút nước mắm ớt lên trên trước khi ăn, bạn sẽ cảm thấy như tất cả tinh hoa đất trời đều tụ lại trong chén bánh bèo Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23887} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-11-banh-beo-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23887\"/><figcaption>Nước mắm ngọt phải có ớt cay mới làm bật được vị ngon của bánh bèo Huế. @im.pubu</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế có hai địa điểm bánh bèo gánh thu hút khách du lịch nhiều nhất là bánh bèo gánh Nam Phổ và Đốc Sơ. Bên cạnh đó, còn có những tiệm, quán bán bánh bèo lâu đời như bánh bèo Ngự Bình và Tây Thượng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Khu phố Bánh bèo: cung An Định, đường Ngự Bình, đường Nguyễn Bỉnh Khiêm,…</em></li><li><em>Khu Ẩm Thực Chợ Tây Lộc –&nbsp;209 Nguyễn Trãi.</em></li><li><em>Bánh bèo Bà Cư &nbsp;– 47 Nguyễn Huệ.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>12. Bánh bột lọc</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh bột lọc Huế được chia làm hai loại là bánh gói (bánh được gói trong lá chuối hoặc lá dong) và bánh trần (không gói lá), nhưng loại nào cũng đều hấp dẫn thực khách nhờ phần bột chín trong suốt để lộ ra phần tôm đỏ gạch đẹp mắt và ngon miệng. Nhân bánh thường là tôm, thịt ba chỉ thái nhỏ, cũng có nơi để nguyên con tôm nhỏ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23888} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-12-banh-bot-loc.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23888\"/><figcaption>Bánh bột lọc là món đặc sản Huế vừa ngon mắt, vừa là món ăn dễ dàng check-in ra những tấm ảnh đẹp do sự hài hòa về màu sắc. @cooky.vn</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Cũng giống như các món bánh đặc sản Huế khác, bánh bột lọc chỉ ăn với mắm ngọt cay, không cần ăn kèm rau sống. Bạn có thể thưởng thức bánh lột bọc ngon chuẩn vị Huế tại các địa chỉ sau đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán 109 chuyên Bèo – Nậm – Lọc –&nbsp;109 Lê Huân.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>13. Bánh nậm</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh nậm cũng là một trong những món ăn vặt yêu thích của người dân nơi đây, xuất hiện nhiều trên các gánh hàng rong ở khắp thành phố Huế. Chiếc bánh nậm hình chữ nhật, được bọc trong lá dong, với lớp bột trắng ngần điểm xuyến màu tôm hồng bắt mắt. Một bát bánh nậm thường sẽ có thêm chả tôm, chan nước mắm ngọt để làm đậm thêm vị bánh.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23889} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-13-banh-nam.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23889\"/><figcaption>Giống như các loại bánh khác ở đây, bánh nậm được ăn kèm với nước mắm ngọt hơi cay. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:list -->\n<ul><li><em>Bánh nậm bà Đỏ –&nbsp;71 Nguyễn Bỉnh Khiêm, Phú Cát.</em></li><li><em>Quán Hàng Me –&nbsp;14 Võ Thị Sáu, Phú Hội.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>14. Bánh khoái</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nếu lần đầu đến Huế, bạn sẽ dễ dàng nhầm bánh khoái thành bánh xèo vì hình thức bên ngoài của hai món này có nhiều nét tương đồng. Nếu nhìn kỹ bạn sẽ thấy lớp vỏ bột của bánh khoái nhỏ, dày và giòn hơn bánh xèo. Đó là về bề ngoài, khi ăn vào, vị của hai món ăn cũng khác biệt, chủ yếu là do chén nước chấm ăn kèm làm nên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23890} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-14-banh-khoai.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23890\"/><figcaption>Bánh khoái và bánh xèo thật ra có nhiều sự khác biệt trong cả cách ăn và cách làm. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nước chấm của bánh khoái được gọi là “nước lèo”. Nước lèo của món đặc sản Huế bánh khoái được làm từ gan heo, thịt nạc băm nhuyễn, mè rang, đậu phộng giã nhuyễn cùng nước tương đậu nành Huế chính gốc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bánh khoái Lạc Thiện&nbsp;–&nbsp;6 Đinh Tiên Hoàng.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>15. Bánh ram ít</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nếu xét trong các món bánh mặn thì bánh ram ít có phần kỳ công hơn cả từ hình dáng, cách phối màu cho đến cách làm. Sự kỳ công này đến từ việc bánh ram ít, trước khi trở thành món đặc sản Huế dễ dàng ăn thử ở bất kỳ nơi đâu như ngày nay, đã từng là món ăn được các triều Vua nhà Nguyễn ưa thích.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23891} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-15-banh-ram-it.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23891\"/><figcaption>Hẳn đây là một món bánh rất lạ đối với nhiều thực khách. @yensplate</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23892} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-15-banh-ram-it-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23892\"/><figcaption>Bánh ram ít trông vô cùng hấp dẫn đúng không nào. @maysul_seulgi</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tên gọi “bánh ram ít” là sự kết hợp của hai bánh: bánh ram và bánh ít. Phần viên bánh tròn màu trắng ở trên là bánh ít, phần bánh chiên ở dưới là bánh ram. Khi ăn bánh cũng là một trải nghiệm rất độc đáo. Khi cắn, đầu tiên ta cảm nhận được cái dẻo của bột nếp, sau đó là phần nhân tôm thịt đậm đà trong bánh rồi cuối cùng là cái giòn rụm của bánh ram. Vừa ngon mắt vừa ngon miệng, bánh ram ít là món ăn ưa thích của nhiều thực khách khi đến Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán Hàng Me –&nbsp;14 Võ Thị Sáu, Phú Hội.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>16. Bánh đậu xanh trái cây</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh đậu xanh trái cây còn được biết đến là món bánh “quý tộc” vì ngày xưa, bánh đậu xanh trái cây chỉ được thực hiện bởi những đầu bếp, thợ làm bánh nổi tiếng để dâng lên triều đình. Chính vì thế, món bánh đòi hỏi cao sự khéo tay và cẩn thận ở người làm.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23870} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-1-banh-dau-xanh-trai-cay.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23870\"/><figcaption>Bánh đậu xanh trái cây từng là món bánh quý tộc, chỉ dành để dâng vua chúa. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bột bánh “quý tộc” được làm từ đậu xanh, thạch và màu thực phẩm. Sau khi trộn bột, người thợ phải dùng tay nặn ra hình dáng các loại củ, trái cây phổ biến như cam, mận, táo, ớt,… Cách thưởng thức bánh đậu xanh trái cây đúng Huế phải vừa uống trà, vừa ăn bánh và hàn huyên, tâm sự. Cách ăn chậm rãi và từ tốn này thích hợp với các gia đình vương giả thời xưa hoặc người lớn tuổi.&nbsp;Muốn thưởng thức&nbsp;và mua về làm quà cho người thân món bánh trái cây này, bạn có thể ghé các địa chỉ sau đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Chợ Đông Ba – Trần Hưng Đạo, Phú Hòa.</em></li><li><em>Vọng Lục Bộ&nbsp;– 79 Nguyễn Chí Diểu, Thuận Thành.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Ngày nay, thật không khó để bạn có thể thử các món ăn Huế ở bất kỳ tỉnh thành nào bạn đến, nhưng sẽ thật lãng phí nếu đã đến Huế mà lại chưa thử đúng đặc sản Huế. Đậm đà và đủ hương – sắc – vị là những gì bạn sẽ nhớ về ẩm thực nơi đây.</p>\n<!-- /wp:paragraph -->', 'Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế', '', 'publish', 'open', 'open', '', 'chua-thu-16-mon-dac-san-hue-nay-ban-chua-den-hue', '', '', '2020-06-28 09:28:03', '2020-06-28 02:28:03', '', 0, 'http://localhost:8080/hotel01/?p=498', 0, 'post', '', 0),
(499, 1, '2020-06-28 09:27:50', '2020-06-28 02:27:50', '', 'dac-san-hue-2-bun-bo-hue', '', 'inherit', 'open', 'closed', '', 'dac-san-hue-2-bun-bo-hue', '', '', '2020-06-28 09:27:50', '2020-06-28 02:27:50', '', 498, 'http://localhost:8080/hotel01/wp-content/uploads/2020/06/dac-san-hue-2-bun-bo-hue.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(500, 1, '2020-06-28 09:28:00', '2020-06-28 02:28:00', '<!-- wp:paragraph -->\n<p><strong><em>Ngoài những món đặc sản&nbsp;<a href=\"https://blog.traveloka.com/vn/resort-hue-ecolodge/\">Huế</a>&nbsp;nức tiếng như cơm hến, bún bò Huế, bánh bèo thì bạn còn hẳn một danh sách các món ngon nhất định phải thử khi đến Cố đô đấy.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>1. Cơm hến / Bún hến</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Một bát cơm huế đúng chuẩn “Huế” phải là cơm nguội để qua đêm, như vậy mới có thể giữ được cái giòn của rau và hương thơm của các gia vị. Đúng với tính cách “ăn cay nói nặng” của người Huế, món đặc sản Huế này phải đủ vị, mặn mà và đặc biệt là phải cay thật cay. Khi đến Huế, nếu bạn không dặn kỹ thì bát cơm hến của bạn đảm bảo sẽ khiến bạn bỏng lưỡi mà thôi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23871} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-1-com-hen.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23871\"/><figcaption>Không phải ai cũng có thể thưởng thức món cơm hến chuẩn đặc sản Huế do vị cay nồng của chúng. @wiktorkomorniczak</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Hiện nay, bạn có thể dễ dàng ăn cơm hến, bún hến ở mọi tỉnh thành nhưng nếu đã từng một lần thử cơm hến ở Huế, bạn sẽ phải thốt lên rằng “Đây mới là cơm hến đúng chuẩn!”. Cũng có lẽ vì cái cay, cái đậm đà hương vị đó mà món đặc sản Huế cơm hến này khiến người khác nhớ mãi không thôi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Cơm hến Đập Đá&nbsp;– 1 Hàn Mặc Tử, Vỹ Dạ.</em></li><li><em>Quán chị Nhỏ trong ngõ ngã tư Phạm Hồng Thái – Trương Định.</em></li><li><em>Quán ở số 2 Trương Định.</em></li><li><em>Quán Cháo – Bún – Cơm hến&nbsp;– 98 Nguyễn Huệ.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>2. Bún bò Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Khác với người miền Nam, nơi mà tô bún bò Huế có vị ngọt thanh dễ chịu từ xương, người Huế họ dùng xác ruốt để chắt lấy vị cho bát bún. Chính vì thế, bát bún bò Huế truyền thống muốn chuẩn vị là phải mặn nồng, đậm đà hơn nhiều. Một điểm khác biệt giữa bún bò ở Huế với ở những vùng miền khác chính là sợi bún. Với món này, người Huế đặc biệt dùng bún gạo sợi nhỏ, hay còn gọi là bún tươi, loại bún mà bạn thường ăn khi gỏi cuốn, hoặc bún riêu, bún măng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23872} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-2-bun-bo-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23872\"/><figcaption>Sợi bún bó Huế đúng gốc nhỏ hơn rất nhiều so với loại người miền Nam hay ăn. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23873} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-2-bun-bo-hue-2-e1523423838112.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23873\"/><figcaption>Người Huế chỉ thường ăn bún bò vào buổi sáng. @eat.travel.with.diep</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bạn muốn thưởng thức món đặc sản Huế này thì phải thật nhanh chân vì bún bò Huế chỉ được bán vào buổi sáng mà thôi. Mỗi sáng, chỉ cần bát bún bò đầy đủ thịt bò, giò heo, chả Huế, chả tôm là đã chứa đủ năng lượng cho một ngày làm việc rồi. Có lẽ một trong những thông tục ưa thích của người dân xứ Cố đô chính là chậm rãi thưởng thức một bát bún bò, nhấm nháp một tách trà và chia sẻ những câu chuyện với nhau.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bún bò Huế –&nbsp;14 Lý Thường Kiệt</em></li><li><em>Bún bà Tuyết&nbsp;–&nbsp;37 Nguyễn Công Trứ</em></li><li><em>Bún bà Tâm&nbsp;–&nbsp;43 Nguyễn Công Trứ</em></li><li><em>Bún bà Mỹ –&nbsp;71 Nguyễn Công Trứ</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>3. Mè xửng</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Mè xửng, hay còn gọi là kẹo mè xửng, là một trong những món ăn luôn xuất hiện trên bàn trà của người Huế. Người Huế xưa thường vừa uống trà, vừa nhâm nhi miếng mè xửng nhỏ, đây cũng là một trong những thú vui tao nhã. Thật ra, ở Huế không vội được đâu, ăn mè xửng cũng thế. Với món đặc sản Huế dinh dính này, bạn chỉ có thể được trong miệng mới có thể cảm nhận hết vị ngọt, cái dẻo và thơm mát mà chúng mang lại.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23874} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-3-keo-me-xung.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23874\"/><figcaption>Mè vừng là thức quà bánh thường được du khách mua về làm quà. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Do nhu cầu của du khách tăng cao, bạn có thể bắt gặp nhiều loại mè xửng như mè dẻo, mè giòn, mè đen, mè gương. Mỗi loại lại có cái ngon và sự thú vị riêng, tuy nhiên bạn cũng cần cẩn thận khi mua mè xửng về làm quà. Khi mua mè xửng, bạn nên kiểm tra màu sắc và độ dẻo của chúng. Nếu mè xửng có màu vàng trong, khi bóp hoặc bẻ thấy mềm nhẹ nhưng không gãy, thả tay ra lại trở về hình dạng cũ là mè xửng loại tốt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Bạn có thể thưởng thức mè xửng ngon và mua về làm quà tại:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Mè xửng Thiên Hương&nbsp;– 20 Chi Lăng.</em></li><li><em>Mè xửng Nam Thuận – 135 Huỳnh Thúc Kháng.</em></li><li><em>Chợ Đông Ba&nbsp;–&nbsp;Trần Hưng Đạo, Phú Hòa.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>4. Chè Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Quả không ngoa khi gọi Huế là kinh đô của các loại chè và chè hẻm là một trong những đặc trưng của xứ Huế. Cứ đi chừng vài bước, bạn sẽ lại bắt gặp một tiệm hoặc gánh chè rong trong hẻm. Chính vì thế, chè trở thành một món đặc sản Huế không thể thiếu trong danh sách những món cần thử của bạn được.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23876} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-4-che-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23876\"/><figcaption>Những nồi chè đầy sắc màu. @chutrieulong</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23877} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-4-che-hue-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23877\"/><figcaption>Chè Hẻm – Số 1 Kiệt 29 Hùng Vương. @linhgumiho</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Những món chè ngon và lạ được bán quanh năm suốt tháng có thể kể đến như chè bột lọc thịt quay, chè chuối khoai môn, chè đậu ngự, chè ngô, chè hạt sen… Vào những ngày oi bức mà được thử một bát chè với đá thì mát lạnh không gì sánh được. Mỗi loại chè có một hương vị đặc biệt riêng nên nếu có thời gian thì bạn nhất định phải thử hết nhé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Chè Hẻm – 17 Hùng Vương.</em></li><li><em>Chè Sao –&nbsp;60 Phan Chu Trinh.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>5. Nem lụi Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Người ta thường kháo nhau rằng nem lụi là một trong những điều tuyệt vời về ẩm thực Huế. Món ăn được chế biến dân dã và đơn giản, nhưng nhờ vào sự thích đậm đà, nhiều hương vị của người Huế mà món đặc sản Huế này có hương thơm có thể khiến lòng thực khách xuyến xao.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23897} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-nem-lui-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23897\"/><figcaption>Nem lụi là một trong những món ăn “đặc sệt” Huế. @bachuaviahe</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nem lụi Huế thường được ăn kèm với rau sống, thơm, khế, giá, ớt như cuộn thịt của người miền Nam. Điều khác biệt ở món ăn này chính là món nước chấm đặc biệt có tên gọi là “nước lèo”. Đảm bảo bạn ăn một lần là sẽ “thèm thuồng” mãi đến ngày về khi thử qua nem lụi Huế tại các địa chỉ sau:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bún Thịt Nướng &amp; Nem Lụi Bà Tý&nbsp;– 81 Đào Duy Từ.</em></li><li><em>Tài Phú&nbsp;–&nbsp;2 Điện Biên Phủ, P. Vĩnh Ninh.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>6. Tré Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Thoạt nhìn, nhiều du khách sẽ dễ bị nhầm lẫn giữa tré Huế và nem chả Huế vì thật chất hai món đặc sản Huế này có “họ hàng” với nhau, tuy nhiên, cách làm của chúng lại khác nhau nên bạn cần hỏi kỹ trước khi mua nhé. Vị của tré thơm mùi thính, vị ngọt đậm, hơi chua. Tré Huế có hai loại là tré heo và tré bò.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23879} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-6-tre-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23879\"/><figcaption>Tré Huế khi được gói vào trong lá thì thật khó phân biệt với nem chả. @o0o.bichngoc.o0o</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tuy nhiên, món tré Huế không có một cách làm cụ thể nào cả nên mùi vị, màu sắc cũng đa dạng tùy vào sở thích của người làm. Trên bàn ăn của gia đình người Huế, tré là một món khai vị hoặc nhấm với rượu không thể thiếu. Nem và tré Huế phải mua ở phố Đào Duy Từ mới đúng chuẩn vì phố Đào Duy Từ&nbsp;chuyên sản xuất và bán nem chả tré từ xưa đến nay ở Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Nem Chả Tré Đông Ba Huế&nbsp;–&nbsp;25 Đào Duy Từ, Phú Bình.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>7. Bánh canh Nam Phổ</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh canh Nam Phổ xuất phát từ làng… Nam Phổ. Đây là món hàng rong phổ biến tại làng này, một nơi cách trung tâm thành phố khoảng 10 km. Bạn sẽ thấy nước bánh có hơi đục và kẹo do bánh canh Nam Phổ được nấu từ bột gạo và bột lọc theo tỉ lệ 3 gạo – 1 lọc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23880} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-7-banh-canh-nam-pho.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23880\"/><figcaption>Món bánh canh nổi tiếng ở Huế. @trungbuii</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23881} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-7-banh-canh-nam-pho-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23881\"/><figcaption>Không cần phải đi đến làng Nam Phổ mới ăn được món đặc sản Huế này, ngay trong trung tâm thành phố Huế cũng có rất nhiều nơi bán. @danangcuisine</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nước dùng bánh canh còn có thịt ba chỉ và tôm. Khi ăn, bạn nhớ thêm chút ớt tăng độ cay để cảm nhận trọn vẹn cái ngon đúng chất Huế. Bánh canh Nam Phổ là món đặc sản Huế ưa thích của nhiều khách du lịch và cả người dân địa phương. Cứ mỗi buổi chiều, song song với các gánh chè rong chính là sự hiện diện của những gánh bánh canh Nam Phổ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán Thúy chuyên bánh Canh Nam Phổ&nbsp;– 16 Phạm Hồng Thái.</em></li><li><em>Bánh canh Nam Phổ – 374 Chi Lăng.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:image {\"id\":36810,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"https://www.traveloka.com/vi-vn/flight?utm_source=blog.traveloka.com&amp;utm_medium=referral&amp;utm_campaign=VN-FL-OM-Button-FLCTA-AVC2018080167-ContentMiddle\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2017/08/timvemaybayngay-300x55.png\" alt=\"\" class=\"wp-image-36810\"/></a></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ôi thèm quá đi mất, tìm vé máy bay rẻ đến Huế ngay thôi!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>8. Tôm chua Huế</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Tôm chua là một món đặc sản Huế bình dị mà bạn khó có thể thấy ở những tỉnh thành khác. Bản thân tôm đã có vị thanh mát, ngọt dịu nay được pha với cay nồng từ các loại gia vị chẳng những không át được vị mát lành vốn có của tôm mà còn thật hài hòa và quyến rũ khi ăn cùng với các món ăn kèm khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23882} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-8-tom-chua-hue.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23882\"/><figcaption>Vị chua chua cay cay của món tôm chua đảm bảo sẽ khiến bạn nhớ mãi không quên. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nếu để ý kỹ bạn sẽ thấy đây là một món đặc sản Huế đại diện cho nét tính cách cầu kỳ và tỉ mẫn của người dân nơi đây. Khi chế biến, họ đặc biệt không sử dụng loại tôm biển to mà chỉ chọn tôm nước ngọt, tôm sông, tôm đất nhỏ. Lý do là vì tôm nhỏ thì dễ thấm đều gia vị hơn và khi bày biện lên dĩa, chén hay xếp trong hũ trông cũng đẹp mắt hơn.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Tôm chua Huế thường được ăn kèm như gỏi cuốn với thịt luộc, bánh tráng cùng các loại rau sống. Ngoài ra, nếu bạn không có nhiều thời gian để cuốn bánh tráng, bạn cũng có thể ăn tôm chua với cơm nóng. Món tôm chua ngon nhất là phải được mua ở đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Tôm chua 21 Đặng Trần Côn.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>9. Vả trộn</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế, khi có ai rủ bạn ăn “vả” tức là họ muốn bạn ăn chơi, ăn cho vui miệng. Có lẽ vì thế mà trái vả ở Huế thường để dùng làm món ăn chơi, khai vị. Đã đến đây thì bạn nhất định phải ăn thử trái vả vì đây mới đúng là đặc sản Huế, chỉ Huế mới có vả mà thôi, đảm bảo không đụng hàng với bất kỳ xứ nào khác.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23883} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-9-va-tron.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23883\"/><figcaption>Trái vả chỉ có ở Huế. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23884} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-9-va-tron-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23884\"/><figcaption>Vả trộn thường được ăn chung với bánh tráng nướng. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Một sự thật thú vị rằng khi đi ăn ở Huế, từ nhà hàng cho đến quán bình dân, bạn sẽ dễ dàng bắt gặp món vả trộn trong thực đơn chứng tỏ được độ yêu thích của người dân nơi đây dành cho loại trái này. Bánh tráng nướng là “cặp bài trùng” với vả trộn. Xúc miếng vả trộn bằng bánh tráng, bỏ vào miệng thì mới đúng là cách ăn của người Huế. Vả trộn là một món ăn phổ biến, bạn có thể dễ dàng tìm thấy món ăn này ở bất kỳ hàng quán nào ở Huế, nhất là những quán “nhậu” bình dân tại đây.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>10. Kẹo cau</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Tên gọi “kẹo cau” xuất phát từ hình dáng giống trái cau của loại kẹo này, trông giống một quả cau được bổ ra. Đây là một thức quà vặt mà trẻ con rất thích, gồm có phần nước đường bên trong màu vàng nhạt đã khô lại, tượng trưng cho hạt cau, còn phần ngoài màu trắng, là thịt cau, làm bằng bột trộn đường.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23885} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-10-keo-cau.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23885\"/><figcaption>Kẹo cau (trái) là món ăn vặt gắn liền với tuổi thơ của nhiều người dân địa phương. @hanhle87</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Món đặc sản Huế này đã xuất hiện từ khá lâu. Ban đầu, kẹo để nguyên viên tròn, thường được gói trong lá chuối khô nhưng ngày nay, kẹo được bổ ra và gói trong giấy bóng kiếng sạch sẽ. Bạn dễ dàng mua kẹo cau ở các khu chợ lớn nhỏ, các quầy tạp hóa, hoặc ngay tại các điểm tham quan.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>11. Bánh bèo</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nhắc đến Cố đô và những món đặc sản Huế thì làm sao có thể bỏ qua vô vàn các loại “bánh” nơi đây, từ ngọt đến mặn, Huế đúng là thiên đường của bánh. Mở đầu danh sách này nhất định phải kể đến món bánh bèo trứ danh.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23886} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-11-banh-beo.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23886\"/><figcaption>Đến Huế mà không ăn bánh bèo Huế thì “phí” cả chuyến đi. @yensplate</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Thưởng thức bánh bèo Huế đúng nghĩa phải là bánh được làm trong từng chén nhỏ và sắp lên cái mẹt tre. Trên mặt những chiếc bánh trắng muốt ấy là màu cam đỏ của tôm chấy, màu vàng của hành phi và tóp mỡ cùng màu xanh của mỡ hành. Chan chút nước mắm ớt lên trên trước khi ăn, bạn sẽ cảm thấy như tất cả tinh hoa đất trời đều tụ lại trong chén bánh bèo Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23887} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-11-banh-beo-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23887\"/><figcaption>Nước mắm ngọt phải có ớt cay mới làm bật được vị ngon của bánh bèo Huế. @im.pubu</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Ở Huế có hai địa điểm bánh bèo gánh thu hút khách du lịch nhiều nhất là bánh bèo gánh Nam Phổ và Đốc Sơ. Bên cạnh đó, còn có những tiệm, quán bán bánh bèo lâu đời như bánh bèo Ngự Bình và Tây Thượng.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Khu phố Bánh bèo: cung An Định, đường Ngự Bình, đường Nguyễn Bỉnh Khiêm,…</em></li><li><em>Khu Ẩm Thực Chợ Tây Lộc –&nbsp;209 Nguyễn Trãi.</em></li><li><em>Bánh bèo Bà Cư &nbsp;– 47 Nguyễn Huệ.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>12. Bánh bột lọc</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh bột lọc Huế được chia làm hai loại là bánh gói (bánh được gói trong lá chuối hoặc lá dong) và bánh trần (không gói lá), nhưng loại nào cũng đều hấp dẫn thực khách nhờ phần bột chín trong suốt để lộ ra phần tôm đỏ gạch đẹp mắt và ngon miệng. Nhân bánh thường là tôm, thịt ba chỉ thái nhỏ, cũng có nơi để nguyên con tôm nhỏ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23888} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-12-banh-bot-loc.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23888\"/><figcaption>Bánh bột lọc là món đặc sản Huế vừa ngon mắt, vừa là món ăn dễ dàng check-in ra những tấm ảnh đẹp do sự hài hòa về màu sắc. @cooky.vn</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Cũng giống như các món bánh đặc sản Huế khác, bánh bột lọc chỉ ăn với mắm ngọt cay, không cần ăn kèm rau sống. Bạn có thể thưởng thức bánh lột bọc ngon chuẩn vị Huế tại các địa chỉ sau đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán 109 chuyên Bèo – Nậm – Lọc –&nbsp;109 Lê Huân.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>13. Bánh nậm</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh nậm cũng là một trong những món ăn vặt yêu thích của người dân nơi đây, xuất hiện nhiều trên các gánh hàng rong ở khắp thành phố Huế. Chiếc bánh nậm hình chữ nhật, được bọc trong lá dong, với lớp bột trắng ngần điểm xuyến màu tôm hồng bắt mắt. Một bát bánh nậm thường sẽ có thêm chả tôm, chan nước mắm ngọt để làm đậm thêm vị bánh.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23889} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-13-banh-nam.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23889\"/><figcaption>Giống như các loại bánh khác ở đây, bánh nậm được ăn kèm với nước mắm ngọt hơi cay. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:list -->\n<ul><li><em>Bánh nậm bà Đỏ –&nbsp;71 Nguyễn Bỉnh Khiêm, Phú Cát.</em></li><li><em>Quán Hàng Me –&nbsp;14 Võ Thị Sáu, Phú Hội.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>14. Bánh khoái</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nếu lần đầu đến Huế, bạn sẽ dễ dàng nhầm bánh khoái thành bánh xèo vì hình thức bên ngoài của hai món này có nhiều nét tương đồng. Nếu nhìn kỹ bạn sẽ thấy lớp vỏ bột của bánh khoái nhỏ, dày và giòn hơn bánh xèo. Đó là về bề ngoài, khi ăn vào, vị của hai món ăn cũng khác biệt, chủ yếu là do chén nước chấm ăn kèm làm nên.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23890} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-14-banh-khoai.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23890\"/><figcaption>Bánh khoái và bánh xèo thật ra có nhiều sự khác biệt trong cả cách ăn và cách làm. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Nước chấm của bánh khoái được gọi là “nước lèo”. Nước lèo của món đặc sản Huế bánh khoái được làm từ gan heo, thịt nạc băm nhuyễn, mè rang, đậu phộng giã nhuyễn cùng nước tương đậu nành Huế chính gốc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Bánh khoái Lạc Thiện&nbsp;–&nbsp;6 Đinh Tiên Hoàng.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>15. Bánh ram ít</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nếu xét trong các món bánh mặn thì bánh ram ít có phần kỳ công hơn cả từ hình dáng, cách phối màu cho đến cách làm. Sự kỳ công này đến từ việc bánh ram ít, trước khi trở thành món đặc sản Huế dễ dàng ăn thử ở bất kỳ nơi đâu như ngày nay, đã từng là món ăn được các triều Vua nhà Nguyễn ưa thích.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23891} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-15-banh-ram-it.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23891\"/><figcaption>Hẳn đây là một món bánh rất lạ đối với nhiều thực khách. @yensplate</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"id\":23892} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-15-banh-ram-it-2.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23892\"/><figcaption>Bánh ram ít trông vô cùng hấp dẫn đúng không nào. @maysul_seulgi</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Tên gọi “bánh ram ít” là sự kết hợp của hai bánh: bánh ram và bánh ít. Phần viên bánh tròn màu trắng ở trên là bánh ít, phần bánh chiên ở dưới là bánh ram. Khi ăn bánh cũng là một trải nghiệm rất độc đáo. Khi cắn, đầu tiên ta cảm nhận được cái dẻo của bột nếp, sau đó là phần nhân tôm thịt đậm đà trong bánh rồi cuối cùng là cái giòn rụm của bánh ram. Vừa ngon mắt vừa ngon miệng, bánh ram ít là món ăn ưa thích của nhiều thực khách khi đến Huế.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Quán Hàng Me –&nbsp;14 Võ Thị Sáu, Phú Hội.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2>16. Bánh đậu xanh trái cây</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Bánh đậu xanh trái cây còn được biết đến là món bánh “quý tộc” vì ngày xưa, bánh đậu xanh trái cây chỉ được thực hiện bởi những đầu bếp, thợ làm bánh nổi tiếng để dâng lên triều đình. Chính vì thế, món bánh đòi hỏi cao sự khéo tay và cẩn thận ở người làm.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":23870} -->\n<figure class=\"wp-block-image\"><img src=\"https://blog.traveloka.com/source/uploads/sites/9/2018/03/dac-san-hue-1-banh-dau-xanh-trai-cay.jpg\" alt=\"Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế\" class=\"wp-image-23870\"/><figcaption>Bánh đậu xanh trái cây từng là món bánh quý tộc, chỉ dành để dâng vua chúa. @Internet</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Bột bánh “quý tộc” được làm từ đậu xanh, thạch và màu thực phẩm. Sau khi trộn bột, người thợ phải dùng tay nặn ra hình dáng các loại củ, trái cây phổ biến như cam, mận, táo, ớt,… Cách thưởng thức bánh đậu xanh trái cây đúng Huế phải vừa uống trà, vừa ăn bánh và hàn huyên, tâm sự. Cách ăn chậm rãi và từ tốn này thích hợp với các gia đình vương giả thời xưa hoặc người lớn tuổi.&nbsp;Muốn thưởng thức&nbsp;và mua về làm quà cho người thân món bánh trái cây này, bạn có thể ghé các địa chỉ sau đây:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li><em>Chợ Đông Ba – Trần Hưng Đạo, Phú Hòa.</em></li><li><em>Vọng Lục Bộ&nbsp;– 79 Nguyễn Chí Diểu, Thuận Thành.</em></li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Ngày nay, thật không khó để bạn có thể thử các món ăn Huế ở bất kỳ tỉnh thành nào bạn đến, nhưng sẽ thật lãng phí nếu đã đến Huế mà lại chưa thử đúng đặc sản Huế. Đậm đà và đủ hương – sắc – vị là những gì bạn sẽ nhớ về ẩm thực nơi đây.</p>\n<!-- /wp:paragraph -->', 'Chưa thử 16 món đặc sản Huế này, bạn chưa đến Huế', '', 'inherit', 'closed', 'closed', '', '498-revision-v1', '', '', '2020-06-28 09:28:00', '2020-06-28 02:28:00', '', 498, 'http://localhost:8080/hotel01/498-revision-v1/', 0, 'revision', '', 0),
(501, 1, '2020-06-28 09:34:06', '2020-06-28 02:34:06', '{\n    \"hotel_galaxy_option[footer_collout_title_1]\": {\n        \"value\": \"Gym\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:34:06\"\n    },\n    \"hotel_galaxy_option[footer_collout_icon_1]\": {\n        \"value\": \"fas fa-dumbbell\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:34:06\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '49c5f6b9-4825-47b1-a363-ac02d84a06c7', '', '', '2020-06-28 09:34:06', '2020-06-28 02:34:06', '', 0, 'http://localhost:8080/hotel01/49c5f6b9-4825-47b1-a363-ac02d84a06c7/', 0, 'customize_changeset', '', 0),
(502, 1, '2020-06-28 09:34:29', '2020-06-28 02:34:29', '{\n    \"hotel_galaxy_option[footer_collout_title_1]\": {\n        \"value\": \"Ph\\u00f2ng Gym\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:34:29\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '00f8be2c-dd31-4ae8-8016-3eef0bfa097f', '', '', '2020-06-28 09:34:29', '2020-06-28 02:34:29', '', 0, 'http://localhost:8080/hotel01/00f8be2c-dd31-4ae8-8016-3eef0bfa097f/', 0, 'customize_changeset', '', 0),
(503, 1, '2020-06-28 09:46:49', '2020-06-28 02:46:49', '{\n    \"hotel-galaxy::Page_about\": {\n        \"value\": \"410\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:46:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '26139490-d1fd-4b0e-a954-6c47d971b9e0', '', '', '2020-06-28 09:46:49', '2020-06-28 02:46:49', '', 0, 'http://localhost:8080/hotel01/26139490-d1fd-4b0e-a954-6c47d971b9e0/', 0, 'customize_changeset', '', 0),
(504, 1, '2020-06-28 09:55:11', '2020-06-28 02:55:11', '{\n    \"hotel-galaxy::Page_about\": {\n        \"value\": \"241\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:55:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '11576d42-3c6a-4236-b23c-46f476205cf7', '', '', '2020-06-28 09:55:11', '2020-06-28 02:55:11', '', 0, 'http://localhost:8080/hotel01/?p=504', 0, 'customize_changeset', '', 0),
(505, 1, '2020-06-28 09:55:40', '2020-06-28 02:55:40', '<!-- wp:paragraph -->\n<p>Trung tâm thể hình của khách sạn có đầy đủ các trang thiết bị tập luyện hiện đại giúp người tập thỏa mãn các mục tiêu rèn luyện cơ thể dẻo dai, săn chắc. Hãy hăng say tập luyện – toát mồ hôi và tiếp tục tập luyện để có một sức khỏe tốt cho bản thân.<br></p>\n<!-- /wp:paragraph -->', 'Giới thiệu', '', 'inherit', 'closed', 'closed', '', '241-revision-v1', '', '', '2020-06-28 09:55:40', '2020-06-28 02:55:40', '', 241, 'http://localhost:8080/hotel01/241-revision-v1/', 0, 'revision', '', 0),
(506, 1, '2020-06-28 09:56:22', '2020-06-28 02:56:22', '{\n    \"hotel_galaxy_option[about_show]\": {\n        \"value\": false,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 02:56:22\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'feee63e3-e983-4bbc-b3d9-f4277213cf32', '', '', '2020-06-28 09:56:22', '2020-06-28 02:56:22', '', 0, 'http://localhost:8080/hotel01/feee63e3-e983-4bbc-b3d9-f4277213cf32/', 0, 'customize_changeset', '', 0),
(507, 1, '2020-06-28 10:12:07', '0000-00-00 00:00:00', '{\n    \"hotel_galaxy_option[about_show]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 03:12:07\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '4fab9fdf-3627-4a24-87e5-87dbbaed2d49', '', '', '2020-06-28 10:12:07', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/hotel01/?p=507', 0, 'customize_changeset', '', 0),
(508, 1, '2020-06-28 10:13:45', '2020-06-28 03:13:45', '{\n    \"hotel_galaxy_option[about_show]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 03:13:45\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '430a547e-f434-4969-a1b1-1e4740f95d2b', '', '', '2020-06-28 10:13:45', '2020-06-28 03:13:45', '', 0, 'http://localhost:8080/hotel01/430a547e-f434-4969-a1b1-1e4740f95d2b/', 0, 'customize_changeset', '', 0),
(509, 1, '2020-06-28 11:16:51', '2020-06-28 04:16:51', '{\n    \"hotel_galaxy_option[blog_latest]\": {\n        \"value\": \"5\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-06-28 04:16:51\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c6c7252a-a4a5-485a-a8e9-f7b96574fb21', '', '', '2020-06-28 11:16:51', '2020-06-28 04:16:51', '', 0, 'http://localhost:8080/hotel01/c6c7252a-a4a5-485a-a8e9-f7b96574fb21/', 0, 'customize_changeset', '', 0),
(510, 1, '2020-06-28 11:17:46', '0000-00-00 00:00:00', '[]', '', '', 'auto-draft', 'closed', 'closed', '', 'd00a36c5-1a0d-4f48-9825-bd76e524197c', '', '', '2020-06-28 11:17:46', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/hotel01/?p=510', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_exclusions`
--

DROP TABLE IF EXISTS `wp_statistics_exclusions`;
CREATE TABLE IF NOT EXISTS `wp_statistics_exclusions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `date` (`date`),
  KEY `reason` (`reason`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_historical`
--

DROP TABLE IF EXISTS `wp_statistics_historical`;
CREATE TABLE IF NOT EXISTS `wp_statistics_historical` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(25) NOT NULL,
  `page_id` bigint(20) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `value` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `page_id` (`page_id`),
  UNIQUE KEY `uri` (`uri`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_pages`
--

DROP TABLE IF EXISTS `wp_statistics_pages`;
CREATE TABLE IF NOT EXISTS `wp_statistics_pages` (
  `page_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `count` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `date_2` (`date`,`uri`),
  KEY `url` (`uri`),
  KEY `date` (`date`),
  KEY `id` (`id`),
  KEY `uri` (`uri`,`count`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `wp_statistics_pages`
--

INSERT INTO `wp_statistics_pages` (`page_id`, `uri`, `type`, `date`, `count`, `id`) VALUES
(1, '/', 'home', '2020-06-18', 1, 0),
(2, '/', 'home', '2020-06-26', 1, 0),
(3, '/accommodation/phong-king-suite/', 'post', '2020-06-26', 4, 373);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_search`
--

DROP TABLE IF EXISTS `wp_statistics_search`;
CREATE TABLE IF NOT EXISTS `wp_statistics_search` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `last_counter` date NOT NULL,
  `engine` varchar(64) NOT NULL,
  `host` varchar(255) DEFAULT NULL,
  `words` varchar(255) DEFAULT NULL,
  `visitor` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `last_counter` (`last_counter`),
  KEY `engine` (`engine`),
  KEY `host` (`host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_useronline`
--

DROP TABLE IF EXISTS `wp_statistics_useronline`;
CREATE TABLE IF NOT EXISTS `wp_statistics_useronline` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(60) NOT NULL,
  `created` int(11) DEFAULT NULL,
  `timestamp` int(10) NOT NULL,
  `date` datetime NOT NULL,
  `referred` text NOT NULL,
  `agent` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `location` varchar(10) DEFAULT NULL,
  `user_id` bigint(48) NOT NULL,
  `page_id` bigint(48) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_visit`
--

DROP TABLE IF EXISTS `wp_statistics_visit`;
CREATE TABLE IF NOT EXISTS `wp_statistics_visit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `last_visit` datetime NOT NULL,
  `last_counter` date NOT NULL,
  `visit` int(10) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_date` (`last_counter`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `wp_statistics_visit`
--

INSERT INTO `wp_statistics_visit` (`ID`, `last_visit`, `last_counter`, `visit`) VALUES
(1, '2019-10-10 14:42:45', '2019-10-10', 1),
(2, '0000-00-00 00:00:00', '2019-10-11', 0),
(3, '0000-00-00 00:00:00', '2019-10-18', 0),
(4, '0000-00-00 00:00:00', '2019-10-20', 0),
(5, '0000-00-00 00:00:00', '2019-10-23', 0),
(6, '0000-00-00 00:00:00', '2019-10-26', 0),
(7, '0000-00-00 00:00:00', '2019-10-31', 0),
(9, '0000-00-00 00:00:00', '2020-06-16', 0),
(10, '2020-06-15 10:52:55', '2020-06-15', 7),
(11, '0000-00-00 00:00:00', '2020-06-17', 0),
(13, '2020-06-18 14:02:14', '2020-06-18', 1),
(14, '0000-00-00 00:00:00', '2020-06-19', 0),
(15, '2020-06-26 14:05:33', '2020-06-26', 6),
(16, '0000-00-00 00:00:00', '2020-06-27', 0),
(23, '0000-00-00 00:00:00', '2020-06-28', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_statistics_visitor`
--

DROP TABLE IF EXISTS `wp_statistics_visitor`;
CREATE TABLE IF NOT EXISTS `wp_statistics_visitor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `last_counter` date NOT NULL,
  `referred` text NOT NULL,
  `agent` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `UAString` varchar(255) DEFAULT NULL,
  `ip` varchar(60) NOT NULL,
  `location` varchar(10) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `honeypot` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `date_ip_agent` (`last_counter`,`ip`,`agent`(75),`platform`(75),`version`(75)),
  KEY `agent` (`agent`),
  KEY `platform` (`platform`),
  KEY `version` (`version`),
  KEY `location` (`location`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `wp_statistics_visitor`
--

INSERT INTO `wp_statistics_visitor` (`ID`, `last_counter`, `referred`, `agent`, `platform`, `version`, `UAString`, `ip`, `location`, `hits`, `honeypot`) VALUES
(1, '2019-10-10', 'http://localhost/hotel01/wp-admin/plugins.php', 'Chrome', 'Windows', '10.0', NULL, '::1', '000', NULL, NULL),
(2, '2020-06-15', 'http://localhost:8080/hotel/wp-admin/', 'Chrome', 'Windows', '10.0', '', '::1', '000', 7, 0),
(3, '2020-06-18', 'http://localhost:8080/hotel01', 'Chrome', 'Windows', '10.0', '', '::1', '000', 1, 0),
(4, '2020-06-26', 'http://localhost:8080/hotel01', 'Chrome', 'Windows', '10.0', '', '::1', '000', 6, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Room', 'room', 0),
(3, 'Phòng VIP', 'phong-vip', 0),
(4, 'Phòng bình thường', 'phong-binh-thuong', 0),
(5, 'Máy lạnh', 'may-lanh', 0),
(6, 'TiVi', 'tivi', 0),
(7, 'Wifi', 'wifi', 0),
(8, 'Điện thoại bàn', 'dien-thoai-ban', 0),
(9, 'Menu 1', 'menu-1', 0),
(10, 'Tin tức', 'tin-tuc', 0),
(11, 'Tủ lạnh nhỏ', 'tu-lanh-nho', 0),
(12, 'Contact Form 7', 'contact-form-7', 0),
(13, 'Form contact', 'form-contact', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 10, 0),
(6, 10, 0),
(109, 9, 0),
(154, 10, 0),
(160, 9, 0),
(278, 9, 0),
(285, 9, 0),
(287, 9, 0),
(291, 10, 0),
(304, 4, 0),
(304, 5, 0),
(304, 6, 0),
(304, 7, 0),
(304, 8, 0),
(304, 11, 0),
(317, 4, 0),
(317, 5, 0),
(317, 6, 0),
(317, 7, 0),
(317, 8, 0),
(317, 11, 0),
(333, 4, 0),
(333, 5, 0),
(333, 6, 0),
(333, 7, 0),
(333, 8, 0),
(333, 11, 0),
(348, 3, 0),
(348, 5, 0),
(348, 6, 0),
(348, 7, 0),
(348, 8, 0),
(348, 11, 0),
(364, 3, 0),
(364, 5, 0),
(364, 6, 0),
(364, 7, 0),
(364, 8, 0),
(364, 11, 0),
(373, 3, 0),
(373, 5, 0),
(373, 6, 0),
(373, 7, 0),
(373, 8, 0),
(373, 11, 0),
(436, 13, 0),
(437, 13, 0),
(438, 13, 0),
(439, 13, 0),
(440, 13, 0),
(442, 13, 0),
(495, 10, 0),
(498, 10, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 0),
(3, 3, 'mphb_room_type_category', '', 0, 3),
(4, 4, 'mphb_room_type_category', '', 0, 3),
(5, 5, 'mphb_room_type_facility', '', 0, 6),
(6, 6, 'mphb_room_type_facility', '', 0, 6),
(7, 7, 'mphb_room_type_facility', '', 0, 6),
(8, 8, 'mphb_room_type_facility', '', 0, 6),
(9, 9, 'nav_menu', '', 0, 5),
(10, 10, 'category', '', 0, 6),
(11, 11, 'mphb_room_type_facility', '', 0, 6),
(12, 12, 'flamingo_inbound_channel', '', 0, 0),
(13, 13, 'flamingo_inbound_channel', '', 12, 6);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:4:{s:13:\"administrator\";b:1;s:14:\"erp_hr_manager\";b:1;s:15:\"erp_crm_manager\";b:1;s:14:\"erp_ac_manager\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'text_widget_custom_html,adrotatefree_39465,adrotatefree_39966'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '299'),
(18, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&uploader=1'),
(19, 1, 'wp_user-settings-time', '1592297611'),
(20, 1, 'closedpostboxes_mphb_room_type', 'a:1:{i:0;s:10:\"wpseo_meta\";}'),
(21, 1, 'metaboxhidden_mphb_room_type', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(22, 1, 'meta-box-order_mphb_room_type', 'a:3:{s:4:\"side\";s:149:\"submitdiv,mphb_room_type_categorydiv,tagsdiv-mphb_room_type_tag,mphb_room_type_facilitydiv,pageparentdiv,attributes,reviews,mphb_gallery,postimagediv\";s:6:\"normal\";s:42:\"postexcerpt,commentstatusdiv,slugdiv,rooms\";s:8:\"advanced\";s:38:\"mphb_capacity,mphb_other,mphb_services\";}'),
(23, 1, 'screen_layout_mphb_room_type', '2'),
(24, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(25, 1, 'metaboxhidden_nav-menus', 'a:6:{i:0;s:28:\"add-post-type-mphb_room_type\";i:1;s:31:\"add-post-type-mphb_room_service\";i:2;s:12:\"add-post_tag\";i:3;s:27:\"add-mphb_room_type_category\";i:4;s:22:\"add-mphb_room_type_tag\";i:5;s:27:\"add-mphb_room_type_facility\";}'),
(26, 1, 'nav_menu_recently_edited', '9'),
(27, 1, 'closedpostboxes_mphb_booking', 'a:0:{}'),
(28, 1, 'metaboxhidden_mphb_booking', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(29, 1, 'closedpostboxes_mphb_payment', 'a:0:{}'),
(30, 1, 'metaboxhidden_mphb_payment', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(31, 1, 'closedpostboxes_mphb_room_service', 'a:0:{}'),
(32, 1, 'metaboxhidden_mphb_room_service', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(33, 1, 'wp_statistics', 'a:2:{s:13:\"dashboard_set\";s:7:\"12.6.10\";s:10:\"editor_set\";s:7:\"12.6.10\";}'),
(34, 1, 'metaboxhidden_dashboard', 'a:33:{i:0;s:28:\"wp-statistics-summary-widget\";i:1;s:29:\"wp-statistics-browsers-widget\";i:2;s:30:\"wp-statistics-countries-widget\";i:3;s:25:\"wp-statistics-hits-widget\";i:4;s:26:\"wp-statistics-pages-widget\";i:5;s:30:\"wp-statistics-referring-widget\";i:6;s:27:\"wp-statistics-search-widget\";i:7;s:26:\"wp-statistics-words-widget\";i:8;s:33:\"wp-statistics-top-visitors-widget\";i:9;s:27:\"wp-statistics-recent-widget\";i:10;s:28:\"wp-statistics-hitsmap-widget\";i:11;s:28:\"wp-statistics-summary-widget\";i:12;s:29:\"wp-statistics-browsers-widget\";i:13;s:30:\"wp-statistics-countries-widget\";i:14;s:25:\"wp-statistics-hits-widget\";i:15;s:26:\"wp-statistics-pages-widget\";i:16;s:30:\"wp-statistics-referring-widget\";i:17;s:27:\"wp-statistics-search-widget\";i:18;s:26:\"wp-statistics-words-widget\";i:19;s:33:\"wp-statistics-top-visitors-widget\";i:20;s:27:\"wp-statistics-recent-widget\";i:21;s:28:\"wp-statistics-hitsmap-widget\";i:22;s:28:\"wp-statistics-summary-widget\";i:23;s:29:\"wp-statistics-browsers-widget\";i:24;s:30:\"wp-statistics-countries-widget\";i:25;s:25:\"wp-statistics-hits-widget\";i:26;s:26:\"wp-statistics-pages-widget\";i:27;s:30:\"wp-statistics-referring-widget\";i:28;s:27:\"wp-statistics-search-widget\";i:29;s:26:\"wp-statistics-words-widget\";i:30;s:33:\"wp-statistics-top-visitors-widget\";i:31;s:27:\"wp-statistics-recent-widget\";i:32;s:28:\"wp-statistics-hitsmap-widget\";}'),
(35, 1, 'metaboxhidden_post', 'a:1:{i:0;s:29:\"wp_statistics_editor_meta_box\";}'),
(36, 1, 'metaboxhidden_page', 'a:1:{i:0;s:29:\"wp_statistics_editor_meta_box\";}'),
(39, 1, 'closedpostboxes_mphb_rate', 'a:0:{}'),
(40, 1, 'metaboxhidden_mphb_rate', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(46, 1, 'session_tokens', 'a:1:{s:64:\"0fc8c47fa235164856fb02fe6c9531f25a3cef7695d90d7e537d1de3fa3c480d\";a:4:{s:10:\"expiration\";i:1593339676;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36\";s:5:\"login\";i:1593166876;}}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BI25cueHFhReg.IGSUiXhU0DcZ7S4q/', 'admin', 'nguyenvanhoai1280@gmail.com', '', '2019-09-06 01:49:58', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_yoast_seo_links`
--

DROP TABLE IF EXISTS `wp_yoast_seo_links`;
CREATE TABLE IF NOT EXISTS `wp_yoast_seo_links` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_yoast_seo_links`
--

INSERT INTO `wp_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(30, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(31, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(32, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(33, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(34, 'http://localhost/hotel01/slider/page-title/', 21, 128, 'internal'),
(35, 'http://localhost/hotel01/2019/09/06/ve-hue-dip-tet-trai-nghiem-cuoc-song-chon-hoang-cung/download/', 21, 7, 'internal'),
(36, 'http://localhost/hotel01/nha-khach-thanh-nien/normal_11-571252810/', 21, 132, 'internal'),
(37, 'http://localhost/hotel01/accommodation/phong-gia-dinh/attachment/89787233/', 21, 173, 'internal'),
(38, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(39, 'http://localhost/hotel01/accommodation-facility/dien-thoai-ban/', 21, 0, 'internal'),
(40, 'http://localhost/hotel01/accommodation-facility/may-lanh/', 21, 0, 'internal'),
(41, 'http://localhost/hotel01/accommodation-facility/tivi/', 21, 0, 'internal'),
(42, 'http://localhost/hotel01/accommodation-facility/wifi/', 21, 0, 'internal'),
(43, 'http://localhost/hotel01/accommodation-category/phong-binh-thuong/', 21, 0, 'internal'),
(44, 'http://localhost/hotel01/accommodation/phong-gia-dinh/', 21, 172, 'internal'),
(45, 'http://localhost/hotel01/accommodation/phong-doi/', 21, 42, 'internal'),
(46, 'http://localhost/hotel01/accommodation/phong-doi/', 21, 42, 'internal'),
(47, 'http://localhost/hotel01/accommodation-facility/dien-thoai-ban/', 21, 0, 'internal'),
(48, 'http://localhost/hotel01/accommodation-facility/may-lanh/', 21, 0, 'internal'),
(49, 'http://localhost/hotel01/accommodation-facility/tivi/', 21, 0, 'internal'),
(50, 'http://localhost/hotel01/accommodation-facility/wifi/', 21, 0, 'internal'),
(51, 'http://localhost/hotel01/accommodation-category/phong-vip/', 21, 0, 'internal'),
(52, 'http://localhost/hotel01/accommodation/phong-doi/', 21, 42, 'internal'),
(53, 'http://localhost/hotel01/accommodation/phong-don/', 21, 29, 'internal'),
(54, 'http://localhost/hotel01/accommodation/phong-don/', 21, 29, 'internal'),
(55, 'http://localhost/hotel01/accommodation-facility/may-lanh/', 21, 0, 'internal'),
(56, 'http://localhost/hotel01/accommodation-facility/wifi/', 21, 0, 'internal'),
(57, 'http://localhost/hotel01/accommodation-category/phong-vip/', 21, 0, 'internal'),
(58, 'http://localhost/hotel01/accommodation/phong-don/', 21, 29, 'internal'),
(62, 'https://www.ivivu.com/blog/category/viet-nam/hue-viet-nam/', 291, 0, 'external'),
(65, 'https://blog.traveloka.com/vn/resort-hue-ecolodge/', 498, 0, 'external'),
(66, 'https://www.traveloka.com/vi-vn/flight?utm_source=blog.traveloka.com&amp;utm_medium=referral&amp;utm_campaign=VN-FL-OM-Button-FLCTA-AVC2018080167-ContentMiddle', 498, 0, 'external');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wp_yoast_seo_meta`
--

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;
CREATE TABLE IF NOT EXISTS `wp_yoast_seo_meta` (
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `internal_link_count` int(10) UNSIGNED DEFAULT NULL,
  `incoming_link_count` int(10) UNSIGNED DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `wp_yoast_seo_meta`
--

INSERT INTO `wp_yoast_seo_meta` (`object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(1, 0, 0),
(2, 0, 0),
(3, 0, 0),
(4, 0, 0),
(5, 0, 0),
(6, 0, 0),
(7, NULL, 1),
(9, 0, 0),
(10, 0, 0),
(11, 0, 0),
(12, 0, 0),
(13, 0, 0),
(14, 0, 0),
(15, 0, 0),
(16, 0, 0),
(19, 0, 0),
(20, 0, 0),
(21, 29, 0),
(22, 0, 0),
(23, 0, 0),
(24, 0, 0),
(25, 0, 0),
(26, 0, 0),
(27, 0, 0),
(28, 0, 0),
(29, 0, 3),
(30, 0, 0),
(31, 0, 0),
(32, 0, 0),
(33, 0, 0),
(34, 0, 0),
(35, 0, 0),
(36, 0, 0),
(37, 0, 0),
(38, 0, 0),
(39, 0, 0),
(40, 0, 0),
(41, 0, 0),
(42, 0, 3),
(43, 0, 0),
(44, 0, 0),
(45, 0, 0),
(46, 0, 0),
(47, 0, 0),
(48, 0, 0),
(49, 0, 0),
(50, 0, 0),
(51, 0, 0),
(52, 0, 0),
(53, 0, 0),
(55, 0, 0),
(56, 0, 0),
(57, 0, 0),
(58, 0, 0),
(59, 0, 0),
(60, 0, 0),
(61, 0, 0),
(62, 0, 0),
(63, 0, 0),
(64, 0, 0),
(65, 0, 0),
(66, 0, 0),
(67, 0, 0),
(68, 0, 0),
(69, 0, 0),
(70, 0, 0),
(71, 0, 0),
(72, 0, 0),
(73, 0, 0),
(74, 0, 0),
(75, 0, 0),
(76, 0, 0),
(77, 0, 0),
(78, 0, 0),
(79, 0, 0),
(80, 0, 0),
(81, 0, 0),
(82, 0, 0),
(83, 0, 0),
(84, 0, 0),
(85, 0, 0),
(86, 0, 0),
(87, 0, 0),
(88, 0, 0),
(89, 0, 0),
(90, 0, 0),
(91, 0, 0),
(92, 0, 0),
(93, 0, 0),
(94, 0, 0),
(95, 0, 0),
(96, 0, 0),
(97, 0, 0),
(98, 0, 0),
(99, 0, 0),
(100, 0, 0),
(101, 0, 0),
(102, 0, 0),
(103, 0, 0),
(104, 0, 0),
(105, 0, 0),
(106, 0, 0),
(107, 0, 0),
(108, 0, 0),
(110, 0, 0),
(118, 0, 0),
(119, 0, 0),
(120, 0, 0),
(121, 0, 0),
(122, 0, 0),
(123, 0, 0),
(124, 0, 0),
(125, 0, 0),
(126, 0, 0),
(127, 0, 0),
(128, NULL, 1),
(130, 0, 0),
(131, 0, 0),
(132, NULL, 1),
(133, 0, 0),
(134, 0, 0),
(135, 0, 0),
(136, 0, 0),
(137, 0, 0),
(138, 0, 0),
(139, 0, 0),
(140, 0, 0),
(141, 0, 0),
(142, 0, 0),
(144, 0, 0),
(145, 0, 0),
(146, 0, 0),
(147, 0, 0),
(148, 0, 0),
(149, 0, 0),
(150, 0, 0),
(151, 0, 0),
(152, 0, 0),
(153, 0, 0),
(154, 0, 0),
(159, 0, 0),
(161, 0, 0),
(162, 0, 0),
(163, 0, 0),
(164, 0, 0),
(165, 0, 0),
(166, 0, 0),
(167, 0, 0),
(171, 0, 0),
(172, 0, 6),
(173, NULL, 1),
(174, 0, 0),
(175, 0, 0),
(176, 0, 0),
(177, 0, 0),
(178, 0, 0),
(179, 0, 0),
(180, 0, 0),
(181, 0, 0),
(182, 0, 0),
(188, 0, 0),
(189, 0, 0),
(190, 0, 0),
(191, 0, 0),
(192, 0, 0),
(193, 0, 0),
(194, 0, 0),
(195, 0, 0),
(196, 0, 0),
(197, 0, 0),
(198, 0, 0),
(199, 0, 0),
(200, 0, 0),
(201, 0, 0),
(202, 0, 0),
(203, 0, 0),
(204, 0, 0),
(205, 0, 0),
(206, 0, 0),
(207, 0, 0),
(208, 0, 0),
(209, 0, 0),
(210, 0, 0),
(213, 0, 0),
(217, 0, 0),
(221, 0, 0),
(222, 0, 0),
(223, 0, 0),
(233, 0, 0),
(234, 0, 0),
(235, 0, 0),
(236, 0, 0),
(237, 0, 0),
(238, 0, 0),
(239, 0, 0),
(240, 0, 0),
(241, 0, 0),
(243, 0, 0),
(244, 0, 0),
(245, 0, 0),
(246, 0, 0),
(247, 0, 0),
(248, 0, 0),
(251, 0, 0),
(252, 0, 0),
(253, 0, 0),
(254, 0, 0),
(255, 0, 0),
(256, 0, 0),
(257, 0, 0),
(258, 0, 0),
(259, 0, 0),
(260, 0, 0),
(261, 0, 0),
(262, 0, 0),
(264, 0, 0),
(265, 0, 0),
(266, 0, 0),
(267, 0, 0),
(271, 0, 0),
(272, 0, 0),
(273, 0, 0),
(275, 0, 0),
(276, 0, 0),
(277, 0, 0),
(279, 0, 0),
(283, 0, 0),
(284, 0, 0),
(286, 0, 0),
(288, 0, 0),
(289, 0, 0),
(290, 0, 0),
(291, 0, 0),
(294, 0, 0),
(295, 0, 0),
(296, 0, 0),
(299, 0, 0),
(300, 0, 0),
(304, 0, 0),
(315, 0, 0),
(317, 0, 0),
(333, 0, 0),
(348, 0, 0),
(364, 0, 0),
(373, 0, 0),
(384, 0, 0),
(390, 0, 0),
(391, 0, 0),
(395, 0, 0),
(397, 0, 0),
(400, 0, 0),
(401, 0, 0),
(408, 0, 0),
(410, 0, 0),
(412, 0, 0),
(414, 0, 0),
(419, 0, 0),
(423, 0, 0),
(424, 0, 0),
(426, 0, 0),
(429, 0, 0),
(430, 0, 0),
(431, 0, 0),
(452, 0, 0),
(453, 0, 0),
(454, 0, 0),
(465, 0, 0),
(468, 0, 0),
(476, 0, 0),
(477, 0, 0),
(478, 0, 0),
(479, 0, 0),
(480, 0, 0),
(481, 0, 0),
(482, 0, 0),
(485, 0, 0),
(495, 0, 0),
(498, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
